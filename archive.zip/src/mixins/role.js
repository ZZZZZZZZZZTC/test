import { mapGetters } from 'vuex'

export default {
  computed: {
    ...mapGetters(['roles'])
  },
  methods: {
    hasPermission(permissionRoles) {
      let roles = this.roles
      if (!permissionRoles) return true
      return permissionRoles.some(role => roles.indexOf(role) >= 0)
    }
  }
}
