<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
  import {mapGetters, mapActions, mapMutations} from 'vuex'

  export default {
    name: 'App',
    mounted() {
      let _this = this
      console.log('App 已挂载')
      window.hanClient.callbackTrayMsgClick = function (uuid,extraStr) {
        let data = JSON.parse(extraStr);
        _this.createNewConversation(data);
        window.hanClient.readMsgByUuid(uuid)
        _this.$router.push('chat')
         _this.receTrapMessage(true)
      }
    },
    methods: {
      ...mapActions(['createNewConversation']),
      ...mapMutations({
        receiveTrapMessage: 'RECEIVE_TRAYMESSAGE'
      }),
      receTrapMessage() {
        this.receiveTrapMessage(true)
      }
    }
  }
</script>
