import fetch from '@/utils/fetch'
import { DOMAIN } from '@/api/config'


export function getUploadImgToken() {
  return fetch({
    url:`${DOMAIN}/Upload/getImageToken`
  })
}

export function getUploadFileToken() {
  return fetch({
    url:`${DOMAIN}/Upload/getFileToken`
  })
}
