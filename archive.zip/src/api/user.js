import fetch from '@/utils/fetch'
// 获取本人信息
export function getSelfInfo() {
  return fetch({
    url: '//api.hanmaker.com/user/getSelfInfo'
  })
}

// 获取用户所有群组 获取自己加入的群组信息
export function getGroupUserGroupList() {
  return fetch({
    url: '//api.hanmaker.com/Group/getUserGroupList'
  })
}
// 获取员工分组列表
export function getUserOrganizeList() {
  return fetch({
    url:'//api.hanmaker.com/User/getUserGroupList'
  })
}

// 获取群组用户列表
export function groupUserList(group_id) {
  return fetch({
    url: '//api.hanmaker.com/Group/getGroupUserList/group_id/' + group_id
  })
}

// 获取最近聊天列表以及常用人与常用群
export function getRecentChatList(type) {
  type = 0 || type;
  return fetch({
    url:'//api.hanmaker.com/Message/getRecentChatList?type=' + type
  })
}

// 获取员工信息
export function getUserInfo(id) {
  return fetch({
    url:'//api.hanmaker.com/User/getUserInfo?id=' + id
  })

}
// 获取群信息
export function getGroupInfo(group_id) {
  return fetch({
    url: '//api.hanmaker.com/user/getGroupInfo?group_id='+ group_id
  })
}

// 通过员工id获取员工信息
export function getUserListByIds(ids) {
  return fetch({
    method: 'post',
    url: '//api.hanmaker.com//User/getUserListByIds',
    data: {uids: ids}
  })
}

// 获取组信息
export function getGroupList() {
  return fetch({
    url: '//api.hanmaker.com/User/getGroupList'
  })
}
// 获取人
export function getUserList() {
  return fetch({
    url: '//api.hanmaker.com/user/getUserList'
  })
}
// 获取所有在职员工列表
export function getStaffOptions() {
  return fetch({
    url: "//api.hanmaker.com/Staff/getStaffOptions"
  })
}


// 根据uid 获取网页端staff_id
export function getUid2staff(uid) {
  return fetch({
    url:`//api.hanmaker.com/V2/Tool/uid2staff?uid=` + uid
  })
}

//获取用户配置
export function getUserConfigList() {
  return fetch({
    url: '//api.hanmaker.com/Message/getClientSetting'
  })
}
