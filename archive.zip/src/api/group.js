import fetch from '@/utils/fetch'
import { DOMAIN } from '@/api/config'
// 邀请入群
export function groupInviteToJoin(group_id, uids) {
  let data = {}
  data.group_id = group_id
  data.uids = uids
  return fetch({
    method: 'post',
    url: `${DOMAIN}/Group/inviteToJoin`,
    data: data
  })
}
// 创建群组
export function groupCreate(form) {
  return fetch({
    method: 'post',
    url: `${DOMAIN}/Group/create`,
    data: form
  })
}
// 踢出群组
export function groupQuitGroup(group_id, uid) {
  let data = {
    group_id: group_id,
    uid: uid
  }
  return fetch({
    method: 'post',
    url: `${DOMAIN}/Group/quitGroup`,
    data: data
  })
}
// 解散群组
export function groupDismiss(group_id) {
  let data = {
    group_id: group_id
  }
  return fetch({
    method: 'post',
    url: `${DOMAIN}/Group/dismiss`,
    data: data
  })
}
// 退出群组
export function groupQuit(group_id) {
  let data = {
    group_id: group_id
  }
  return fetch({
    method: 'post',
    url: `${DOMAIN}/Group/quit`,
    data: data
  })
}
// 屏蔽群组
export function shieldGroup(group_id) {
  let data = {
    group_id: group_id
  }
  return fetch({
    method:'post',
    url:`${DOMAIN}/Group/shieldGroup`,
    data:data
  })
}
// 取消屏蔽群组
export function unShieldGroup(group_id) {
  let data = {
    group_id: group_id
  }
  return fetch({
    method:'post',
    url:`${DOMAIN}/Group/unShieldGroup`,
    data:data
  })
}
// 修改群名称
export function editGroupName(group_id,group_name) {
  let data = {
    group_id,
    group_name
  }
  return fetch({
    method:'post',
    url:`${DOMAIN}/Group/modGroupInfo`,
    data:data
  })
}
// 修改群头像
export function editGroupAvatar(group_id,avatar) {
  let data = {
    group_id,
    avatar
  }
  return fetch({
    method:'post',
    url:`${DOMAIN}/Group/modGroupInfo`,
    data:data
  })
}
// 转让群主
export function changeGroupOwner(group_id,owner) {
  let data = {
    group_id,
    owner
  }
  return fetch({
    method:'post',
    url:`${DOMAIN}/Group/modGroupInfo`,
    data:data
  })
}
// 获取群组在线人数
export function getGroupOnlineStatus(group_id) {
  return fetch({
    url: `${DOMAIN}/Group/getGroupOnlineStatus?id=` + group_id
  })
}
// 设置邀请成员方式
export function setGroupPrivate(type,group_id) {
  let data ={
    type: 0 || type,
    group_id:group_id
  }
 return fetch({
   method:"post",
   url:`${DOMAIN}/V2/Group/setGroupPrivate`,
   data:data
 })
}
// 添加管理员
export function attachManager(formData) {
  let data = formData
  return fetch({
    method:'post',
    url:`${DOMAIN}/V2/Group/attachManager`,
    data:data
  })
}
// 移除管理员
export function detachManager(formData) {
  let data = formData
  return fetch({
    method:'post',
    url:`${DOMAIN}/V2/Group/detachManager`,
    data:data
  })

}
// 确认群组是否存在
export function checkGroupStatus(group_id) {
  let data = {
    group_id: group_id
  }
  return fetch({
    method:'post',
    url:'//api.hanmaker.com/V2/Group/checkGroupStatus',
    data:data
  })
}
// // 获取群组所有信息
// export function groupInfo(group_id) {
//   return fetch({
//     url: '//api.hanmaker.com/Group/getAllGroupInfo/group_id/' + group_id
//   })
// }
// 获取群信息
export function groupInfo(group_id) {
  return fetch({
    url: '//api.hanmaker.com/user/getGroupInfo?group_id='+ group_id
  })
}
// 创建群组会话关系
export function groupCreateConversation(group_id) {
  return fetch({
    method: 'post',
    url: '//api.hanmaker.com/Group/createConversation',
    data: { group_id: group_id }
  })
}
