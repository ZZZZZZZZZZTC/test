import fetch from '@/utils/fetch'
import { DOMAIN } from '@/api/config'
import {genMsgUId} from '@/utils/utils'
// 发送消息
export function publishChatMsg(data) {
  return fetch({
    method: 'post',
    url: `${DOMAIN}/V3/Message/publishPrivate`,
    data: data
  })
}

// 发送消息
export function updateChatMsgType(id,type) {
  let data = {
    message_id:id,
    type:type
  }
  return fetch({
    method: 'post',
    url: `${DOMAIN}/V3/Message/updateSendType`,
    data: data
  })
}
// 获取表情包组
export function getStickerGroup() {
  return fetch({
    url: `${DOMAIN}/V2/Sticker/getGroups`,
  })
}

// 获取表情列表
export function getStickerList(group_id) {
  return fetch({
    url: `${DOMAIN}/V2/Sticker/getStickers?group_id=${group_id}`,
  })
}
// 置顶和取消置顶会话
export function stickChatTop(id, type, stick) {
  let data = {
    id, type, stick
  }
  return fetch({
    method: 'post',
    url: `${DOMAIN}/Message/setStick`,
    data: data
  })
}

//获取置顶会话
export function getStickTopChat() {
  let uuid = genMsgUId()
  return fetch({
    url: `${DOMAIN}/Message/getStickList?uuid=${uuid}`
  })
}
//获取信息
export function newMessage() {
  let data = {client:localStorage.getItem('clientName')}
  return fetch({
    method: 'post',
    url: `${DOMAIN}/v2/Tool/newMessage `,
    data: data
  })
}

//数据同步
export function syncData(data) {
  return fetch({
    method: 'post',
    url: `${DOMAIN}/V2/Tool/syncData`,
    data: data
  })
}

// 获取数据同步
export function getSyncData(name) {
  let data = {
    key: name
  }
  return fetch({
    method: 'post',
    url: `${DOMAIN}/V2/Tool/getData`,
    data: data
  })
}

// 搜索员工群组列表
export function searchUserAndGroup(keywords) {
  return fetch({
    url: '//api.hanmaker.com/user/getSearchList?keywords=' + keywords
  })
}

// 获取群文件
export function getGroupMsg(group_id, type, page) {
  type = type || 2
  page = page || 1
  return fetch({
    url: `${DOMAIN}/Message/getGroupMsg?group_id=${group_id}&type=${type}&p=${page}`
  })
}
// 获取个人相关信息
export function getUserMsg(relationship,type,page){
  type = type || 2
  page = page || 1
  return fetch({
    url:`${DOMAIN}/Message/getUserMsg?relationship=${relationship}&type=${type}&p=${page}`
  })
}

// 获取不同类型消息内容 type:1 图片，2，文件
export function getMessageByType(relationship,type,page) {
  page = page || 1
  return fetch({
    url:`${DOMAIN}/v2/Message/getMessageByType?relationship=${relationship}&type=${type}&page=${page}`
  })
}



// 获取全文搜索
export function getSo(type, keyword, p, size) {
  p = p || 1
  size = size || 20
  return fetch({
    url: `${DOMAIN}/So?type=${type}&keyword=${keyword}&p=${p}&size=${size}`
  })
}
// 获取消息记录 旧版
export function getMessageList(is_group, id, type, keyword, page, time) {
  is_group = is_group || 0
  page = page || 0
  type = type || ''
  keyword = keyword || ''
  time = time || ''
  return fetch({
    url: `${DOMAIN}/Message/getMessageList?id=${id}&is_group=${is_group}&type=${type}&page=${page}&keyword=${keyword}&time=${time}`
  })
}

// 根据id获取消息记录 新
export function getMessageListNew(id, relationship, type = 1) {
  // 获取类型 0==> 默认，获取chat_id前后10条, 1==> 向前取 20 条, 2 ==> 向后取20条
  let data = {
    chat_id: id,
    relationship: relationship,
    type: type,
    version:1
  }
  return fetch({
    method: 'post',
    url: `${DOMAIN}/V2/Message/getChatListByOrder`,
    data: data
  })
}

// 修改用户字体大小
export function setConversationFontSize(font_size) {
  let data = {
    font_size: font_size
  }
  return fetch({
    method: 'post',
    url: `${DOMAIN}/Message/setUserClientFontSize`,
    data: data
  })
}

//获取待办任务
export function readAllMessage(relationship) {
  let data ={
    relationship:relationship
  }
  return fetch({
    method: 'post',
    url: `${DOMAIN}/v3/Message/readAll`,
    data: data
  })
}

//获取待办任务
export function getUndoMission() {
  return fetch({
    url: `${DOMAIN}/V2/Account/getUndoTasks`
  })
}
// 新版消息记录
export function chatListByTime(ship,page,time,keyword) {
  // let timestamp = new Date().getTime() / 1000;

  let data= {
    relationship:ship,
    page: 0 || page,
    timeline: 0 || time,
    keyword:''|| keyword,
    version:1
  }
  return fetch({
    method:'post',
    url:`${DOMAIN}/V2/Message/chatListByTime`,
    data:data
  })
}


//撤回消息

export function updateSendType(msgItem) {
  return fetch({
    method:'post',
    url:`${DOMAIN}/v3/Message/updateSendType`,
    data:{
      message_id:msgItem.messageId || msgItem.id,
      type:5
    }
  })
}

//统计

export function statistics(statisticsType) {
  return fetch({
    method:'post',
    url:`${DOMAIN}/V2/Tool/logFunction`,
    data:{
      func:statisticsType,
      client:'pc'
    }
  })
}




