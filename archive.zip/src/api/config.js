export const DOMAIN = '//api.hanmaker.com'
