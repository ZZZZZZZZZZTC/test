import fetch from '@/utils/fetch'
import { DOMAIN } from '@/api/config'

// 获取通知
export function receiveNotify() {
  return fetch({
    url: `${DOMAIN}/Notify`
  })
}

// 临近活动
export function nearActivity() {
  return fetch({
    url: `${DOMAIN}/Activity/nearActivity`
  })
}

// 收到活动
export function receivedActivity(act_id) {
  return fetch({
    url: `${DOMAIN}/Activity/read/act_id/${act_id}`
  })
}

// 检测用户在线状态
export function userOnlineType(uid) {
  return fetch({
    url: `${DOMAIN}/User/getUserOnlineType/uid/${uid}`
  })
}

// 心跳
export function heartBeat(order ) {
  return fetch({
    method: 'post',
    url: `${DOMAIN}/V2/Message/heartBeat`,
    data: { order  : order   }
  })
}
