import fetch from '@/utils/fetch'

export function getUserList() {
    return fetch({
        url: '//api.hanmaker.com/user/getUserList'
    })
}

export function getUserInfo(id) {
    return fetch({
        url: "//api.hanmaker.com/user/getUserInfo/id/" + id
    })
}

export function searchUser(username) {
    return fetch({
        url: '//api.hanmaker.com/user/getUserList?username=' + username
    })
}

// 获取员工列表按项目组分
export function getUserGroupList() {
    return fetch({
        url: '//api.hanmaker.com/user/getUserGroupList'
    })
}

// 获取组信息
export function getGroupList() {
    return fetch({
        url: '//api.hanmaker.com/User/getGroupList'
    })
}

// 通过员工id获取员工信息
export function getUserListByIds(ids) {
    return fetch({
        method: 'post',
        url: '//api.hanmaker.com//User/getUserListByIds',
        data: {uids: ids}
    })
}

// 获取所有在职员工列表
export function getStaffOptions() {
  return fetch({
    url: "//api.hanmaker.com/Staff/getStaffOptions"
  })
}

// 获取聊天记录
export function getMessageList(id,is_group,page) {
  page = page || 0
  return fetch({
    url:'//api.hanmaker.com/Message/getMessageList?id='+ id + '&is_group='+ is_group + '&page=' + page
  })
}

// 搜索员工群组列表
export function searchUserAndGroup(keywords) {
    return fetch({
        url: '//api.hanmaker.com/user/getSearchList?keywords=' + keywords
    })
}
// 获取最近聊天列表
export function getRecentChatList() {
  return fetch({
      url: '//api.hanmaker.com/Message/getRecentChatList'
    })
}

//获取用户配置
export function getUserConfigList() {
  return fetch({
    url: '//api.hanmaker.com/Message/getClientSetting'
  })
}

