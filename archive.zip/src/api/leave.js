import fetch from '@/utils/fetch'
import { DOMAIN } from '@/api/config'
// 审核请假列表
export function getCheckList() {
  return fetch({
    url: `${DOMAIN}/Leave/check`
  })
}
// 获取请假类型列表
export function getTypes(operation=1) {
  return fetch({
    url: `${DOMAIN}/Leave/getTypes?operation=${operation}`
  })
}
// 提交申请请假信息
export function submitApply(form) {
  return fetch({
    method: 'post',
    url: `${DOMAIN}/Leave/apply`,
    data: form
  })
}
// 用户相关提示警告
export function applyWarn(form) {
  return fetch({
    method: 'post',
    url: `${DOMAIN}/Leave/applyWarn`,
    data: form
  })
}
// 处理审核请假
export function doCheck(form) {
  return fetch({
    method: 'post',
    url: `${DOMAIN}/Leave/doCheck`,
    data: form
  })
}
// 历史列表
export function getHistoryList(page, time_type, type, uid) {
  page = page || 1
  time_type = time_type || 0
  type = type || 0
  uid = uid || 0

  return fetch({
    method: 'post',
    url: `${DOMAIN}/Leave/history?p=` + page,
    data: {
      time_type: time_type,
      type: type,
      uid: uid
    }
  })
}
// 提交手动添加申请
export function submitAddApply(form) {
  return fetch({
    method: 'post',
    url: `${DOMAIN}/Leave/addApply`,
    data: form
  })
}
// 提交修改请假信息
export function submitModApply(form) {
  return fetch({
    method: 'post',
    url: `${DOMAIN}/Leave/modApply`,
    data: form
  })
}
// 用户申请请假信息
export function getUserApply() {
  return fetch({
    url: `${DOMAIN}/Leave/getUserApply`
  })
}
// 获取一条请假信息
export function getOne(id) {
  return fetch({
    url: `${DOMAIN}/Leave/getOne&id=` + id
  })
}
// 删除请假记录
export function deleteLeave(id) {
  return fetch({
    method: "post",
    url: `${DOMAIN}/Leave/deleteLeave`,
    data: { id: id }
  })
}
// 获取个人请假汇总
export function getLeaveUserUsedCount(){
  return fetch({
    url:`${DOMAIN}/V2/Leave/userUsedCount`
  })
}

// 统计个人请假时长次数
export function getCountLeavedHours(time_type) {
  return fetch({
    method:'post',
    url:`${DOMAIN}/Leave/countLeavedHours`,
    data:{time_type:time_type}
  })
}

