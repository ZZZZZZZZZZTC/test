import fetch from '@/utils/fetch';

// 获取所有请假小组
export function getLeaveGroupList() {
    return fetch({
        url: '//api.hanmaker.com/LeaveGroup'
    })
}
// 添加请假小组
export function leaveGroupAdd(form) {
    return fetch({
        url: '//api.hanmaker.com/LeaveGroup/add',
        method: 'post',
        data: form
    })
}
// 删除请假小组
export function leaveGroupDel(id) {
    return fetch({
        method:'post',
        url: '//api.hanmaker.com/LeaveGroup/del',
        data:{id:id}
    })
}
// 编辑请假小组负责人
export function leaveGroupEditLeader(id,first_leader,second_leader) {
    return fetch({
        method: 'post',
        url: '//api.hanmaker.com/LeaveGroup/editLeader',
        data: {
          id:id,
          first_leader:first_leader,
          second_leader:second_leader
        }
    })
}
// 获取小组信息
export function leaveGroupItem(id) {
    return fetch({
        method:'post',
        url: '//api.hanmaker.com/LeaveGroup/item',
        data:{id:id}
    })
}
// 小组添加员工
export function leaveGroupAddStaff(id, uid) {
    return fetch({
        url: '//api.hanmaker.com/LeaveGroup/addStaff',
        method: 'POST',
        data: {
            id:id,
            uid:uid
        }
    })
}
//小组删除员工
export function leaveGroupDelStaff(id, uid) {
    return fetch({
        method:'post',
        url: '//api.hanmaker.com/LeaveGroup/delStaff',
        data:{
            id:id,
            uid:uid
        }
    })
}
