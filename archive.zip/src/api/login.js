import fetch from '@/utils/fetch'

// 登录
export function login(username, password) {
  let data = {
    'account': {
      username:username,
      password:password
    }
  }
  return fetch({
    method: 'post',
    url: '//api.hanmaker.com/Login',
    data: data
  })
}

// ws绑定用户
export function wsBindUser(client_id) {
  let data = {
    client_id: client_id
  }
  return fetch({
    method: "post",
    url: "//api.hanmaker.com/Sockets/bindUid",
    data: data
  })
}
