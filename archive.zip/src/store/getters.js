// export const xxx = state => state.xxx

// 用户相关
export const staff = state => state.user.staff
export const isGuest = state => state.user.isGuest
export const roles = state => state.user.roles
export const roleModule = state =>state.user.role_module
export const isLogin = state => state.user.isLogin
// im
export const heartOrder = state => state.event.heartOrder;
export const isInClient = () => window.hanClient.mounted()
// 所有人列表
export const userList = state => state.chat.userList
// 自己所在群列表
export const groupList = state => state.chat.groupList

// 聊天相关
export const userConfig = state => state.user.config
export const isSendMessage = state => state.chat.isSendMessage
export const hasNewTrayMessage = state => state.status.hasNewTrayMessage
export const stickList = state => state.chat.stickList
export const conversationList = state => state.chat.conversationList
export const shieldConversationList = state => state.chat.shieldConversationList
export const messages = state => state.chat.messages
export const currentChatId = state => state.chat.currentChatId
export const currentConversationRelationship = state => state.chat.currentConversationRelationship
export const currentConversationType = state => state.chat.currentConversationType
export const currentChatUserOnlineType = state => state.chat.currentChatUserOnlineType
export const currentChatName = state =>state.chat.currentChatName
export const currentChatUserInfo = state=>state.chat.currentChatUserInfo
export const currentChatGroupInfo = state=> state.chat.currentChatGroupInfo
export const hasMoreMessage = state=> state.status.hasMoreMessage
// 发送方式
export const sendMessageWays = state => state.status.sendMessageWays

// 通讯录信息处理
export const contactUserId = state => state.info.contactUserId
export const contactGroupId = state => state.info.contactGroupId
export const contactInfoType = state => state.info.contactInfoType
export const contactInfoFrom = state => state.info.contactInfoFrom
// 群组创建等操作信息同步
export const contactChangeSync = state =>state.status.contactChangeSync
// 配置设置相关

// 文件上传下载相关
export const fileUploadMq = state => state.chat.fileUploadMq;
export const fileDownloadMq = state => state.chat.fileDownloadMq;


// 弹窗相关
export const transpondData = state =>state.status.transpondData // 转发数据
export const transpondShow = state=> state.status.transpondShow // 转发展示
