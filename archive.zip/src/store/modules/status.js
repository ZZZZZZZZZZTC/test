import * as types from '../mutations-types'
import {numToMsgType} from '@/utils/utils'
import {unixDateFormat} from '@/filters/index'
const state = {
    // 创建群组同步通讯录群组列表
    contactChangeSync:false,
    sendMessageWays: '1',//1回车2ctrl+enter发送
    hasNewTrayMessage:false,
    transpondData: {}, // 转发信息
    transpondShow:false, // 转发展示
    hasMoreMessage:true  // 是否有更多数据
}

const mutations = {
  [types.CONTACT_CHANGE_SYNC](state,payload){
    state.contactChangeSync = payload
  },
  [types.SET_SENDMESSAGE_WAYS](state,payload){
    state.sendMessageWays = payload
  },
  [types.READ_TRAYMESSAGE](state,payload){
    state.hasNewTrayMessage = payload
  },
  [types.RECEIVE_TRAYMESSAGE](state,payload){
    state.hasNewTrayMessage = payload
  },
  // 转发
  [types.TRANSPOND_MESSAGE_INFO](state, payload) {
    state.transpondData = payload
  },
  // 转发弹窗的显示与关闭
  [types.TRANSPOND_SHOW_INFO](state,payload){
    state.transpondShow = payload
  },
  // 会话是否有更老消息
  [types.SET_CONVERSATION_HAS_MORE_MESSAGE_STATUS](state,payload){
    state.hasMoreMessage = payload
  },
}

const actions = {
  // 改变同步状态
  setContactChangeSync({commit,state},payload){
    commit(types.CONTACT_CHANGE_SYNC,payload)
  },
  // 设置消息发送方式(默认回车发送)
  setSendMessageWays({commit,state},payload){
    commit(types.SET_SENDMESSAGE_WAYS,payload)
  },
  // 转发消息处理
  getTransPondData({commit, dispatch, getters, state}, payload) {
    let transData = {
      content:{},
      type:null
    }
    let type = numToMsgType(payload.type);
    // 文档数据
    transData.type = payload.type
    transData.sentStatus = 1
    if(type ==='RC:ImgTextMsg'){
      switch (payload.fromPath){
        // 从搜索文档传递过来的文档数据
        case 'searchDocs':
          transData.content = payload.content
          transData.objectName =  type
          break;
        case 'chatFrame':
          transData.content = payload.content
          transData.objectName = type
          break;
        case "msgRecord":
          console.log(payload,'0980980980')
          transData.content = payload.content.content
          transData.objectName = type
          break;
      }
    }

    // 文件数据
    if (type === 'RC:FileMsg') {
      switch (payload.fromPath){
        case 'chatFrame':
          transData.content = payload.content.content
          transData.from_name = payload.content.full_name || payload.content.name;
          transData.id = payload.content.from_id;
          transData.objectName = payload.content.objectName || type;
          transData.relationship = payload.content.relationship || payload.relationship;
          break;
        case 'msgRecord':
          console.log(payload,'6666666666')
          transData.content = payload.content.content
          transData.from_name = payload.content.full_name;
          transData.id = payload.content.from_id;
          transData.objectName = payload.content.msg_type_str || type;
          transData.relationship = payload.content.relationship || payload.relationship;
          break;
        case 'fileFrame':
          transData.content =payload.content.content
          transData.from_name = payload.content.full_name;
          transData.id = payload.content.from_id;
          transData.objectName = type;
          transData.relationship = payload.content.relationship || payload.relationship;
          break
      }
    }
    console.log(transData,'转送过来的信息')
    commit(types.TRANSPOND_MESSAGE_INFO, transData)
  },

  // 设置转发弹窗的关闭与展示
  setTransPondShowToggle({commit, state}, payload){
    commit(types.TRANSPOND_SHOW_INFO,payload)
  }

}

export default {
  state,
  mutations,
  actions
}
