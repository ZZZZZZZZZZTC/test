import {userOnlineType} from '@/api/event'
import {
  createConversation,
  getStickTopChat,
  syncData,
  getSyncData,
  publishChatMsg,
  updateSendType,
  updateChatMsgType,
  getMessageListNew,
  readAllMessage,
} from '@/api/chat'
import {getUploadImgToken} from '@/api/upload'
import {getUserInfo} from '@/api/staff'
import * as types from '../mutations-types'
import {
  structRelationship, relationshipToType, parseChatText,
  numToMsgType, genMsgUId, msgTypeToNum, uploadItem, getSuffix,unescapeHTML,HTMLDecode} from '@/utils/utils'
import {getGroupOnlineStatus, groupInfo} from '@/api/group'

const state = {
  userList: [],
  groupList: [],
  stickerList: [],
  conversationList: [],
  shieldConversationList: [],
  messages: [],
  currentChatName: '',
  currentChatId: 0,
  currentConversationRelationship: '',
  currentConversationType: '',
  currentChatUserOnlineType: {
    info: '',
    type: 0
  },
  currentChatUserInfo: {
    avatar: '',
    full_name: '',
    team_name: '',
    job_name: '',
    part_name: '',
    mobile: '',
    working_years: ''
  },
  currentChatGroupInfo: {
    onlineCount: 0,
    members: [],
    avatar: '',
    group_name: ''
  },
  isSendMessage: false,
  chatUploadMq: [],
  fileUploadMq: [],
  fileDownloadMq: [],
  fileCancelMq: []
};
const getters = {};
const mutations = {
  [types.FILE_UPLOAD_MG](state, payload) {
    if (Array.isArray(payload)) {
      state.fileUploadMq = payload
    } else {
      state.fileUploadMq.forEach((val, key) => {
        if (val.uuid == payload.index) {
          payload.self.$set(val, 'process', payload.complete);
          payload.self.$set(val, 'uploadFlag', payload.val);
        }
      })
    }
  },
  [types.FILE_DOWNLOAD_MQ](state, payload) {

  },
  [types.CHAT_SAVE_USER_INFORMATION](state, payload) {
    state.userList = payload
  },
  [types.CHAT_SAVE_GROUP_INFORMATION](state, payload) {
    state.groupList = payload
  },
  [types.CHAT_CREATE_NEW_CONVERSATION](state, payload) {
    let Index = state.stickerList.findIndex((v) => {
      return v.uid == payload
    });
    if (Index == -1) {
      payload.ConversationToTop = false
    } else {
      payload.ConversationToTop = true
    }
    state.conversationList.push(payload)
  },
  [types.INIT_CONVERSATION_LIST](state, payload) {
    let list = payload;
    list.map((item) => {
      let isExist = state.conversationList.some((v) => {
        return v.uid == item.uid
      })
      if (isExist) {

      } else {
        state.conversationList.push(item)
      }
    })
  },
  [types.UPDATE_CONVERSATION_LIST](state, payload) {
    payload.map((item) => {
      try {
        item = JSON.parse(item)
      } catch (e) {

      }
      let obj = {};
      obj.avatar = item.portraitUrl;
      obj.full_name = item.conversationTitle;
      obj.content = '';
      obj.sentTime = item.sentTime;
      obj.relationship = item.relationship;
      obj.uid = item.targetId;
      obj.ConversationType = relationshipToType(item.relationship);
      obj.ConversationToTop = item.isTop;
      obj.unreadMessageCount = item.unreadMessageCount;
      obj.isDisturb = state.shieldConversationList.some((value) => {
        return obj.uid == value
      })
      if (obj.uid > 0 || obj.uid !== -4) {
        let isExist = state.conversationList.some((v) => {
          return v.uid == obj.uid
        })
        if (isExist) {

        } else {
          state.conversationList.push(obj)
        }
      }
    })
  },
  [types.SET_STICK_CONVERSATION_LIST](state, payload) {
    if (payload.type === 'add') {
      state.stickerList.push(payload.uid)
      let Index = state.conversationList.findIndex((item) => {
        return item.uid == payload.uid
      })
      if (Index !== -1) {
        state.conversationList[Index].ConversationToTop = true
      }
    } else if (payload.type === 'set') {
      payload.map((item) => {
        state.stickerList.push(item.uid)
      })
    } else if (payload.type === 'del') {
      let Index = state.stickerList.findIndex((v) => {
        return v.uid === payload.uid
      })
      state.stickerList.splice(Index, 1)
      let stickIndex = state.conversationList.findIndex((item) => {
        return item.uid == payload.uid
      })
      if (stickIndex !== -1) {
        state.conversationList[stickIndex].ConversationToTop = false
      }
    }
  },
  [types.SET_CONVERSATION_LIST](state, payload) {
    let Index = state.conversationList.findIndex((v) => {
      return v.uid === payload.uid
    });
    if (Index === -1 && payload.type !== 'update') {
      return
    }
    if (payload.type === 'update') {
      let item = {
        avatar: payload.data.avatar,
        group_name: payload.data.group_name,
        id: payload.uid,
        owner_id: payload.data.owner_id
      }
      const groupIndex = state.groupList.findIndex((value) => {
        return value.id == payload.uid
      })
      if (groupIndex !== -1) {
        state.groupList.splice(groupIndex, 1, item)
      } else {
        state.groupList.push(item)
      }
    } else if (payload.type === 'mod') {
      let Info = payload;
      if (Info.avatar) {
        state.conversationList[Index].avatar = Info.avatar
        if (payload.uid == state.currentChatId) {
          state.currentChatGroupInfo.avatar = Info.avatar
        }
      } else if (Info.group_name) {
        state.conversationList[Index].full_name = Info.group_name;
        if (payload.uid == state.currentChatId) {
          state.currentChatGroupInfo.group_name = Info.group_name;
          state.currentChatName = Info.group_name;
        }
      }
    } else if (payload.type === 'set') {
      state.conversationList[Index] = payload
    } else if (payload.type === 'del') {
      state.conversationList.splice(Index, 1)
      if (payload.uid == state.currentChatId) {
        state.currentChatName = '';
        state.currentChatId = 0
      }
    } else if (payload.type === 'add'){
      const pushItem = {
        avatar: payload.data.avatar,
        group_name: payload.data.group_name,
        id: payload.uid,
        owner_id: payload.data.owner_id
      }
      state.groupList.push(pushItem)
    }
  },
  [types.CHAT_RESET_CURRENTCHATINFO](state, payload) {
    state.currentChatId = 0;
    state.currentConversationType = '';
    state.currentChatName = '';
    state.currentConversationRelationship = '';
    state.currentChatUserOnlineType = {
      info: '',
      type: 0
    };
    state.currentChatUserInfo = {
      avatar: '',
      team_name: '',
      job_name: '',
      part_name: '',
      mobile: '',
      working_years: ''
    };
    state.currentChatGroupInfo = {
      onlineCount: 0,
      members: []
    };
  },
  [types.CHAT_CHANGE_CONVERSATION_INFO](state, payload) {
    state.currentChatName = payload.full_name;
    state.currentChatId = payload.uid;
    state.currentConversationRelationship = payload.relationship;
    state.currentConversationType = payload.ConversationType;
    let obj = state.conversationList.find((v) => {
      return payload.uid == v.uid
    })
    obj.unreadMessageCount = 0
    if (payload.ConversationType != 'U') {
      state.currentChatUserOnlineType = {
        info: '',
        type: 0
      }
    } else {

    }
    // todo:切换会话限制回话消息条数
    // let messageList = state.messages.find((item)=>{
    //   return item.targetId == payload.uid
    // });
    // if(messageList.messageList.length>300){
    //   messageList.messageList
    // }
  },
  [types.CHAT_RESET_CURRENTCHATUSERINFO](state, payload) {
    state.currentChatUserInfo = payload
    //同步更新会话列表单聊信息
    let obj = state.conversationList.find((v) => {
      return payload.uid == v.uid
    })
    obj.full_name = payload.full_name;
    obj.avatar = payload.avatar;
  },
  [types.CHAT_RESET_CURRENTCHATGROUPINFO](state, payload) {
    state.currentChatGroupInfo = payload
    //同步更新群聊信息
    let obj = state.conversationList.find((v) => {
      return payload.uid == v.uid
    });
    obj.avatar = payload.avatar;
    obj.full_name = payload.group_name;
  },
  [types.CHAT_CONVERSATION_CHANGE_SEND_STATUS](state, payload) {
    state.isSendMessage = payload
  },
  [types.CHAT_ADD_NEW_MESSAGE](state, payload) {
    let Index = state.messages.findIndex((v) => {
      return v.targetId == payload.targetId
    });
    if (Index !== -1) {
      let obj = '';
      if (payload.messageId) {
        obj = state.messages[Index].messageList.find((v) => {
          return v.messageId == payload.messageId
        })
      } else {
        obj = state.messages[Index].messageList.find((v) => {
          return v.messageUId == payload.messageUId
        })
      }
      //有就更新,没有推入
      if (obj) {
        obj.content = payload.content;
        obj.sentStatus = payload.sentStatus;
        obj.messageId = payload.messageId;
      } else {
        state.messages[Index].messageList.push(payload)
        if(state.messages[Index].messageList.length>100){
          state.messages[Index].messageList.shift()
        }
      }
    } else {
      //全新的会话消息
      state.messages.push({
        targetId: payload.targetId,
        messageList: [payload]
      });
      // state.messages[Index].messageList.push(payload)
    }
    // 新信息数据
    // let odata = HTMLDecode(latestMessageContent);
    // odata = odata.replace(/<(img|IMG)(.*?)>/,'[图片]');
    // odata = odata.replace(/<[^<>]+?>/g,'');
    // let m = {
    //   uuid: messageInfo.relationship,
    //   userName: messageInfo.full_name,
    //   msgCount: messageInfo.unreadMessageCount.toString(),
    //   logoUrl: messageInfo.avatar,
    //   currentUser:message.user_name,
    //   chatData:odata,
    //   extra: '{"uid": "' + messageInfo.uid.toString() + '", "relationship": "' + messageInfo.relationship + '"}'
    // }
    // if(!message.self){
    //   window.hanClient.haveNewMsg(m)
    // }
  },
  [types.CHAT_UPDATE_MESSAGE_INFO](state, payload) {
    // 获取当前消息列表索引
    let Index = state.messages.findIndex((v) => {
      return v.targetId == payload.targetId
    })
    switch (payload.status) {
      case 'set' :

        break;
      case 'update':
        if (Index !== -1) {
          let obj = '';
          if (payload.messageId) {
            obj = state.messages[Index].messageList.find((v) => {
              return v.messageId == payload.messageId
            })
          } else {
            obj = state.messages[Index].messageList.find((v) => {
              return v.messageUId == payload.messageUId
            })
          }
          if (obj) {
            obj.content = payload.content;
            obj.sentStatus = payload.sentStatus;
            obj.messageId = payload.messageId;
            obj.messageUId = payload.messageUId;
            if (payload.complete) {
              obj.complete = payload.complete
            }
          } else {
            state.messages[Index].messageList.push(payload)
          }
        } else {
          // 没有消息列表创建
          state.messages.push({
            targetId: payload.targetId,
            messageList: [payload]
          })
        }
        break;
      case 'error':
        if (Index !== -1) {
          let obj = state.messages[Index].messageList.find((v) => {
            return v.messageUId == payload.messageUId
          })
          if (obj) {
            obj.sentStatus = 10
          }
        }
        break;
      default:
        break;
    }
  },
  [types.CHAT_REVOKE_NEW_MESSAGE](state, payload) {
    let messagesObj = state.messages.find((o) => {
      return o.targetId == payload.currentChatId
    });
    if (messagesObj) {
      messagesObj.messageList.splice(payload.index, 1);
    }
  },
  [types.CHAT_ADD_HISTORY_MESSAGE](state, payload) {
    payload.item.content = unescapeHTML(payload.item.content)
    payload.item.senderUserId = payload.item.from_id;
    payload.item.sentStatus = payload.item.send_type;
    payload.item.name = payload.item.full_name
    switch (payload.item.msg_type) {
      case '0':
        try {
          payload.item.content = JSON.parse(payload.item.content);
        } catch (e) {
        }
        payload.item.objectName = 'RC:TxtMsg'
        break;
      case '7':
        payload.item.objectName = 'RC:InfoNtf'
        break;
      case '1':
        payload.item.content = JSON.parse(payload.item.content);
        payload.item.objectName = 'RC:ImgMsg'
        break;
      case '3':
        try {
          payload.item.content = JSON.parse(payload.item.content);
        } catch (e) {
        }
        payload.item.objectName = 'RC:VcMsg'
        break;
      case '2':
        payload.item.content = JSON.parse(payload.item.content);
        payload.item.objectName = 'RC:FileMsg'
        break;
      case '4':
        if (payload.item.version == '0') {
          try {
            payload.item.content = JSON.parse(payload.item.content);
            payload.item.content.extra = JSON.parse(payload.item.content.extra);
            payload.item.content.extra.cont = payload.item.content.url
            payload.item.objectName = 'RC:ImgTextMsg'
          } catch (e) {
            payload.item.msg_type = '0'
            payload.item.content = `<div>文档消息已损坏，无法查看</div>`
            payload.item.objectName = 'RC:TxtMsg'
          }
        } else {
          payload.item.content = JSON.parse(payload.item.content);
          try {
            payload.item.content.extra = JSON.parse(payload.item.content.extra);
            payload.item.content.imgUrl = payload.item.content.imageUri
          } catch (e) {
          }
          payload.item.objectName = 'RC:ImgTextMsg'
        }
        break;
      case '13':
        if (payload.item.content != '') {
          payload.item.content = JSON.parse(payload.item.content);
        }
        payload.item.objectName = 'HC:StickerMsg'
        break;
      case '14':
        try {
          payload.item.content = JSON.parse(payload.item.content);
        } catch (e) {
        }
        payload.item.objectName = 'HC:TextImage'
        break;
      case '':
        payload.item.objectName = ''
        break;

    }
    let Index = state.messages.findIndex((v) => {
      return v.targetId == payload.targetId
    })
    if (Index === -1) {
      let data = {
        targetId: payload.targetId,
        messageList: [payload.item]
      }
      state.messages.push(data)
    } else {
      state.messages[Index].messageList.unshift(payload.item)
    }
  },
  [types.INIT_SHIELD_GROUP_LIST](state, payload) {
    state.shieldConversationList = payload
  },
  [types.ADD_SHIELD_GROUP_ITEM](state, payload) {
    let Index = state.shieldConversationList.findIndex((v) => {
      return v == payload
    })
    if (Index == -1) {
      state.shieldConversationList.push(payload)
    }
    let shieldIndex = state.conversationList.findIndex((item) => {
      return item.uid == payload.uid
    })
    if (shieldIndex !== -1) {
      state.conversationList[shieldIndex].isDisturb = true
    }
  },
  [types.DEL_SHIELD_GROUP_ITEM](state, payload) {
    let Index = state.shieldConversationList.findIndex((v) => {
      return v == payload
    })
    if (Index != -1) {
      state.shieldConversationList.splice(Index, 1)
    }
    let shieldIndex = state.conversationList.findIndex((item) => {
      return item.uid == payload.uid
    })
    if (shieldIndex !== -1) {
      state.conversationList[shieldIndex].isDisturb = false
    }
  },
  [types.UPDATE_CONVERSATION_LASTMESSAGE_INFO](state, payload) {
    let conversation = state.conversationList.find((v) => {
      return v.uid == payload.targetId
    })
    if(payload.objectName == "RC:InfoNtf"){
      conversation.sentTime = payload.timeline;
      conversation.content = payload.content;
      return
    }
    if(payload.senderUserId < 0){
      conversation.sentTime = payload.timeline;
      conversation.content = payload.content;
      return
    }
    if (payload.objectName != "RC:CmdMsg") {
      conversation.sentTime = payload.timeline;
      if (payload.senderUserId != payload.staff.uid && payload.targetId != state.currentChatId) {
        conversation.unreadMessageCount++;
      }
    }
    let userInfo = state.userList.find((v) => {
      return v.uid == payload.senderUserId
    })
    let name = '';
    if (payload.conversationType == 3) {
      if (userInfo) {
        name = userInfo.full_name + ': '
      }
    }
    switch (payload.objectName) {
      case 'HC:TextImage':
        let content = '';
        for (let i = 0; i < payload.content.content.length; i++) {
          for (let z = 0; z < payload.content.content[i].length; z++) {
            if (payload.content.content[i][z].type === 0) {
              content += payload.content.content[i][z].src
            } else {
              content += '[图片]'
            }
          }

        }
        conversation.content = name + content;
        break;
      case 'RC:TxtMsg':
        conversation.content = name + payload.content.content;
        break;
      case 'RC:ImgMsg':
        conversation.content = name + '[图片]'
        break;
      case 'HC:StickerMsg':
        conversation.content = name + '[表情]'
        break;
      case 'RC:FileMsg':
        conversation.content = name + '[文件]'
        break;
      case 'RC:InfoNtf':
        conversation.content = name + '[提示]'
        break;
      case 'RC:RcCmd':
        conversation.content = name + '[撤回消息]'
        break;
      case 'RC:VcMsg':
        conversation.content = name + '[语音消息]'
        break;
      case 'RC:ImgTextMsg':
        conversation.content = name + '[图文消息]'
        break;
      case "RC:CmdMsg":
        break;
      default:
        conversation.content = ''
        break;
    }
    // 新信息数据
    let index = state.shieldConversationList.findIndex((val) => {
      return val == payload.targetId;
    })
    if(index == -1){
      if(payload.staff.uid != payload.senderUserId){
        let data = conversation.content;
        if(conversation.content.length > 100){
          data = (conversation.content.substr(0,100) + '...');
        }
        let odata = HTMLDecode(data);
        odata = odata.replace(/<(img|IMG)(.*?)>/,'[图片]');
        odata = odata.replace(/<[^<>]+?>/g,'');
        let underRead = String(conversation.unreadMessageCount);
        let avatar = payload.conversationType == 3 ? conversation.avatar:payload.avatar;
        if(window.hanClient.isMinimized()){
          underRead = conversation.unreadMessageCount != 0 ? String(conversation.unreadMessageCount):'1';
        }
        let m = {
          uuid: payload.targetId,
          userName: conversation.full_name,
          msgCount: underRead,
          currentUser:payload.staff.full_name,
          logoUrl: avatar,
          chatData:odata,
          extra: '{"id": "' + payload.targetId.toString() + '", "avatar": "' + payload.avatar + '","full_name": "' + payload.name + '"}'
        }
        window.hanClient.haveNewMsg(m)
      }
    }
  },
  [types.UPDATE_CONVERSATION_GROUP_DEFAULT](state, payload) {
    state.currentChatGroupInfo.group_name = payload.group_name
    state.currentChatGroupInfo.avatar = payload.avatar
    state.currentChatGroupInfo.members = payload.members
    state.currentChatName = payload.group_name
    //同步更新群聊信息
    let obj = state.conversationList.find((v) => {
      return payload.uid == v.uid
    });
    obj.avatar = payload.avatar;
    obj.full_name = payload.group_name
  },
  [types.SYNC_CONVERSATION_CHAT_SENTSTATUS](state, payload) {
    console.log(payload)
    let message = state.messages.find((v) => {
      return v.uid = payload.targetId
    });
    console.log(2222)
    if(message){
      let msgList = message.messageList
      msgList.map((item)=>{
        if(item.senderUserId != payload.uid){
          if(item.sentStatus !=4){
            console.log(item)
            let id = item.messageId ||item.id
            if(item.objectName=='RC:VcMsg'||item.objectName=='RC:InfoNtf'||item.objectName=='RC:FileMsg'){

            }else{
              updateChatMsgType(id, 4)
                .then(response => {
                  console.log('更新已读状态',response)
                })
                .catch(error => {
                  console.log(error)
                })
            }

          }
        }
      })
    }
  },
  [types.ADD_CANCEL_CHAT_UPLOAD](state, payload) {
    state.fileCancelMq.push(payload)
  },
  [types.DELETE_CONVERSATION_LASTMESSAGE_INFO](state, payload) {
    let Index = state.messages.findIndex((v) => {
      return v.targetId == payload.targetId
    });
    let msgIndex = state.messages[Index].messageList.findIndex((v) => {
      return v.messageUId == payload.messageUId
    });
    if (msgIndex !== -1) {
      state.messages[Index].messageList.splice(msgIndex, 1)
    }
    //同步删除 取消列表
    let cancelIndex = state.fileCancelMq.findIndex((v) => {
      return v == payload.messageUId;
    })
    if (cancelIndex !== -1) {
      state.fileCancelMq.splice(cancelIndex, 1)
    }
  },
  [types.ADD_CONVERSATION_LIST_ITEM](state, payload) {
    let list = payload;
    list.map((item) => {
      let obj = {};
      obj.avatar = item.avatar;
      obj.full_name = item.full_name;
      obj.content = '';
      obj.sentTime = item.timeline;
      obj.relationship = item.relationship;
      obj.uid = item.uid;
      obj.ConversationType = relationshipToType(item.relationship);
      obj.ConversationToTop = true;
      if (item.unreadMessageCount) {
        obj.unreadMessageCount = item.unreadMessageCount;
      } else {
        obj.unreadMessageCount = 0;
      }
      obj.isDisturb = state.shieldConversationList.some((v) => {
        return obj.uid == v
      });
      if (obj.uid > 0 || obj.uid !== -4) {
        // let isExist = state.conversationList.some((v)=>{
        //   return v.uid = obj.uid
        // })
        // if(isExist){
        //
        // }else{
        //
        // }
        if (item.from_id) {
          state.conversationList.push(obj)
        }
      }
    })
  },
  [types.ADD_USERLIST_ITEM](state, payload) {
    state.userList.push(payload)
  },
  [types.CHAT_SET_USER_ONLINE_TYPE](state, payload) {
    state.currentChatUserOnlineType = payload
  },
  [types.UPDATE_CONVERSATION_MESSAGE_INFO](state, payload) {
    if (payload.type == 5) {
      let MsgList = state.messages.find((item) => {
        return item.targetId == payload.targetId
      })
      let conversation = state.conversationList.find((v) => {
        return v.uid == payload.targetId
      })
      let msgIndex = MsgList.messageList.findIndex((item) => {
        return item.messageId == payload.msgId
      })
      let name = MsgList.messageList[msgIndex].name;
      MsgList.messageList[msgIndex].content = name + '撤回了一条消息';
      MsgList.messageList[msgIndex].objectName = 'RC:RcCmd'
      let tempObj =  Object.assign(MsgList.messageList[msgIndex]);
      tempObj.sentStatus = payload.type;
      MsgList.messageList.splice(msgIndex,1,tempObj);
      // MsgList.messageList.splice(msgIndex, 1)
    }else if(payload.type == 4){
      let MsgList = state.messages.find((item) => {
        return item.targetId == payload.targetId
      })
      let msgItemIndex = MsgList.messageList.findIndex((item) => {
        return item.messageId == payload.msgId
      })
      let tempObj =  Object.assign(MsgList.messageList[msgItemIndex]);
      tempObj.sentStatus = payload.type;
      MsgList.messageList.splice(msgItemIndex,1,tempObj);
    }
  },
  [types.LOGINOUT_CLEARN_CONVERSION_LIST](state, payload) {
    state.conversationList = []
    state.stickerList = []
    state.shieldConversationList = []
    state.currentChatUserOnlineType = {
      inf0: '',
      type: 0
    }
  }
};
const actions = {
  setFileUploadMg({commit, dispatch}, payload) {
    commit(types.FILE_UPLOAD_MG, payload)
  },
  getUserList({commit, dispatch}, payload) {
    commit(types.CHAT_SAVE_USER_INFORMATION, payload)
  },
  getGroupList({commit, dispatch}, payload) {
    commit(types.CHAT_SAVE_GROUP_INFORMATION, payload)
  },
  initConversationList({commit, dispatch, getters, state}, payload) {
    getSyncData('hc_conversation_list')
      .then(response => {
        if (response.status === 200) {
          if (response.data === null) {
            getSyncData('hc_im_conversation_list')
              .then(response => {
                if (response.status === 200) {
                  let conversationList = response.data;
                  let imConversationList = [];
                  for (let i = 0; i < conversationList.length; i++) {
                    let obj = {};
                    obj.avatar = conversationList[i].avatar;
                    obj.full_name = conversationList[i].full_name;
                    obj.content = '';
                    obj.sentTime = conversationList[i].sentTime;
                    obj.relationship = conversationList[i].relationship;
                    obj.uid = conversationList[i].uid;
                    obj.ConversationType = relationshipToType(conversationList[i].relationship);
                    obj.ConversationToTop = conversationList[i].isStickTop;
                    obj.unreadMessageCount = conversationList[i].unreadMessageCount;
                    obj.isDisturb = state.shieldConversationList.some((v) => {
                      return obj.uid == v
                    });
                    if (obj.uid > 0 || obj.uid !== -4) {
                      imConversationList.push(obj)
                    }
                  }
                  commit(types.INIT_CONVERSATION_LIST, imConversationList);
                  dispatch('conversationStorage', imConversationList);
                }
              })
              .catch(error => {
                console.log(error)
              })
          } else {
            const arr = JSON.parse(response.data.conversation_list);
            commit(types.UPDATE_CONVERSATION_LIST, arr)
          }
        }
      })
      .catch(error => {
      })
  },
  addChatMessage({commit, dispatch, getters, state}, payload) {
    console.log(payload,11)
    let tempObj = payload;
    try {
      tempObj = JSON.parse(tempObj)
    } catch (e) {
      console.log('payload解析错误1', e)
      tempObj = payload;
    }
    console.log(tempObj)

    // 下班弹窗消息
    if (tempObj.senderUserId == -1) {
            let strdata = {tpl_type: 4}
            strdata = JSON.stringify(strdata)
            let m = {
              strUrl: './background/notify/index.html',
              strData: strdata,
              width: '300',
              height: '200'
            }
            window.hanClient.runPopWindow(m);
            return
    }
    if (tempObj.objectName == 'RC:CmdMsg') {
      let data = Object.assign(tempObj.content)
      try {
        data = JSON.parse(data)
      } catch (e) {
        console.log('parse Error', e)
        data = tempObj.content
      }
      let name = data.name;
      switch (name) {
        case 'UpdateRelationshipType':
          switch (data.type) {
            case 1:
              //置顶
              let adddata = {
                uid: data.targetId,
                type: 'add'
              };
              commit(types.SET_STICK_CONVERSATION_LIST, adddata);
              dispatch('conversationStorage', state.conversationList);
              break;
            case 2:
              //免打扰
              commit(types.ADD_SHIELD_GROUP_ITEM, data.targetId);
              dispatch('conversationStorage', state.conversationList);
              break;
            case 3:
              //取消置顶
              let deldata = {
                uid: data.targetId,
                type: 'del'
              };
              commit(types.SET_STICK_CONVERSATION_LIST, deldata);
              dispatch('conversationStorage', state.conversationList);
              break;
            case 4:
              //取消免打扰
              commit(types.DEL_SHIELD_GROUP_ITEM, data.targetId)
              dispatch('conversationStorage', state.conversationList);
              break;
            default:
              break;
          }
          break;
        case 'GroupNotice':
          console.log(data.data.type)
          switch (data.data.type) {
            case 1:
              //有人加入群
              break;
            case 2:
              //有人退群
              break;
            case 3:
              //我被踢出群
              let delData = {
                uid: data.groupid,
                type: 'del'
              }
              commit(types.SET_CONVERSATION_LIST, delData);
              dispatch('conversationStorage', state.conversationList);
              break;
            case 4:
              // 群解散
              let dissData = {
                uid: data.groupid,
                type: 'del'
              }
              commit(types.SET_CONVERSATION_LIST, dissData);
              dispatch('conversationStorage', state.conversationList);
              break;
            case 5:
              //被拉入群
              groupInfo(data.data.target_id)
                .then(response => {
                  if (response.status === 200) {
                    let info = {
                      uid: data.data.target_id,
                      type: 'update',
                      data: response.data
                    }
                    commit(types.SET_CONVERSATION_LIST, info)
                  }
                })
                .catch(error => {
                  console.log(error)
                });
              break;
            default:
              break;
          }
          break;
        case 'ModifyGroupInformation':
          groupInfo(data.groupid)
            .then(response => {
              if (response.status === 200) {
                let info = {
                  uid: data.groupid,
                  type: 'update',
                  data: response.data
                }
                commit(types.SET_CONVERSATION_LIST, info)
                dispatch('conversationStorage', state.conversationList);
              }
            })
            .catch(error => {
              console.log(error)
            })
          break;
        case 'UpdateSendType':
          let msgStatus = data.data.send_type;
          let msgId = data.data.messageId;
          let targetId = 0
          if (data.data.target_id < 1000000) {
            if (data.data.target_id == getters.staff.uid) {
              targetId = data.data.sender_id
            }else{
              targetId = data.data.target_id
            }
          } else {
            targetId = data.data.target_id
          }
          let upDataMsg = {
            type: msgStatus,
            msgId: msgId,
            targetId: targetId,
            data:data
          }
          if (msgStatus > 0) {
            commit(types.UPDATE_CONVERSATION_MESSAGE_INFO, upDataMsg)
          }
          break;
        case 'StickCMD':
          break;
        case 'SyncUnReadMsg':
          break;
        case 'AddGroupInfo':
          groupInfo(data.data.targetId)
            .then(response => {
              if (response.status === 200) {
                let info = {
                  uid: data.data.targetId,
                  type: 'update',
                  data: response.data
                }
                commit(types.SET_CONVERSATION_LIST, info)
              }
            })
            .catch(error => {
              console.log(error)
            })
          break;
        case 'birthCMD':
          let strData = {
            tpl_type: 5,
            full_name: data.data.full_name,
            head_img: data.data.head_img
          }
          strData = JSON.stringify(strData)
          let m = {
            strUrl: './background/notify/index.html',
            strData: strData,
            width: '390',
            height: '291'
          }
          window.hanClient.runPopWindow(m)
          break;
        case 'RecallCommandMessage':
          break;
        case 'ModGroupInfo':
          let modInfo = {
            uid: data.data.id,
            group_name: data.data.group_name,
            avatar: data.data.avatar,
            type: 'mod'
          }
          commit(types.SET_CONVERSATION_LIST, modInfo);
          dispatch('conversationStorage', state.conversationList);
          break;
        case 'DismissGroup':
          let delData = {
            uid: data.data.targetId,
            type: 'del'
          }
          commit(types.SET_CONVERSATION_LIST, delData);
          dispatch('conversationStorage', state.conversationList);
          break;
      }
      return
    }
    try {
      tempObj.content = JSON.parse(tempObj.content)
    } catch (e) {
      console.log('payload content解析错误', e)
      tempObj.content = payload.content
    }
    let Index = state.conversationList.findIndex((v) => {
      return v.uid == tempObj.targetId
    });
    // 判断目标会话是否已在聊天会话列表
    if (tempObj.conversationType == 1) {
      let sid = tempObj.senderUserId;
      if (sid != getters.staff.uid) {
        tempObj.targetId = sid
      }
      if(state.currentChatId == tempObj.targetId&&sid!=getters.staff.uid){
        updateChatMsgType(tempObj.messageId, 4)
          .then(response => {})
          .catch(error => {
            console.log(error)
          })
      }
    }
    if (Index === -1) {
      let obj = {};
      if (tempObj.conversationType == 1) {
        let hasUser = state.userList.findIndex((item) => {
          return item.uid == tempObj.targetId;
        })
        if (hasUser != -1) {
          obj = Object.assign({}, state.userList.find((info) => {
            return info.uid == tempObj.targetId;
          }));
          obj.isSysCreated = true;
          dispatch('createNewConversation', obj)
        } else {
          getUserInfo(tempObj.targetId)
            .then(response => {
              if (response.status == 200) {
                let data = response.data;
                let pushData = {
                  avatar: data.avatar,
                  big_img: data.big_img,
                  full_name: data.full_name,
                  team_name: data.team_name,
                  job_name: data.job_name,
                  part_name: data.part_name,
                  mobile: data.mobile,
                  working_years: data.working_years,
                  uid: tempObj.targetId
                };
                commit(types.ADD_USERLIST_ITEM, pushData)
                let userInfo = state.userList.find((v) => {
                  return v.uid == tempObj.senderUserId
                })
                tempObj.avatar = userInfo.avatar;
                tempObj.name = userInfo.full_name;
                commit(types.CHAT_ADD_NEW_MESSAGE, tempObj);
                tempObj.staff = Object.assign(getters.staff);
                commit(types.UPDATE_CONVERSATION_LASTMESSAGE_INFO, tempObj)
              }
            })
            .catch(error => {

            })
          return
        }
      } else if (tempObj.conversationType == 3) {
        let hasGroup = state.groupList.findIndex((item) => {
          return item.id == tempObj.targetId;
        })
        if (hasGroup != -1) {
          obj = Object.assign({}, state.groupList.find((v) => {
            return v.id == tempObj.targetId;
          }));
          obj.isSysCreated = true;
          dispatch('createNewConversation', obj)
        }
      } else if (tempObj.conversationType == 7) {
        return
      }
    }
    if (tempObj.objectName == 'RC:InfoNtf') {
      tempObj.content = tempObj.content.message
      commit(types.CHAT_ADD_NEW_MESSAGE, tempObj);
      tempObj.staff = Object.assign(getters.staff);
      commit(types.UPDATE_CONVERSATION_LASTMESSAGE_INFO, tempObj)
      return
    }
    let userInfo = state.userList.find((v) => {
      return v.uid == tempObj.senderUserId
    })
    tempObj.avatar = userInfo.avatar;
    tempObj.name = userInfo.full_name;
    commit(types.CHAT_ADD_NEW_MESSAGE, tempObj);
    tempObj.staff = Object.assign(getters.staff);
    commit(types.UPDATE_CONVERSATION_LASTMESSAGE_INFO, tempObj)
  },
  revokeMessage({commit, dispatch, getters, state}, payload) {
    commit(types.CHAT_REVOKE_NEW_MESSAGE, payload);
  },
  sendChatMessage({commit, dispatch, getters, state}, payload) {
    // 构造/处理消息体
    let targetId = payload.id || payload.uid;
    let uid = getters.staff.uid;
    let myDate = new Date();
    const type = numToMsgType(payload.type);
    let content = JSON.stringify(payload.content)
    let contentBody = {
      content: content,
      conversationType: '',
      targetId: targetId,
      messageId: '',
      messageUId: '',
      senderUserId: uid,
      sentStatus: 0,
      timeline: '',
      objectName: type,
      device: 'PC',
      version: 1,
      relationship: ''
    };
    contentBody.relationship = structRelationship(uid, targetId);
    contentBody.conversationType = msgTypeToNum(relationshipToType(contentBody.relationship));
    contentBody.timeline = parseInt(myDate.getTime() / 1000);
    contentBody.messageUId = genMsgUId();
    switch (payload.type) {
      // 2,4图片和文件等上传消息占位
      case 2:
        contentBody.sentStatus = payload.sentStatus || 0;
        dispatch('pushChatMessage', contentBody);
        break;
      case 4:
        contentBody.sentStatus = payload.sentStatus || 0;
        dispatch('pushChatMessage', contentBody);
        break;
      default:
        contentBody.sentStatus = 1;
        dispatch('pushChatMessage', contentBody);
        break;
    }
    let Index = state.conversationList.findIndex((v) => {
      return v.uid == payload.targetId
    });
    if (Index === -1) {
      let obj = {};
      if (contentBody.conversationType == '1') {
        let hasUser = state.userList.findIndex((v) => {
          return v.uid == targetId;
        })
        obj = Object.assign({}, state.userList.find((v) => {
          return v.uid == targetId;
        }));
        if (hasUser != -1) {
          obj.isSysCreated = true;
          dispatch('createNewConversation', obj)
        }
      } else if (contentBody.conversationType == '3') {
        let hasGroup = state.groupList.findIndex((v) => {
          return v.id == targetId;
        })
        obj = Object.assign({}, state.groupList.find((v) => {
          return v.id == targetId;
        }));
        if (hasGroup != -1) {
          obj.isSysCreated = true;
          dispatch('createNewConversation', obj)
        }
      }
    }
  },
  // 消息完成后发送给服务端
  pushChatMessage({commit, dispatch, getters, state}, payload) {
    publishChatMsg(payload)
      .then(response => {
        if (response.status == 200) {
          let data = response.data;
          payload.sentStatus = data.send_type;
          payload.messageId = data.messageId;
          let userInfo = state.userList.find((v) => {
            return v.uid == payload.senderUserId
          });
          payload.avatar = userInfo.avatar;
          payload.name = userInfo.full_name;
          payload.status = 'update';
          payload.content = JSON.parse(payload.content)
          dispatch('updateChatMessage', payload)
          // messageId:178252
          // messageUId:"2c051844b4bd7e659b"
          // send_type:1
          // timeline:1525413726
          // 发送成功
        }
      })
      .catch(error => {
        // 发送失败
        payload.status = 'error';
        dispatch('updateChatMessage', payload)
      })
  },
  // 更新会话消息
  updateChatMessage({commit, dispatch, getters, state}, payload) {
    if (payload.objectName == 'RC:FileMsg') {
      //取消上传操作
      let isCancel = state.fileCancelMq.some((v) => {
        return v == payload.messageUId;
      })
      if (isCancel) {
        payload.xhr.abort()
        dispatch('delChatMessage', payload)
        return
      }
    }
    // 根据状态进入不同更新
    commit(types.CHAT_UPDATE_MESSAGE_INFO, payload)
    payload.staff = Object.assign(getters.staff);
    commit(types.UPDATE_CONVERSATION_LASTMESSAGE_INFO, payload)
  },
  // 删除/撤回会话消息
  delChatMessage({commit, dispatch, getters, state}, payload) {
    commit('DELETE_CONVERSATION_LASTMESSAGE_INFO', payload)
  },
  uploadFile({commit, dispatch, getters, state}, payload) {
    let content = {};
    let uuid = genMsgUId();
    let myDate = new Date();
    const type = numToMsgType(payload.type);
    if (payload.type == 2) {
      content = {
        content: "https://pic2.hanmaker.com/" + uuid
      }
    } else {
      let fileType = getSuffix(payload.file.name)
      content = {
        "content": "https://pic2.hanmaker.com/" + uuid,
        "name": payload.file.name,
        "size": payload.file.size,
        "type": fileType
      }
    }
    let uid = getters.staff.uid;
    let sendInfoBody = {
      content: content,
      conversationType: '',
      complete: 0,
      isCancel: false,
      targetId: payload.id,
      messageId: '',
      messageUId: uuid,
      senderUserId: uid,
      sentStatus: 0,
      timeline: '',
      objectName: type,
      device: 'PC',
      version: 1,
      relationship: ''
    };
    sendInfoBody.relationship = structRelationship(uid, payload.id);
    sendInfoBody.conversationType = msgTypeToNum(relationshipToType(sendInfoBody.relationship));
    sendInfoBody.timeline = parseInt(myDate.getTime() / 1000);
    getUploadImgToken()
      .then(response => {
        if (response.status == 200) {
          let config = {
            name: 'file',  // 图片参数名
            size: 12,  // 可选参数 图片大小，单位为M，1M = 1024kb
            action: 'http://upload.qiniu.com',  // 服务器地址,
          };
          let data = response.data;
          config.token = data.upToken;
          uploadItem(payload.file, config, uuid, {
            success(data) {
              setTimeout(() => {
                let tempObj = Object.assign({}, sendInfoBody)
                if (payload.type == 2) {
                  tempObj.content = {
                    content: data.src
                  }
                } else {
                  let fileType = getSuffix(data.fileName)
                  tempObj.content = {
                    "content": data.src,
                    "name": data.fileName,
                    "size": data.fileSize,
                    "type": fileType
                  }
                }
                updateChatMsgType(tempObj.messageId, tempObj.sentStatus)
                  .then(response => {
                    tempObj.sentStatus = response.data.send_type;
                    dispatch('updateChatMessage', tempObj)
                  })
                  .catch(error => {
                    console.log(error)
                  })
              }, 250)
              //发送完成的消息给服务器更新数据
            },
            error(e) {

            },
            start(e) {
              publishChatMsg(sendInfoBody)
                .then(response => {
                  if (response.status == 200) {
                    let data = response.data;
                    sendInfoBody.sentStatus = data.send_type;
                    sendInfoBody.messageId = data.messageId;
                    let userInfo = state.userList.find((v) => {
                      return v.uid == sendInfoBody.senderUserId
                    });
                    sendInfoBody.avatar = userInfo.avatar;
                    sendInfoBody.name = userInfo.full_name;
                    sendInfoBody.status = 'update';
                    if (payload.type == 2) {
                      sendInfoBody.content.content = ''
                    }
                    dispatch('updateChatMessage', sendInfoBody)
                    // messageId:178252
                    // messageUId:"2c051844b4bd7e659b"
                    // send_type:1
                    // timeline:1525413726
                    // 发送成功
                  }
                })
                .catch(error => {
                  // 发送失败
                  console.log('error');
                  payload.status = 'error';
                  dispatch('updateChatMessage', payload)
                })
            },
            progress(complete, xhr) {
              let tempObj1 = Object.assign({}, sendInfoBody)
              tempObj1.complete = complete;
              tempObj1.xhr = xhr
              dispatch('updateChatMessage', tempObj1)
            },
            change(xhr, formData) {

            },
            end(e) {
              e.target.value = ''
              console.log(e)
            }
          })
        }
      })
  },
  updateUploadMq({commit, dispatch, getters, state}, payload) {
    switch (payload.type) {

    }
  },
  conversationStorage({commit, dispatch, getters, state}, payload) {
    let imConversation = [];
    let conversationList = payload
    for (let i = 0; i < conversationList.length; i++) {
      let obj = {};
      obj.relationship = conversationList[i].relationship;
      obj.content = conversationList[i].content;
      obj.targetId = conversationList[i].uid;
      obj.conversationType = msgTypeToNum(relationshipToType(conversationList[i].relationship));
      obj.isTop = conversationList[i].ConversationToTop;
      obj.portraitUrl = conversationList[i].avatar;
      obj.conversationTitle = conversationList[i].full_name;
      obj.sentTime = conversationList[i].sentTime;
      obj.isDisturb = state.shieldConversationList.some((v) => {
        return obj.uid == v
      });
      obj = JSON.stringify(obj)
      imConversation.push(obj)
    }
    if (imConversation.length === 0) {
      return
    }
    imConversation = JSON.stringify(imConversation)
    let date = new Date();
    let time = date.getTime()
    let value = {
      conversation_list: imConversation,
      time: time
    }
    let data = {
      key: 'hc_conversation_list',
      value: value
    }
    syncData(data)
      .then(response => {
        console.log(response)
      })
      .catch(error => {
      })
  },
  cancelUploadFile({commit, dispatch, getters, state}, payload) {
    commit(types.ADD_CANCEL_CHAT_UPLOAD, payload)
  },
  createNewConversation({commit, dispatch, getters, state}, payload) {
    let conversationItem = {};
    let isSysCreated = payload.isSysCreated;
    let targetId = payload.id || payload.uid;
    let uid = getters.staff.uid;
    let Index = state.conversationList.findIndex((v) => {
      return v.uid == targetId
    })
    //不可以和自己聊天
    if (targetId == uid) {
      return
    }
    if (targetId >= 1000000) {
      let groupInfo = state.groupList.find((v) => {
        return v.id == targetId;
      })
      if (groupInfo) {
        payload = groupInfo;
      }
      conversationItem.relationship = structRelationship(uid, targetId);
      conversationItem.full_name = payload.group_name || payload.full_name;
      conversationItem.uid = targetId;
      conversationItem.avatar = payload.avatar;
      conversationItem.content = '';
      conversationItem.ConversationType = relationshipToType(conversationItem.relationship);
      let date = new Date();
      conversationItem.sentTime = date.getTime() / 1000;
      conversationItem.unreadMessageCount = 0;
      conversationItem.ConversationToTop = false;
      let isDisturb = state.shieldConversationList.some((v) => {
        return conversationItem.uid == v
      })
      conversationItem.isDisturb = isDisturb
    }
    else {
      getUserInfo(targetId)
        .then(response => {
          if (response.status == 200) {
            console.log(response.data)
          }
        })
        .catch(error => {

        })
      let userInfo = state.userList.find((v) => {
        return v.uid == targetId
      })
      if (userInfo) {
        payload = userInfo
      }
      conversationItem.relationship = structRelationship(uid, targetId);
      conversationItem.ConversationType = relationshipToType(conversationItem.relationship)
      conversationItem.full_name = payload.full_name;
      conversationItem.uid = targetId;
      conversationItem.avatar = payload.avatar;
      conversationItem.content = '';
      let date = new Date()
      conversationItem.sentTime = date.getTime() / 1000;
      conversationItem.unreadMessageCount = 0;
      conversationItem.ConversationToTop = false
    }
    if (Index != -1) {
      if (!isSysCreated) {
        dispatch('changeConversation', conversationItem)
      }
    } else {
      // todo:新增消息加入grouplist
      commit(types.CHAT_CREATE_NEW_CONVERSATION, conversationItem);
      if (!isSysCreated) {
        dispatch('changeConversation', conversationItem)
      }
    }
      dispatch('conversationStorage', state.conversationList);
  },
  changeConversation({commit, dispatch, getters, state}, payload) {
    if (payload.uid == getters.currentChatId) {
      return
    }
    commit(types.CHAT_RESET_CURRENTCHATINFO)
    getMessageListNew(0, payload.relationship, 1)
      .then(response => {
        if (response.status == 200) {
          if (response.data.is_front_more) {
            commit(types.SET_CONVERSATION_HAS_MORE_MESSAGE_STATUS, true)
          } else {
            commit(types.SET_CONVERSATION_HAS_MORE_MESSAGE_STATUS, false)
          }
        }
      })
      .catch(error => {
        console.log(error)
      })
    if (payload.uid < 1000000) {
      getUserInfo(payload.uid)
        .then(response => {
          if (response.status == 200) {
            let data = response.data;
            let pushData = {
              avatar: data.avatar,
              big_img: data.big_img,
              full_name: data.full_name,
              team_name: data.team_name,
              job_name: data.job_name,
              part_name: data.part_name,
              mobile: data.mobile,
              working_years: data.working_years,
              uid: payload.uid
            };
            commit(types.CHAT_RESET_CURRENTCHATUSERINFO, pushData)
          }
        })
        .catch(error => {

        })
    } else if (payload.uid > 1000000) {
      let _this = this;
      let uid = payload.uid;
      getGroupOnlineStatus(uid)
        .then(response => {
          if (response.status == 200) {
            groupInfo(uid)
              .then(data => {
                if (data.status == 200) {
                  let ownership = data.data.owner_info;
                  let pushData = {
                    onlineCount: response.data.online_num,
                    members: data.data.group_user_list,
                    avatar: data.data.avatar,
                    group_name: data.data.group_name,
                    uid: payload.uid
                  }
                  for (let i = 0; i < pushData.members.length; i++) {
                    pushData.members[i].group_level = 3
                  }
                  for (let i = 0; i < pushData.members.length; i++) {
                    for (let j = 0; j < ownership.length; j++) {
                      if (pushData.members[i].uid == ownership[j].uid) {
                        pushData.members[i].group_level = ownership[j].group_level;
                      }
                    }
                  }
                  commit(types.CHAT_RESET_CURRENTCHATGROUPINFO, pushData)
                }
              })
              .catch(error => {
                console.log(error)
              })
          }
        })
        .catch(error => {
          console.log(error)
        })
    }
    commit(types.CHAT_CHANGE_CONVERSATION_INFO, payload);
    dispatch('chatUserOnlineType');
  },
  deleteConversation({commit, dispatch, getters, state}, payload) {
    let data = {
      type: 'del',
      uid: payload
    }
    commit(types.SET_CONVERSATION_LIST, data)
    dispatch('resetChatStore')
    dispatch('conversationStorage', state.conversationList);
  },
  resetChatStore({commit, dispatch, state}, payload) {
    commit(types.CHAT_RESET_CURRENTCHATINFO, payload);
  },
  setConversationStickStatus({commit, dispatch, state}, payload) {
    commit(types.SET_STICK_CONVERSATION_LIST, payload)
    if (payload.type === 'set') {
      commit(types.ADD_CONVERSATION_LIST_ITEM, payload)
    }
  },
  changeSendStatus({commit, dispatch}, payload) {
    commit(types.CHAT_CONVERSATION_CHANGE_SEND_STATUS, payload)
  },
  initShieldList({commit, dispatch}, payload) {
    commit(types.INIT_SHIELD_GROUP_LIST, payload)
  },
  addShildItem({commit, dispatch}, payload) {
    commit(types.ADD_SHIELD_GROUP_ITEM, payload)
  },
  delShildItem({commit, dispatch}, payload) {
    commit(types.DEL_SHIELD_GROUP_ITEM, payload)
  },
  getMoreMessages({commit, dispatch, getters, state}, payload) {
    payload.list.map((v) => {
      let data = {
        item: v,
        targetId: payload.id
      };
      commit(types.CHAT_ADD_HISTORY_MESSAGE, data)
    })
  },
  changeConversationGroupInfo({commit, state}, payload) {
    let uid = payload.uid
    groupInfo(uid)
      .then(data => {
        if (data.status == 200) {
          let ownership = data.data.owner_info;
          let pushData = {
            members: data.data.group_user_list,
            avatar: data.data.avatar,
            group_name: data.data.group_name,
            uid: payload.uid
          }
          for (let i = 0; i < pushData.members.length; i++) {
            pushData.members[i].group_level = 3
          }
          for (let i = 0; i < pushData.members.length; i++) {
            for (let j = 0; j < ownership.length; j++) {
              if (pushData.members[i].uid == ownership[j].uid) {
                pushData.members[i].group_level = ownership[j].group_level;
              }
            }
          }
          commit(types.UPDATE_CONVERSATION_GROUP_DEFAULT, pushData)
        }
      })
      .catch(error => {
        console.log(error)
      })

  },
  clearnConversationLocalList({commit, state}) {
    commit(types.LOGINOUT_CLEARN_CONVERSION_LIST)
  },
  chatUserOnlineType(context, payload) {
    let uid = (context.state.currentConversationType == 'U' ? context.state.currentChatId : 0) || payload
    if (!uid) return false
    userOnlineType(uid)
      .catch(err => console.warn('获取用户状态：' + err))
      .then(response => {
        let data = {}
        if (response.status == 200) {
          data = response.data
        } else {
          data = {
            info: '',
            type: 0
          }
        }
        context.commit(types.CHAT_SET_USER_ONLINE_TYPE, data)
      })
  },
};

export default {
  state,
  mutations,
  actions,
  getters
}
