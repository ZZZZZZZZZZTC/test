import * as types from '../mutations-types'
import { receiveNotify, nearActivity,heartBeat} from '@/api/event'
import { wsBindUser } from '@/api/login'
import { getCheckList} from '@/api/leave'
import {newMessage} from '@/api/chat'
import {unescapeHTML} from '@/utils/utils'
import {genMsgUId} from "../../utils/utils";
// import { ipcRenderer } from 'electron'
// import imSdk from '@/utils/imSdk'

const state = {
  recNotify: null,
  nearActivity: null,
  userOnlineType: null,
  getLeaveInfo:null,
  leaveCheckCount:0,
  heartOrder:0
}

const mutations = {
  [types.EVENT_START_RECNOTIFY](state, timer) {
    state.recNotify = timer
  },
  [types.EVENT_END_RECNOTIFY](state) {
    if (state.recNotify == null) return true
    clearInterval(state.recNotify)
    state.recNotify = null
  },
  [types.EVENT_START_NEARACTIVITY](state, timer) {
    state.nearActivity = timer
  },
  [types.EVENT_START_LEAVEINFO](state, payload) {
    state.nearActivity = payload.timer
  },
  [types.EVENT_CHANGE_LEAVEINFO](state, payload) {
    state.leaveCheckCount = payload
  },
  [types.EVENT_END_NEARACTIVITY](state) {
    if (state.nearActivity == null) return true
    clearInterval(state.nearActivity)
    state.nearActivity = null
  },
  // 请假相关
  [types.EVENT_START_LEAVEINFO](state, payload) {
    state.nearActivity = payload.timer
  },
  [types.EVENT_CHANGE_LEAVEINFO](state, payload) {
    state.leaveCheckCount = payload
  },
  [types.EVENT_SET_HEART_BEAT_ORDER](state, payload){
    state.heartOrder = payload
  },
}
function getMsg(callback) {
  newMessage()
    .then(response=>{
      callback(response)
      getMsg(callback)
    })
    .catch(error=>{
      console.log(error)
      callback(error)
      getMsg(callback)
    })
}

const actions = {
  // 开启接收请假信息
  startRecNearLeave:({ commit, state })=>{
    getCheckList()
      .catch(err => console.warn('接收临近活动通知：' + err))
      .then(response => {
        console.log('请求请假审核数据', response);
        if (response.status == 200) {
          commit(types.EVENT_CHANGE_LEAVEINFO, response.data.length)
        }
      })
    let timer = setInterval(() => {
      getCheckList()
        .catch(err => console.warn('接收临近活动通知：' + err))
        .then(response => {
          console.log('请求请假审核数据', response);
          if (response.status == 200) {
            commit(types.EVENT_CHANGE_LEAVEINFO, response.data.length)
          }
        })
    }, 1000*60*10);
    commit(types.EVENT_START_LEAVEINFO, timer)
  },
  // 接收hantalk消息
  startRecHantalkMsg({ commit, state,getters,dispatch},payload){

    // HanIMClient.connect(payload.hanIm.username, payload.hanIm.password, {
    //   onSuccess: () => {
    //     HanIMClient.addProperty(getters.groupList);
    //     for(let i=0;i<getters.groupList.length;i++){
    //       HanIMClient.joinRoom(getters.groupList[i].id)
    //     }
    //     HanIMClient.setOnReceiveMessageListener({
    //       onReceived(msg) {
    //         console.log(msg)
    //         msg = unescapeHTML(msg);
    //         // let data = JSON.parse(msg);
    //         // data.content = JSON.parse(data.content);
    //         dispatch('addChatMessage',msg)
    //       }
    //     })
    //   }
    // })
  },
  startReceiveMsg({ commit, state,getters,dispatch},payload){
    let uuid = 'pc_'+genMsgUId();
    localStorage.setItem("clientName",uuid)
    getMsg(function (response) {
      if(response.status){
        if(response.status==200){
          let data = response.data;
          data.map((item)=>{
            dispatch('addChatMessage',item)
          })
        }
      }
    })
  },
  // 开启接收通知消息
  startRecNotify: ({ commit, state }) => {
    if (state.recNotify != null) return true
    console.log('开启接收通知消息')
    let delay = 1000 * 20
    // let delay = 1000 * 5
    let timer =  setInterval(() => {
      receiveNotify()
        .catch(err => console.warn('接收通知消息：' + err))
        .then(response => {
          if (!response || response.status != 200) return false
          console.log('接收通知消息数据：', response)

          let info = response.data
          // ipcRenderer.send("create-new-notify-win", info)
          let m = {
            strUrl: './background/notify/index.html',
            strData: JSON.stringify(info),
            width: '300',
            height: '200'
          }

          window.hanClient.runPopWindow(m)
        })
    }, delay)
    commit(types.EVENT_START_RECNOTIFY, timer)
  },
  // 关闭接收通知消息
  endRecNotify: ({ commit, state }) => {
    if (state.recNotify == null) return true;
    console.log('关闭接收通知消息')
    commit(types.EVENT_END_RECNOTIFY)
  },
  //开启协议心跳
  startHeartBeat({ commit , getters}){
    // let order = 0;
    // let timer = setInterval(()=>{
    //   if(HanIMClient.getStatus().connectCount>=5&&!HanIMClient.getStatus().connected){
    //     clearInterval(timer)
    //   }
    //   heartBeat(order)
    //     .catch(error => {})
    //     .then(response => {
    //       if(response.status == 200){
    //         let heartBeatOrder =  getters.heartOrder;
    //         if(order == heartBeatOrder){
    //           console.log('心跳一致',order,heartBeatOrder)
    //         }else{
    //           console.log('心跳不一致',order,heartBeatOrder)
    //           if(order - heartBeatOrder>5){
    //             window.hanClient.restartNetwork();
    //           }
    //         }
    //         console.log('发送的心跳order为',order);
    //         order++;
    //       }
    //     });
    // },40*1000)
  },
  // 保存协议心跳
  saveHeartBeat({ commit },payload){
    commit(types.EVENT_SET_HEART_BEAT_ORDER,payload)
  },
  // 开启接收临近活动通知
  startRecNearActivity: ({ commit, state }) => {
    if (state.nearActivity != null) return true
    console.log('开启接收临近活动通知')
    let delay = 1000 * 50
    // let delay = 1000 * 5
    let timer =  setInterval(() => {
      nearActivity()
        .catch(err => console.warn('接收临近活动通知：' + err))
        .then(response => {
          if (!response || response.status != 200) return false;
          console.log('接收临近活动通知数据：', response);
          let info = response.data;
          // ipcRenderer.send("create-new-notify-win", info)
          let m = JSON.stringify({
            strUrl: './background/notify/index.html',
            strData: JSON.stringify(info),
            width: '300',
            height: '200'
          })
          window.hanClient.runPopWindow(m)
        })
    }, delay);
    commit(types.EVENT_START_NEARACTIVITY, timer)
  },
  // 关闭接收临近活动通知
  endRecNearActivity: ({ commit, state }) => {
    if (state.nearActivity == null) return true
    console.log('关闭接收临近活动通知')
    commit(types.EVENT_END_NEARACTIVITY)
  },

  // 关闭所有通知时间
  endAllEvent: function({ commit, dispatch, state}) {
    dispatch('endRecNotify')
    dispatch('endRecNearActivity')
  },
}



export default {
  state,
  mutations,
  actions
}
