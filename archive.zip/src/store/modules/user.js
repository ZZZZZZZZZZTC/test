import * as types from '../mutations-types'

const state = {
  isGuest:1,
  staff: {},
  roles: [],
  role_module:[],
  imConfig: {},
  isLogin:false,
  config:{}
};

const mutations = {
  // 登录信息
  [types.USER_LOGIN](state,payload){
    state.staff = payload.staff;
    state.isGuest = payload.isGuest;
    state.roles = payload.roles || payload.role;
    state.imConfig = payload.imConfig;
    state.role_module = payload.role_module;
    state.isLogin = true;
  },
  // 退出登录
  [types.USER_LOGOUT] (state){
    state.isGuest = 1
    state.staff = {}
    state.roles = []
    state.role_module = []
    state.isLogin = false
    state.staff = {}
  },
  [types.GET_USER_CONFIG](state, payload) {
    state.config = payload
  }
};

const actions = {
  // 用户登录
  userLogin({commit,state},payload){
    commit(types.USER_LOGIN,payload);
  },
  // 用户退出
  userLogout({commit, state},payload){
    commit(types.USER_LOGOUT)
    // dispatch('endAllEvent')
  },

  // 用户配置
  userConfig({commit, state},payload){
    console.log(payload,2333)
    commit(types.GET_USER_CONFIG,payload)
  }
};

export default {
  state,
  mutations,
  actions
}
