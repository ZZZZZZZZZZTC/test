import * as types from '../mutations-types'
import {getUserInfo, getGroupInfo} from '@/api/user'
import {numToMsgType} from '@/utils/utils'
import {unixDateFormat} from '@/filters/index'


const state = {
  contactUserId: '',
  contactGroupId: '',
  contactInfoType: '',
  contactInfoFrom:'contact',
};

const mutations = {
  // 个人信息id
  [types.GER_CONTACT_USER_ID](state, payload) {
    state.contactUserId = payload
  },
  // 群组信息id
  [types.GER_CONTACT_GROUP_ID](state, payload) {
    state.contactGroupId = payload
  },
  // 通讯录类型
  [types.GET_CONTACT_INFO_TYPE](state, payload) {
    state.contactInfoType = payload
  },
  // 通讯信息来自哪里
  [types.GET_CONTACT_INFO_FROM](state,payload){
    state.contactInfoFrom = payload
  },
};

const actions = {
  // 获取个人信息
  getContactUserId({commit, state}, payload) {
    commit(types.GER_CONTACT_USER_ID, payload)
  },
  // 获取群组信息
  getContactGroupId({commit, state}, payload) {
    commit(types.GER_CONTACT_GROUP_ID, payload)
  },
  //设置通讯录类型
  getContactInfoType({commit, state}, payload) {
    commit(types.GET_CONTACT_INFO_TYPE, payload)
  },
  // 设置通讯录来自哪里
  setContactInfoFrom({commit, state}, payload){
    commit(types.GET_CONTACT_INFO_FROM, payload)
  },
};

export default {
  state,
  mutations,
  actions
}
