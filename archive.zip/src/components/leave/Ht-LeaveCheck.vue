<template>
  <div class="ht-cloud ht-main-section">
    <!--标题工具栏-->
    <div class="main-section-menu">
      <!--聊天标题栏-->
      <div class="chat-menu-bar">
        <div class="chat-menu-name">
          请假审核
        </div>
      </div>
    </div>
    <!---->
    <div class="main-section-body">
      <!--聊天-->
      <div class="ht-leave-section">
        <div class="leave-check-cont">
          <SmScroll>
            <ul class="clearfix">
              <li class="check-item fl" v-for="item in checkList" :key="item.id">
                <div class="item-block">
                  <span class="title">姓名：</span>
                  <p class="info">{{ item.full_name }}</p>
                </div>
                <div class="item-block">
                  <span class="title">开始时间:</span>
                  <p class="info">{{ item.start_date }}</p>
                </div>
                <div class="item-block">
                  <span class="title">结束时间：</span>
                  <p class="info">{{ item.end_date }}</p>
                </div>
                <div class="item-block">
                  <span class="title">请假时长：</span>
                  <p class="info">{{ item.hours }}小时</p>
                </div>
                <div class="item-block">
                  <span class="title">请假原因</span>
                  <p class="info" :title="'('+item.type_name+')' +'-' +item.reason">({{ item.type_name }}){{ item.reason }}</p>
                </div>
                <div class="item-handle">
                  <template v-if="item.status === '0'">
                    <el-button type="primary" size="mini" @click="handleCheck(item.id, 1)">批准</el-button>
                    <el-button type="danger" size="mini" @click="handleCheck(item.id, 2)">拒绝</el-button>
                    <el-button type="warning" size="mini" @click="handleMod(item.full_name,item.id,item.uid)">修改</el-button>
                  </template>
                  <template v-else-if="item.status === '1'">
                    <el-button type="primary" size="mini" plain :disabled="true">已批准</el-button>
                  </template>
                  <template v-else-if="item.status === '2'">
                    <el-button type="warning" size="mini" plain :disabled="true">已拒绝</el-button>
                  </template>
                </div>
              </li>
            </ul>
            <h3 v-if="!(checkList && checkList.length > 0)"  class="no-data-tip">暂无数据</h3>
          </SmScroll>
        </div>
      </div>
    </div>
    <!--聊天信息框-->
    <!--聊天信息输入发送框-->
    <HtLeaveMod
      v-if="modDialogShow"
      :id="dialogModId"
      :modUserName="modUserName"
      :leaveTypes="leaveTypes"
      :workType="workType"
      @done="handleModDone"
      @handleCloseCreate="handleCloseDialog"/>
  </div>
</template>

<script>
  import HtLeaveMod from '@/components/leave/Ht-leaveMod'
  import {getCheckList, getTypes, doCheck, submitAddApply} from '@/api/leave'
  import {getStaffOptions} from '@/api/user'
  import moment from 'moment'
  export default {
    name: "Ht-LeaveCheck",
    data() {
      return {
        loading: true,
        checkList: [],
        form: {
          uid: '',
          start_date: '',
          end_date: '',
          type: '',
          reason: ''
        },
        formLabelWidth: '70px',
        staffOptions: [],
        leaveTypes: [],
        modDialogShow: false,
        dialogModId: 0,
        modUserName:'',
        workType:[]
      }
    },
    mounted() {
      this.fetchData()
    },
    methods:{
      // 审核按钮
      handleCheck(id, status) {
        let form = {}
        form.id = id
        form.status = status
        doCheck(form).catch(err => console.log(err))
          .then(response => {
            if (response.status == 200) {
              this.$message.success(response.info)
              setTimeout(() => {
                this.fetchData()
              }, 200)
            } else {
              this.$message.error(response.info)
            }
          })
      },
      // 获取请假审核列表
      fetchData() {
        this.loading = true
        Promise.all([getCheckList(), getTypes(), getStaffOptions()])
          .catch(err => this.catchErr(err))
          .then(result => {
            this.loading = false
            let response = null
            // 审核列表
            response = result[0]
            if (response.status === 200) {
              this.checkList = []
              this.checkList = response.data
            }
            // 请假类型数据
            response = result[1]
            if (response.status === 200) {
              this.leaveTypes = response.data
            }
            // 用户信息
            response = result[2]
            if (response.status === 200) {
              this.staffOptions = response.data
            }
          })
      },
      // 打开修改弹窗
      handleMod(name,id,uid) {
        this.modDialogShow = true
        this.dialogModId = parseInt(id)
        this.modUserName = name
        let item  = this.staffOptions.find((v)=>{
          return v.uid == uid;
        });
        this.workType = item.elastic_time;
      },
      // 提交修改后的回调
      handleModDone() {
        setTimeout(() => {
          this.fetchData()
        }, 200)
      },
      // 关闭修改弹窗
      handleCloseDialog(){
        this.modDialogShow = false
      }
    },
    components: {HtLeaveMod}
  }
</script>

<style scoped>





</style>
