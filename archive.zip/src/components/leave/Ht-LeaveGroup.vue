<template>
  <div class="ht-cloud ht-main-section">
  <!--标题工具栏-->
  <div class="main-section-menu">
    <!--聊天标题栏-->
    <div class="chat-menu-bar">
      <div class="chat-menu-name">
        请假小组管理
      </div>
    </div>
  </div>
  <!---->
  <div class="main-section-body">
    <div class="ht-leave-section">

      <div class="leave-group-list">
        <SmScroll>
        <ul class="clearfix">
          <li class="group-box"
              :style="{ backgroundColor: item.color }"
              v-for="item in groups"
              :key="item.id">
            <a href="javascript:void(0);" @click="goGroup(item.id)">{{ item.name }}</a>
            <span class="delete-btn iconfont icon-group-delete"
                  v-show="edit && ( item.team_id === '0')"
                  @click="delGroup(item.id)">
            </span>
          </li>
          <li class="group-box compile-box" @click="dialogFormVisible = true">
            <span class="iconfont icon-groupicon-add addGroup-icon"></span>
          </li>
          <li class="redactli-box" @click="edit = !edit">
            <span class="redact-edit">{{ editText }}</span>
          </li>

        </ul>
        </SmScroll>
      </div>

    </div>
  </div>

    <!--添加请假小组-->
    <!--添加请假小组-->
    <el-dialog class="addLeaveUserWin"
               title="添加请假小组"
               :visible.sync="dialogFormVisible"
               size="small"
               :modal="true">
      <el-form :model="form">
        <el-form-item label="小组名"
                      :label-width="formLabelWidth">
          <el-input v-model="form.name"
                    auto-complete="off">
          </el-input>
        </el-form-item>
        <el-form-item label="第一负责人"
                      :label-width="formLabelWidth">
          <el-select v-model="form.first_leader"
                     clearable filterable>
            <el-option v-for="item in staffOptions"
                       :key="item.uid"
                       :label="item.full_name"
                       :value="item.uid">
            </el-option>
          </el-select>
        </el-form-item>
        <!--<el-form-item label="第二负责人" :label-width="formLabelWidth">-->
          <!--<el-select v-model="form.second_leader" clearable filterable>-->
            <!--<el-option v-for="item in staffOptions"-->
                       <!--:key="item.uid"-->
                       <!--:label="item.full_name"-->
                       <!--:value="item.uid">-->
            <!--</el-option>-->
          <!--</el-select>-->
        <!--</el-form-item>-->
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="submitAdd">确 定</el-button>
      </div>
    </el-dialog>

  </div>
</template>

<script>
  import { getLeaveGroupList, leaveGroupDel, leaveGroupAdd } from '@/api/leaveGroup'
  import { getStaffOptions } from '@/api/user'
    export default {
        name: "Ht-LeaveGroup",
      data(){
          return{
            edit: false,
            groups: [],

            dialogFormVisible: false,
            form: {
              name: '',
              first_leader: '',
              second_leader: ''
            },
            formLabelWidth: '90px',

            staffOptions: [
              { uid: 1, full_name: '' }
            ]
          }
      },
      mounted() {
        this.fetchData()
      },
      computed: {
        editText() {
          if (this.edit)
            return '取消编辑';
          else
            return '编辑'
        }
      },
      methods: {
        fetchData() {
          this.loading = true
          Promise.all([getLeaveGroupList(), getStaffOptions()]).catch(err => this.catchErr(err))
            .then(result => {
              this.loading = false
              let response
              response = result[0]
              if (response.status !== 0)
                this.groups = response.data
              response = result[1]
              if (response.status !== 0) {
                this.staffOptions = response.data
              }
            })
        },
        goGroup(id) {
          this.$router.push({ name: 'leaveGroupItem', params: { id: id } })
        },
        delGroup(id) {
          leaveGroupDel(id).catch(err => this.catchErr(err))
            .then(response => {
              console.log(response.info)
              if (response.status !== 0) {
                this.$message.success(response.info)
                getLeaveGroupList().catch(err => this.catchErr(err))
                  .then(response => {
                    this.groups = response.data
                  })
              } else {
                this.$message.error(response.info)
              }
            })
          return false;
        },
        submitAdd() {
          this.dialogFormVisible = false
          leaveGroupAdd(this.form).catch(err => this.catchErr(err))
            .then(response => {
              if (response.status !== 0) {
                this.$message.success(response.info)
              } else {
                this.$message.error(response.info)
              }
              return response.status
            })
            .then(status => {
              if (status === 200) {
                getLeaveGroupList().catch(err => this.catchErr(err))
                  .then(response => {
                    this.groups = response.data
                  })
              }
            })
        }
      },
    }
</script>

<style scoped>

</style>
