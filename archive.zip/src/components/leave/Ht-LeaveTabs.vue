<template>
    <div class="ht-leave-tabs">
      <el-menu default-active="1-1" :default-openeds="['1']" class="leave-tabulation"
               @open="handleOpen('/main/leave/index')" @close="handleClose">
        <el-submenu index="1">
          <template slot="title">
            <i class="iconHc-schedule"></i>请假
          </template>
          <!--请假提交-->
          <el-menu-item index="1-1">
            <router-link :to="{name:'leaveIndex'}" tag="p" class="link-p">
              请假提交
            </router-link>
          </el-menu-item>
          <!--主管权限展示部分-->
          <!--请假审核-->
          <template v-if="hasPermission(['LEAVE'])">
            <el-menu-item index="1-2">
              <router-link :to="{name:'leaveCheck'}"
                           tag="p"
                           class="link-p"
                           @click.native="removeUncheckHint">
                请假审核
              </router-link>
            </el-menu-item>
          </template>
          <!--我的请假记录-->
          <el-menu-item index="1-3">
            <router-link :to="{name:'leaveMyHistory'}"
                         tag="p"
                         class="link-p">
              我的请假记录
            </router-link>
          </el-menu-item>
          <!--小组请假记录-->
          <template v-if="hasPermission(['LEAVE'])">
            <el-menu-item index="1-4">
              <router-link :to="{name:'leaveHistory'}"
                           tag="p"
                           class="link-p">
                小组请假记录
              </router-link>
            </el-menu-item>
          </template>
          <!--请假小组-->
          <template v-if="hasPermission(['LEAVE'])">
          <!--<template>-->
            <el-menu-item index="1-5">
              <router-link :to="{name:'leaveGroup'}"
                           tag="p"
                           class="link-p">
                请假小组管理
              </router-link>
            </el-menu-item>
          </template>
        </el-submenu>
      </el-menu>
    </div>
</template>

<script>
  import {mapMutations} from 'vuex'
  import roleMixin from '@/mixins/role'
    export default {
        name: "Ht-LeaveTabs",
      mixins: [roleMixin],
      data(){
        return{
          activeIndex: '1',
        }
      },
      methods:{
        ...mapMutations({
          removeChkHint:'EVENT_CHANGE_LEAVEINFO'
        }),
        handleOpen(path) {
          this.$router.push({path: path})
        },
        handleClose(key, keyPath) {
          // console.log(key, keyPath);
        },
        removeUncheckHint() {
          this.removeChkHint(0)
        }
      }
    }
</script>

<style scoped>

</style>
