<template>
  <div class="ht-creat-group">
    <div class="creat-group__cont">
      <div class="creat-group__head">
        <div class="log-title">
          <i class="iconfont icon-group-icon"></i>
          修改请假人员信息
        </div>
        <div class="handle-bar">
         <span class="close-btn" @click="handleCloseCreate">
            <i class="iconfont icon-close"></i>
         </span>
        </div>
      </div>
      <div class="creat-group__body leave-mod__body">
        <div class="mod-item">
          <el-input disabled v-model="modUserName"></el-input>
        </div>
        <div class="mod-item">
          <el-date-picker
            v-model="form.start_date"
            type="datetime"
            :editable="false"
            @change="changeStartDate"
            placeholder="选择开始时间"
            :default-time="startDefaultTime"
            value-format="yyyy-MM-dd HH:mm:ss">
          </el-date-picker>
        </div>
        <div class="mod-item">
          <el-date-picker
            v-model="form.end_date"
            type="datetime"
            :editable="false"
            @change="changeEndDate"
            :default-time="endDefaultTime"
            placeholder="选择结束时间"
            value-format="yyyy-MM-dd HH:mm:ss">
          </el-date-picker>
        </div>
        <div class="mod-item">
          <el-select v-model="form.type" filterable placeholder="请选择请假类型">
            <el-option v-for="item in modeType" :key="item.id" :label="item.name" :value="item.id"></el-option>
          </el-select>
        </div>
        <div class="mod-item">
          <el-input type="textarea" :rows="6" placeholder="请输入请假原因" v-model="form.reason"></el-input>
        </div>
      </div>

      <div class="creat-group__foot">
        <el-button type="default" class="create-step__button" @click="handleCloseCreate">取消</el-button>
        <el-button type="default" class="create-step__button" :loading="leaveFormProcessing" @click="submitForm">确定
        </el-button>
      </div>
    </div>
  </div>
</template>

<script>
  import {getOne, submitModApply} from '@/api/leave'
  import moment from 'moment'

  export default {
    name: "Ht-leaveMod",
    props: {
      id: {
        type: Number,
        default: 0,
        required: true
      },
      leaveTypes: {
        type: Array,
        default: [],
        required: true
      },
      modUserName: {
        type: String,
        default: ''
      },
      workType: {
        type: Array,
        required: true
      },
    },
    data() {
      return {
        dialogFormVisible: this.show,
        form: {
          id: 0,
          start_date: '',
          start_time: '',
          end_date: '',
          end_time: '',
          type: '',
          reason: ''
        },
        formLabelWidth: '70px',
        leaveFormProcessing: false,
        modeId: 0,
        modeType: [],
        defaultStartTime: '',
        defaultEndTime: ''
      };
    },
    computed:{
      startDefaultTime(){
        if(!this.form.uid){return '9:30:00'}
        let  week = new Date().getDay();
        let workType = this.workType.some((v)=>{
          return v == week
        });
        if(workType){
          return '9:00:00'
        }else {
          return '9:30:00'
        }
      },
      endDefaultTime(){
        let time = moment().format('h:mm:ss')
        return time
      }
    },
    watch: {
      modeId(nVal) {
        getOne(nVal)
          .catch(err => console.log(err))
          .then(response => {
            let data = response.data
            this.form.id = data.id
            this.form.start_date = moment(data.start_date).format()
            this.form.end_date = moment(data.end_date).format()
            this.form.type = data.type
            this.form.reason = data.reason
          })
      }
    },
    created() {
      this.modeId = this.id
      this.modeType = this.leaveTypes
    },
    methods: {
      changeStartDate(val) {
        if (!val) return false
        let day = moment(val).format('d')
        let workType = this.workType.some((v) => {
          return v == day
        })
        console.log(workType,'弹性工作类型')
        if (workType) {
          this.form.start_date = val.replace(/\d{2}:\d{2}$/, '00:00')
        } else {
          this.form.start_date = val.replace(/\d{2}:\d{2}$/, '30:00')
        }
      },
      changeEndDate(val) {
        if (!val) return false
        let day = moment(val).format('d')
        let workType = this.workType.some((v) => {
          return v == day
        });
        if (workType) {
          this.form.end_date = val.replace(/\d{2}:\d{2}$/, '00:00')
        } else {
          this.form.end_date = val.replace(/\d{2}:\d{2}$/, '30:00')
        }
      },
      // 确认提交修改表单
      submitForm() {
        this.leaveFormProcessing = true
        submitModApply(this.form)
          .catch(err => this.catchErr(err))
          .then(response => {
            this.leaveFormProcessing = false
            if (response.status === 200) {
              this.$message.success(response.info)
              this.handleCloseCreate()
            } else {
              this.$message.error(response.info)
            }
            this.$emit('done')
          })
      },
      // 关闭
      handleCloseCreate() {
        this.$emit('handleCloseCreate')
      }
    }
  }
</script>

<style scoped>

</style>
