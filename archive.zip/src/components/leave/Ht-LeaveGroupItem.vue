<template>
  <div class="ht-cloud ht-main-section">
  <!--标题工具栏-->
  <div class="main-section-menu">
    <!--聊天标题栏-->
    <div class="chat-menu-bar">
      <div class="chat-menu-name" @click="goRrouteBack" style="cursor: pointer;">
        返回
      </div>
    </div>
  </div>
  <!---->
  <div class="main-section-body">
    <!--聊天-->
    <div class="ht-leave-section">
      <div class="group-item-info">
        <div class="item-info-tit">
          <h3>请假小组负责人</h3>
          <el-button type="text" class="change-info-btn" @click="dialogEditLeaderVisible = true">
            <i class="icon-portrait-feedback iconfont"></i> 修改信息</el-button>
        </div>
        <div class="principal">
          <div class="prin-item" v-if="Object.keys(first_leader_data).length > 0">
            <p class="prin-tit">第一小组负责人</p>
            <div class="prin-cont">
              <img :src="first_leader_data.full_head_img" alt="">
              <div class="integ">
                <p>{{ first_leader_data.full_name }}</p>
                <p>电话:{{ first_leader_data.mobile }}</p>
              </div>
            </div>
          </div>
          <!-- 第二负责人信息 -->
          <!-- <div class="prin-item"  v-if="Object.keys(second_leader_data).length > 0">
                  <p class="prin-tit">第二小组负责人</p>
                  <div class="prin-cont">
                      <img:src="second_leader_data.full_head_img" alt="">
                      <div class="integ">
                          <p>{{ second_leader_data.full_name }}</p>
                          <p>电话:{{ second_leader_data.mobile }}</p>
                      </div>
                  </div>
              </div> -->
        </div>
        <div class="member">
          <h3>请假小组成员
            <span>(共{{ staffs.length }}人)</span>
          </h3>
          <div  style="max-height: 300px;width: 100%">
            <SmScroll>
              <ul class="xmember clearfix">
                <li v-for="item in staffs" :key="item.uid">

                  <img :src="item.full_head_img" :title="item.full_name">

                  <span class="xmemberde" v-if="editStaff" @click="delStaff(item.uid)">
                            <i class="iconfont icon-group-delete"></i>
                        </span>
                </li>

                <li class="addxmember" v-if="team_id == 0">
                  <el-button type="text" @click="dialogAddStaffVisible = true;editStaff = false">添加</el-button>
                </li>
                <li class="addxmember" v-if="team_id == 0 && (staffs.length > 0)">
                  <el-button type="text" @click="editStaff = !editStaff">{{ editStaffText }}</el-button>
                </li>
              </ul>
            </SmScroll>
          </div>
        </div>
      </div>
    </div>
  </div>

    <!--修改小组负责人-->
    <el-dialog title="修改小组负责人"
               :visible.sync="dialogEditLeaderVisible"
               class="addLeaveUserWin"
               :modal="true">
      <el-form :model="form">
        <el-form-item label="第一负责人" :label-width="formLabelWidth">
          <el-select v-model="form.first_leader" clearable filterable>
            <el-option v-for="item in staffOptions"
                       :key="item.uid"
                       :label="item.full_name"
                       :value="item.uid"></el-option>
          </el-select>
        </el-form-item>

        <!-- 添加第二负责人 -->
        <!--<el-form-item label="第二负责人" :label-width="formLabelWidth">-->
        <!--<el-select v-model="form.second_leader" clearable filterable>-->
        <!--<el-option v-for="item in staffOptions" :key="item.uid" :label="item.full_name" :value="item.uid"></el-option>-->
        <!--</el-select>-->
        <!--</el-form-item>-->
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogEditLeaderVisible = false">取 消</el-button>
        <el-button type="primary" @click="submitEditLeader">确 定</el-button>
      </div>
    </el-dialog>
    <!--添加小组成员-->
    <el-dialog title="添加小组成员"
               :visible.sync="dialogAddStaffVisible"
               size="small" :modal="true"
               class="addLeaveUserWin">
      <el-form :model="addStaffForm">
        <el-form-item label="姓名" :label-width="formLabelWidth">
          <el-select v-model="addStaffForm.uid" clearable filterable>
            <el-option v-for="item in staffOptions" :key="item.uid" :label="item.full_name" :value="item.uid"></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogAddStaffVisible = false">取 消</el-button>
        <el-button type="primary" @click="submitAddStaff">确 定</el-button>
      </div>
    </el-dialog>

  </div>
</template>

<script>
  import { leaveGroupItem, leaveGroupEditLeader, leaveGroupAddStaff, leaveGroupDelStaff } from '@/api/leaveGroup'
  import { getStaffOptions } from '@/api/user'
    export default {
        name: "Ht-LeaveGroupItem",
      data(){
          return{
            group_id: 0,
            team_id: 0,
            currentGroupName: '',
            loading: true,
            dialogEditLeaderVisible: false,
            form: {
              first_leader: '',
              second_leader: ''
            },
            addStaffForm: {
              uid: ''
            },
            formLabelWidth: '90px',
            staffOptions: [],
            editStaff: false,
            staffs: [],
            dialogAddStaffVisible: false,
            first_leader_data: {},
            second_leader_data: {}
          }
      },
      created() {
        // 组件创建完后获取数据，
        // 此时 data 已经被 observed 了
        this.fetchData()
      },
      watch: {
        // 如果路由有变化，会再次执行该方法
        '$route': 'fetchData'
      },
      computed: {
        editStaffText() {
          if (this.editStaff)
            return '取消';
          else
            return '编辑';
        }
      },
      methods:{
        // 路由返回
        goRrouteBack(){
          this.$router.back()
        },
        fetchData() {
          this.loading = true
          this.group_id = this.$route.params.id
          leaveGroupItem(this.group_id).catch(err => this.catchErr(err))
            .then(response => {
              this.loading = false
              if(response.status === 200){
                this.currentGroupName = response.data.name
                this.team_id = response.data.team_id
                this.first_leader_data = response.data.first_leader_data
                this.second_leader_data = response.data.second_leader_data
                this.form.first_leader = Object.keys(response.data.first_leader_data).length > 0 ? response.data.first_leader_data.uid : ''
                this.form.second_leader = Object.keys(response.data.second_leader_data).length > 0 ? response.data.second_leader_data.uid : ''
                this.staffs = response.data.staffs
              }
            });
          getStaffOptions().catch(err => this.catchErr(err))
            .then(response => this.staffOptions = response.data)
        },
        submitEditLeader() {
          leaveGroupEditLeader(this.group_id, this.form.first_leader,this.form.second_leader)
            .catch(err => this.catchErr(err))
            .then(response => {
              this.dialogEditLeaderVisible = false
              if (response.status != 0) {
                this.$router.push({  name: 'leaveGroupItem', params: { id: this.group_id}, query: { t: new Date().getTime() } })
                return true
              }
              this.$message.error(response.info)
            })
        },
        submitAddStaff() {
          leaveGroupAddStaff(this.group_id, this.addStaffForm.uid).catch(err => this.catchErr(err))
            .then(response => {
              this.dialogAddStaffVisible = false
              if (response.status != 0) {
                this.$router.push({ name: 'leaveGroupItem', params: { id: this.group_id }, query: { t: new Date().getTime() } })
                return true
              }
              this.$message.error(response.info)
            })
        },
        delStaff(uid) {
          leaveGroupDelStaff(this.group_id, uid).catch(err => this.catchErr(err))
            .then(response => {
              if (response.status != 0) {
                this.$router.push({ name: 'leaveGroupItem', params: { id: this.group_id }, query: { t: new Date().getTime() } })
                return true
              }
              this.$message.error(response.info)
            })
        }
      }
    }
</script>

<style scoped>

</style>
