<template>
  <div class="ht-cloud ht-main-section">
    <!--标题工具栏-->
    <div class="main-section-menu">
      <!--聊天标题栏-->
      <div class="chat-menu-bar">
        <div class="chat-menu-name">
          我的请假记录
        </div>
      </div>
    </div>
    <!---->
    <div class="main-section-body">
      <!--聊天-->
      <div class="ht-leave-section">
        <div class="my-history-tab__title">
          <el-radio-group v-model="tabPosition" @change="checkRadioChange">
            <el-radio-button label="1">本季度</el-radio-button>
            <el-radio-button label="2">本月</el-radio-button>
          </el-radio-group>
        </div>
        <div class="my-history-tab__cont">

          <!--我的请假历史-->
          <!--请假次数列表-->
          <div class="leave-number-table">
            <table width="100%">
              <tr>
                <th width="20%"></th>
                <th width="20%">事假</th>
                <th width="20%">病假</th>
                <th width="20%">小时假</th>
                <th width="20%">其他</th>
              </tr>
              <tr>
                <td>次数</td>
                <td>{{listForm.time.normal}}次</td>
                <td>{{listForm.time.sick}}次</td>
                <td>{{listForm.time.hours}}次</td>
                <td>{{listForm.time.other}}次</td>
              </tr>
              <tr>
                <td>时间</td>
                <td>{{listForm.hours.normal}}</td>
                <td>{{listForm.hours.sick}}</td>
                <td>{{listForm.hours.hours}}</td>
                <td>{{listForm.hours.other}}</td>
              </tr>
            </table>
          </div>

          <!--请假列表-->
          <div class="leave-recode-list">
            <SmScroll>
              <el-row v-if="myLeaveList.length > 0">
                <el-col :xs="12" :sm="12" :md="12" :lg="8" class="col-cont" v-for="item in myLeaveList" :key="item.id">
                  <div class="list-item">
                    <div class="item-block clearfix">
                      <span class="tit fl">姓名：</span>
                      <p class="cont fl">{{item.full_name}}</p>
                    </div>
                    <div class="item-block clearfix">
                      <span class="tit fl">开始时间</span>
                      <p class="cont fl">{{item.start_date}}</p>
                    </div>
                    <div class="item-block clearfix">
                      <span class="tit fl">结束时间</span>
                      <p class="cont fl">{{item.end_date}}</p>
                    </div>
                    <div class="item-block clearfix">
                      <span class="tit fl">请假时长</span>
                      <p class="cont fl">{{item.duration_text}}</p>
                    </div>
                    <div class="item-block clearfix">
                      <span class="tit fl">审核状态</span>
                      <p class="cont fl">
                        <el-tag type="warning" v-if="item.status == 0">审核中</el-tag>
                        <el-tag type="primary" v-else-if="item.status == 1">通过</el-tag>
                        <el-tag type="danger" v-else-if="item.status == 2">拒绝</el-tag>
                      </p>
                    </div>
                    <div class="item-block clearfix">
                      <span class="tit fl">请假原因</span>
                      <p class="cont fl" :title="'('+item.type_name +')' +'-' + item.reason">
                        ({{item.type_name}}){{item.reason}}</p>
                    </div>
                  </div>
                </el-col>
              </el-row>
              <el-row v-else>
                <el-col :span="24">
                  <div style="text-align: center;padding: 20px 0;">
                    <el-button type="text">暂无请假记录</el-button>
                  </div>
                </el-col>
              </el-row>
            </SmScroll>
          </div>

          <!--分页-->
          <div class="leave-myhis-page" v-if="myLeaveList.length > 0">
            <el-pagination
              :page-size="10"
              layout="prev, pager, next"
              :total="total"
              :current-page.sync="currentPage"/>
          </div>


        </div>
      </div>
    </div>
    <!--聊天信息框-->
    <!--聊天信息输入发送框-->
  </div>
</template>

<script>
  import {mapGetters} from 'vuex'
  import {getHistoryList, getCountLeavedHours} from '@/api/leave'

  export default {
    name: "Ht-LeaveMyRecord",
    data() {
      return {
        tabPosition: '1',
        listForm: {
          time: {
            normal: '',
            sick: '',
            hours: '',
            other: ''
          },
          hours: {
            normal: '',
            sick: '',
            hours: '',
            other: ''
          }
        },
        formInline: {
          time_type: 7,
          type: "0",
          uid: ''
        },
        myLeaveList: [],
        total: 0,
        currentPage: 1,
      }
    },
    watch: {
      'formInline.time_type'(){
        this.fetchMyLeaveData()
        this.getMyCountLeavedHours()
      },
      'currentPage': 'fetchMyLeaveData'
    },
    computed: {
      ...mapGetters([
        'staff'
      ])
    },
    mounted() {
      this.fetchMyLeaveData()
      this.getMyCountLeavedHours()
    },
    methods: {
      // 获取时长与次数
      getMyCountLeavedHours() {
        getCountLeavedHours(this.formInline.time_type)
          .then((res) => {
          if (res.status === 200) {
            let data = res.data
            this.listForm = {
              time: {
                normal: data.normal.times,
                sick: data.sick.times,
                hours: data.hours.times,
                other: data.other.times
              },
              hours:{
                normal: this.computedTime(data.normal.hours),
                sick: this.computedTime(data.sick.hours),
                hours: this.computedTime(data.hours.hours),
                other: this.computedTime(data.other.hours)
              }
            }
          }
        })
      },

      // 获取我的请假历史
      fetchMyLeaveData() {
        this.formInline.uid = this.staff.uid
        getHistoryList(
          this.currentPage,
          this.formInline.time_type,
          this.formInline.type,
          this.formInline.uid)
          .then(res => {
            if (res.status === 200) {
              this.myLeaveList = res.data.list
              this.total = res.data.total
            }
          })
          .catch(err => {
            console.log(err)
          })
      },
      // 切换
      checkRadioChange(val) {
        if (val === '1') {
          this.formInline.time_type = 7
        } else if (val === '2') {
          this.formInline.time_type = 6
        }
      },
      computedTime(sum) {
        let day = ''
        if (sum >= 8) {
          if (sum % 8 > 0) {
            day = parseInt(sum / 8) + '天' + (sum % 8) + '小时'
          } else {
            day = sum / 8 + '天'
          }
        } else {
          day = sum + '小时'
        }
        return day
      }
    }
  }
</script>

<style scoped>

</style>
