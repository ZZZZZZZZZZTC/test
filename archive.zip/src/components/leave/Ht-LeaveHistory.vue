<template>
  <div class="ht-cloud ht-main-section">
    <!--标题工具栏-->
    <div class="main-section-menu">
      <!--聊天标题栏-->
      <div class="chat-menu-bar">
        <div class="chat-menu-name">
          小组请假记录
        </div>
      </div>
    </div>
    <!---->
    <div class="main-section-body">
      <!--请假-->
      <div class="ht-leave-section">
        <div class="leave-history-section">
          <!--筛选按钮-->
          <el-row class="leave-history__tab">
            <el-form :inline="true"
                     :model="formInline"
                     class="history-line-form">
              <!--近一个月记录-->
              <el-col :span="5">
                <el-form-item label="">
                  <el-select v-model="formInline.time_type"
                             placeholder="近一个月记录">
                    <el-option v-for="item in timeTypes"
                               :key="item.id"
                               :label="item.name"
                               :value="item.id">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <!--全部类型-->
              <el-col :span="5">
                <el-form-item label="">
                  <el-select v-model="formInline.type"
                             clearable
                             placeholder="全部类型">
                    <el-option v-for="item in leaveTypes"
                               :key="item.id"
                               :label="item.name"
                               :value="item.id">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <!--选择员工-->
              <el-col :span="5">
                <el-form-item label="">
                  <el-select v-model="formInline.uid"
                             clearable
                             filterable
                             placeholder="选择员工">
                    <el-option v-for="item in staffOptions"
                               :key="item.uid"
                               :label="item.full_name"
                               :value="item.uid">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <!--添加请假人员-->
              <el-col :span="5">
                <el-input type="button"
                          class="add-but-input"
                          value="添加请假人员"
                          @click.native="dialogFormVisible = true">
                </el-input>
              </el-col>
            </el-form>
          </el-row>
          <!--历史列表-->
          <div class="leave-history__list">
            <el-row>
              <el-col :span="24" class="table-list-body" >
                <table border="0" cellpadding="0" cellspacing="0" width="100%" :loading="loading">
                  <tr>
                    <th width="12%">申请日期</th>
                    <th width="10%">姓名</th>
                    <th width="24%">请假时间</th>
                    <th width="8%">时长</th>
                    <th width="12%">请假类型</th>
                    <th width="12%">审批</th>
                    <th width="12%">状态</th>
                    <th>操作</th>
                  </tr>
                  <tr v-for="(item,index) in tableData" :key="item.id">
                    <td>
                      {{item.create_date}}
                    </td>
                    <td>
                      {{item.full_name}}
                    </td>
                    <td>
                      {{item.longDate}}
                    </td>
                    <td>
                      {{item.duration_text}}
                    </td>
                    <td>
                      <template v-if="item.reason">
                        <el-tooltip :content="item.reason" placement="top-end">
                          <el-button type="text">{{ handleLeaveTypeText(item.type) }}</el-button>
                        </el-tooltip>
                      </template>
                      <template v-else>
                        {{ handleLeaveTypeText(item.type) }}
                      </template>
                    </td>
                    <td>
                      {{item.check_user_name}}
                    </td>
                    <td>
                      <!-- 状态-->
                      <el-tag type="warning" v-if="item.status == 0">审核中</el-tag>
                      <el-tag type="primary" v-else-if="item.status == 1" >通过</el-tag>
                      <el-tag type="danger" v-else-if="item.status == 2">拒绝</el-tag>
                    </td>
                    <td>
                      <template v-if="item.status == 1">
                        <!--修改按钮-->
                        <el-tooltip effect="dark" content="修改" placement="top">
                          <el-button type="text" @click="handleMod(item.full_name,item.id,item.uid)" class="hand-work__btn">
                            <i class="iconfont icon-contackt-edit"></i>
                          </el-button>
                        </el-tooltip>
                        <!--删除按钮-->
                        <el-tooltip effect="dark" content="删除" placement="top">
                          <el-button type="text" @click="rmLeaveRecord(item.id)" class="hand-work__btn">
                            <i class="iconfont icon-Shapecopy"></i>
                          </el-button>
                        </el-tooltip>
                      </template>
                      <span v-if="item.status != 1">-</span>
                    </td>
                  </tr>
                </table>
              </el-col>
            </el-row>
          </div>
          <!--分页-->
          <div class="leave-history__page">
            <el-row v-if="tableDataTotal">
              <el-col :span="24">
                <el-pagination background
                               :page-size="10"
                               layout="prev, pager, next"
                               :total="tableDataTotal"
                               :current-page.sync="currentPage">
                </el-pagination>
              </el-col>
            </el-row>
          </div>
        </div>
      </div>
    </div>

    <!-- 添加请假人员弹窗 -->
    <el-dialog title="添加请假人员" class="leav-add-user__win" :visible.sync="dialogFormVisible"  :modal="true">
      <el-form :model="form">
        <el-form-item label="姓名" :label-width="formLabelWidth">
          <el-select v-model="form.uid"
                     filterable
                     placeholder="请选择">
            <el-option v-for="item in staffOptions"
                       :key="item.uid"
                       :label="item.full_name"
                       :value="item.uid">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="开始时间" :label-width="formLabelWidth">
          <el-date-picker v-model="form.start_date"
                          type="datetime"
                          @change="changeStartDate"
                          :default-time="startDefaultTime"
                          value-format="yyyy-MM-dd HH:mm:ss"
                          placeholder="选择开始时间">
          </el-date-picker>
        </el-form-item>
        <el-form-item label="结束时间" :label-width="formLabelWidth">
          <el-date-picker v-model="form.end_date"
                          type="datetime"
                          @change="changeEndDate"
                          :default-time="endDefaultTime"
                          value-format="yyyy-MM-dd HH:mm:ss"
                          placeholder="选择结束时间">
          </el-date-picker>
        </el-form-item>
        <el-form-item label="请假类型" :label-width="formLabelWidth">
          <el-select v-model="form.type" filterable placeholder="请选择">
            <el-option v-for="item in leaveTypes"
                       :key="item.id"
                       :label="item.name"
                       :value="item.id">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="请假原因" :label-width="formLabelWidth">
          <el-input type="textarea"
                    :rows="4"
                    resize="none"
                    placeholder="请输入原因"
                    v-model="form.reason">
          </el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="closeLeaveUserDialog">取 消</el-button>
        <el-button type="primary" :loading="leaveFormProcessing" @click="addSubmitForm">确 定</el-button>
      </div>
    </el-dialog>

    <!--删除请假记录提示框-->
    <div class="leave-remove__model" v-if="rmLeaveRecordVisible" :id="dialogModId">
      <div  class="model-content">
        <div class="cont-tit">
          <div class="log-title"><i class="iconfont icon-group-icon"></i>删除请假记录</div>
          <i class="close iconfont icon-close" @click="rmLeaveRecordVisible = false"></i>
        </div>
        <div class="cont-body">
          <span class="warn-tip">确定要删除这条请假记录吗</span>
        </div>
        <div class="cont-foot">
          <el-button type="default" class="foot-button" @click="rmLeaveRecordVisible = false">取消</el-button>
          <el-button type="default" class="foot-button" @click="submitRmRecord" :loading="rmLoadiing">确定</el-button>
        </div>
      </div>
    </div>

    <!--修改请假人员弹窗-->
    <HtLeaveMod v-if="dialogLeaveModFormVisible"
                :id="dialogModId"
                :leaveTypes="leaveTypes"
                :modUserName="modUserName"
                :workType="workType"
                @done="handleModDone"
                @handleCloseCreate="HandleLeaveModClose"/>

  </div>
</template>

<script>
  import {mapGetters} from 'vuex'
  import moment from 'moment'
  import {getTypes, getHistoryList, doCheck, submitAddApply, deleteLeave} from '@/api/leave'
  import {getStaffOptions} from '@/api/staff'
  import HtLeaveMod from '@/components/leave/Ht-leaveMod'

  export default {
    name: "Ht-LeaveHistory",
    data() {
      return {
        formInline: {
          time_type: 1,
          type: '',
          uid: ''
        },
        timeTypes: [
          {id: 1, name: '近一个月记录'},
          {id: 2, name: '近三个月记录'},
          {id: 3, name: '近半年月记录'},
          {id: 4, name: '近一年记录'},
          {id: 5, name: '近三年记录'},
        ],
        leaveTypes: [],
        staffOptions: [],
        tableData: [],
        tableDataTotal: 0,
        currentPage: 1,
        dialogLeaveModFormVisible: false,
        dialogModId: 0,
        leaveFormProcessing: false,
        dialogFormVisible: false,
        formLabelWidth: '70px',
        form: {
          uid: '',
          start_date: '',
          end_date: '',
          type: '',
          reason: ''
        },
        rmLeaveRecordVisible: false,
        rmLoadiing: false,
        loading: true,
        modUserName:'',
        workType:[],
        addUserId:0,
        // startDefaultTime:'',
        // endDefaultTime:''
      }
    },
    watch: {
      'formInline.time_type': 'fetchListDataWithChange',
      'formInline.type': 'fetchListDataWithChange',
      'formInline.uid': 'fetchListDataWithChange',
      'currentPage': 'fetchListData',
      dialogFormVisible(val){
        if(val === false){
          this.form = {
            uid: '',
            start_date: '',
            end_date: '',
            type: '',
            reason: ''
          }
        }
      }
    },
    computed:{
      ...mapGetters([
        'staff'
      ]),
      startDefaultTime(){
        if(!this.form.uid){return '9:30:00'}
        let item  = this.staffOptions.find((v)=>{
          return v.uid == this.form.uid;
        });
        let  week = new Date().getDay();
        let workType = item.elastic_time.some((v)=>{
          return v == week
        });
        if(workType){
          return '9:00:00'
        }else {
          return '9:30:00'
        }
      },
      endDefaultTime(){
        let time = moment().format('h:mm:ss')
        return time
      }
    },
    mounted() {
      this.fetchData()
    },
    methods: {
      fetchData() {
        this.loading = true
        Promise.all([
          getTypes(2),
          getStaffOptions(),
          getHistoryList(
            this.currentPage,
            this.formInline.time_type,
            this.formInline.type,
            this.formInline.uid
          )
        ])
          .catch(err => this.catchErr(err))
          .then(result => {
            this.loading = false
            let response
            response = result[0]
            if (response.status === 200)
              this.leaveTypes = response.data
            response = result[1]
            if (response.status === 200)
              this.staffOptions = response.data
            response = result[2]
            if (response.status === 200) {
              this.tableDataTotal = response.data.total;
              this.tableData = response.data.list;
              let longDate = '';
              for (let i = 0; i < this.tableData.length; i++) {
                this.tableData[i].longDate = moment(this.tableData[i].start_date).format('MM.DD HH:mm') + ' - ' + moment(this.tableData[i].end_date).format('MM.DD HH:mm')
                this.tableData[i].create_date = moment(this.tableData[i].create_time * 1000).format('YYYY.MM.DD')
              }
            }
          })
      },
      //  获取历史记录列表
      fetchListData() {
        console.log(this.formInline.uid,'66666666')
        getHistoryList(
          this.currentPage,
          this.formInline.time_type,
          this.formInline.type,
          this.formInline.uid,
        )

          .catch(err => this.catchErr(err))
          .then(response => {
            if (response.status == 200) {
              this.tableDataTotal = response.data.total
              this.tableData = response.data.list;
              var longDate = '';
              for (let i = 0; i < this.tableData.length; i++) {
                this.tableData[i].longDate = moment(this.tableData[i].start_date).format('MM.DD HH:mm') + ' - ' + moment(this.tableData[i].end_date).format('MM.DD HH:mm')
                this.tableData[i].create_date = moment(this.tableData[i].create_time * 1000).format('YYYY.MM.DD')
              }
            }
          })
      },
      handleLeaveTypeText(type) {
        let text = ''
        this.leaveTypes.forEach(function (item) {
          if (item.id == type) {
            text = item.name
            return false
          }
        })
        return text
      },
      changeStartDate(val) {
        if(!val) return;
        if(!this.form.uid){
          this.$message.warning('请先请假选择人员')
          this.form.start_date = ''
          return
        }
        let item  = this.staffOptions.find((v)=>{
          return v.uid == this.form.uid;
        });

        let day = moment(val).format('d')
        let workType = item.elastic_time.some((v)=>{
          return v == day
        });
        if(workType){
          this.form.start_date = val.replace(/\d{2}:\d{2}$/, '00:00')
        }else {
          this.form.start_date = val.replace(/\d{2}:\d{2}$/, '30:00')
        }
      },
      changeEndDate(val) {
        if(!val) return
        if(!this.form.uid){
          this.$message.warning('请先请假选择人员')
          this.form.end_date = ''
          return
        }
        let item  = this.staffOptions.find((v)=>{
          return v.uid == this.form.uid;
        });
        let day = moment(val).format('d')
        let workType = item.elastic_time.some((v)=>{
          return v == day
        });
        if(workType){
          this.form.end_date = val.replace(/\d{2}:\d{2}$/, '00:00')
        }else{
          this.form.end_date = val.replace(/\d{2}:\d{2}$/, '30:00')
        }
      },
      addSubmitForm() {
        this.leaveFormProcessing = true;
        submitAddApply(this.form)
          .catch(err => this.catchErr(err))
          .then(response => {
            this.leaveFormProcessing = false
            if (response.status == 200) {
//              this.handleCheck(this.dialogModId, 1)
              this.$message.success(response.info)
              this.dialogFormVisible = false
            } else {
              this.$message.error(response.info)
            }
          })
      },
//      激活删除弹窗
      rmLeaveRecord(id) {
        this.rmLeaveRecordVisible = true;
        this.dialogModId = parseInt(id)
      },

//      提交删除确认
      submitRmRecord() {
        this.rmLoadiing = true;
        deleteLeave(this.dialogModId)
          .catch(err => this.catchErr(err))
          .then(response => {
            if (response.status == 200) {
              this.$message.success(response.info)
              this.rmLoadiing = false
              this.rmLeaveRecordVisible = false
              setTimeout(() => {
                this.fetchData()
              }, 800)
            } else {
              console.log(response.info)
            }
          })
      },
      // 审核
      handleCheck(id, status) {
        let form = {}
        form.id = id
        form.status = status
        doCheck(form).catch(err => this.catchErr(err))
          .then(response => {
            if (response.status === 200) {
              this.$message.success(response.info)
              setTimeout(() => {
                this.fetchData()
              }, 800)
            } else {
              this.$message.error(response.info)
            }
          })
      },
      fetchListDataWithChange() {
        this.currentPage = 1
        this.fetchListData()
      },
      handleMod(name,id,uid) {
        this.dialogLeaveModFormVisible = true
        let item  = this.staffOptions.find((v)=>{
          return v.uid == uid;
        });
        this.workType = item.elastic_time;
        this.dialogModId = parseInt(id)
        this.modUserName = name
      },
      handleModDone() {
        this.dialogLeaveModFormVisible = false
        setTimeout(() => {
          this.fetchData()
        }, 800)
      },
      // 关闭添加请假人员弹窗
      closeLeaveUserDialog(){
        this.dialogFormVisible = false
        this.form = {
          uid: '',
          start_date: '',
          end_date: '',
          type: '',
          reason: ''
        }
      },
      HandleLeaveModClose(){
        this.dialogLeaveModFormVisible = false
      }
    },
    components:{HtLeaveMod}
  }
</script>

<style scoped>

</style>
