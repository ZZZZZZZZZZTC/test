<template>
  <div class="ht-leave ht-main-section">
    <!--标题工具栏-->
    <div class="main-section-menu">
      <!--请假标题栏-->
      <div class="chat-menu-bar">
        <div class="chat-menu-name">
          请假提交
        </div>
      </div>
    </div>
    <!---->
    <div class="main-section-body">
      <!--请假提交-->
      <div class="ht-leave-section">
        <div class="leave-index-cont">
          <div class="index-cont__left">
            <div class="leave-type-box">
              <span class="types-button tran" v-for="item in commonTypes"
                    :key="item.id" @click="changeCommonType(item.id)"
                    :class="{'active':leaveForm.type === item.id}">{{item.name}}</span>
              <el-dropdown trigger="click" @command="changeOtherType">
               <span class="types-button tran" :class="{'active':dropDownActive}">
                {{otherTypeTitle}}
                <i class="down-icon el-icon-caret-bottom"></i>
              </span>
                <el-dropdown-menu slot="dropdown">
                  <div style="height:300px;width: 100%;overflow-x: hidden;overflow-y: auto;">
                    <el-dropdown-item :command="otherType.id + '#' + otherType.name"
                                      v-for="(otherType,index) in otherTypes" :key="index">
                      {{otherType.name}}
                    </el-dropdown-item>
                  </div>
                </el-dropdown-menu>
              </el-dropdown>
            </div>
            <div class="leave-form-box">
              <div class="form-box-item">
                <el-date-picker
                  v-model="leaveForm.start_date"
                  type="datetime"
                  :editable="false"
                  @change="changeStartDate"
                  :default-time="startDefaultTime"
                  :picker-options="startPickerOptions"
                  placeholder="选择开始时间"
                  value-format="yyyy-MM-dd HH:mm:ss">
                </el-date-picker>
              </div>
              <div class="form-box-item">
                <el-date-picker
                  v-model="leaveForm.end_date"
                  type="datetime"
                  :editable="false"
                  @change="changeEndDate"
                  :picker-options="endPickerOptions"
                  :default-time="endDefaultTime"
                  placeholder="选择结束时间"
                  value-format="yyyy-MM-dd HH:mm:ss">
                </el-date-picker>
              </div>
              <div class="form-box-item">
                <el-input type="textarea" v-model="leaveForm.reason" placeholder="请输入请假原因"/>
              </div>
              <!--提交按钮-->
              <el-button type="primary" class="from-submit-btn" :loading="leaveFormProcessing" @click="submitForm">提交</el-button>
              <el-alert v-if="warning" type="warning" show-icon :title="warning" :closable="false"/>
            </div>

          </div>
          <div class="index-cont__right">
            <div class="leave-collect-title">
              <span>普通请假汇总</span>
            </div>
            <div class="leave-collect-table">
              <table width="100%" cellspacing="0" cellpadding="0">
                <tr>
                  <th>请假类型</th>
                  <th>已请</th>
                  <th>可用</th>
                </tr>
                <tr v-for="(item,index) in leaveUsedList" :key="index">
                  <!--<td>两小时带薪事假(月)</td>-->
                  <td>{{item.name}}</td>
                  <template v-if="item.type === 12">
                    <td class="used">{{item.used}}h</td>
                    <td class="reside">{{ item.sum - item.used > 0 ? item.sum - item.used : 0  }}h</td>
                  </template>
                  <template v-else>
                    <td class="used">{{item.used / 8}}d</td>
                    <td class="reside">{{parseInt((item.sum - item.used > 0 ? item.sum - item.used : 0) / 8)}}d</td>
                  </template>
                </tr>
                <!--<tr>-->
                  <!--<td>普通事假(季度)</td>-->
                  <!--<td class="used">3d</td>-->
                  <!--<td class="reside">0</td>-->
                <!--</tr>-->
                <!--<tr>-->
                  <!--<td>病假(季度)</td>-->
                  <!--<td class="used">0</td>-->
                  <!--<td class="reside">5d(限用1次)</td>-->
                <!--</tr>-->
                <!--<tr>-->
                  <!--<td>紧急事假(年)</td>-->
                  <!--<td class="used">1d</td>-->
                  <!--<td class="reside">2d</td>-->
                <!--</tr>-->
                <!--<tr>-->
                  <!--<td  class="plan-td clearfix">-->
                    <!--<div class="box_l fl">-->
                      <!--带薪年假-->
                    <!--</div>-->
                    <!--<div class="box-lf fl" >统一安排</div>-->
                    <!--<div class="fl box-h">自由安排</div>-->
                  <!--</td>-->
                  <!--<td >-->
                    <!--<div class="box-ll used">0</div>-->
                    <!--<div class="box-v used">1d</div>-->
                  <!--</td>-->
                  <!--<td>-->
                    <!--<div class="box-ll reside">12d</div>-->
                    <!--<div class="box-v reside">4d</div>-->
                  <!--</td>-->
                <!--</tr>-->
              </table>
            </div>
            <div class="leave-collect-title">
              <span >温馨提示</span>
            </div>
            <div class="role-list">
              <p>1.每月有2个小时带薪小时假</p>
              <p>2.普通事假最小单位为2小时</p>
              <p>3.未满2小时的事假按2小时计算</p>
              <p>4.超出整点小时部分，按取整1小时计算</p>
              <p>5.每季度可请6天事假，按实际天数扣除请假日薪资</p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--聊天信息框-->
    <!--聊天信息输入发送框-->
  </div>
</template>

<script>
  import {mapGetters} from 'vuex'
  import moment from 'moment'
  import{formatDate} from '@/utils/utils'
  import {getTypes, submitApply, applyWarn, getUserApply,getHistoryList,getLeaveUserUsedCount} from '@/api/leave'
    export default {
        name: "HtLeaveIndex",
      data(){
        return{
          conversationName: '请假提交',
          leaveFormProcessing: false,
          leave: [],
          leaveForm: {
            type: 1,
            start_date: '',
            end_date: '',
            reason: ''
          },
          types: [],
          warning: '',
          dropDownActive:false,
          leaveUsedList:[]
        }
      },
      mounted(){
        this.fetchData()
        this.checkWarn();
        // 默认选择事假
        this.changeCommonType('1')

        this.fetchMyDataMounth()
        console.log(this.staff,'5252')
      },
      watch: {
        'leaveForm.type': 'checkWarn',
        'leaveForm.start_date': 'checkWarn',
        'leaveForm.end_date': 'checkWarn',
        '$route': 'fetchData'
      },
      computed:{
        ...mapGetters([
          'staff'
        ]),
        commonTypes() {
          let types = []
          this.types.forEach(function(type) {
            if (parseInt(type.is_common))
              types.push(type)
          });
          return types
        },
        otherTypes() {
          let types = []
          this.types.forEach(function(type) {
            if (!parseInt(type.is_common))
              types.push(type)
          });
          return types
        },
        otherTypeTitle() {
          let title = '其他';
          let type = this.leaveForm.type;
          this.otherTypes.some(function(value) {
            if (value.id === type) {
              title = value.name;
              return true;
            }
          });
          return title;
        },
          startPickerOptions(){
              var self = this;
              return {
                  disabledDate(time) {
                      return time.getTime() < (Date.now() - 1 * 24 * 60 * 60 * 1000);
                  }
              }
          },
          endPickerOptions() {
              let self = this;
              return {
                  disabledDate(time) {
                      return time.getTime() < (self.leaveForm.start_date == ''? Date.now(): new Date(self.leaveForm.start_date).getTime())- 1 * 24 * 60 * 60 * 1000;
                  }
              }
          },
        startDefaultTime(){
          if(this.staff.work_type==1){
            return '9:00:00'
          }else if(this.staff.work_type==1){
            return '9:30:00'
          }
        },
        endDefaultTime(){
          let time = moment().format('HH:mm:ss')
          console.log(time,'6563-0683-0683-086')
          return time
        }
      },
      methods:{
        fetchData() {
          getTypes().catch(err => console.warn(err))
            .then(response => {
              this.types = response.data
            })
          getUserApply()
            .catch(err => console.warn(err))
            .then(response => {
              this.leave = response.data
            })
        },
        changeCommonType(val) {
          this.leaveForm.type = val;
          this.dropDownActive = false
        },
        changeOtherType(val) {
          let type = val.split("#");
          this.leaveForm.type = type[0];
          this.dropDownActive = true
        },
        changeStartDate(val) {
          if (!val) return
          if(this.staff.work_type==0){
            this.leaveForm.start_date = val.replace(/\d{2}:\d{2}$/, '30:00')
          }else if(this.staff.work_type==1){
            this.leaveForm.start_date = val.replace(/\d{2}:\d{2}$/, '00:00')
          }else{
            this.leaveForm.start_date = val.replace(/\d{2}:\d{2}$/, '')
          }
        },
        changeEndDate(val) {
          if (!val) return false
          if(this.staff.work_type==0){
            this.leaveForm.end_date = val.replace(/\d{2}:\d{2}$/, '30:00')
          }else if(this.staff.work_type==1){
            this.leaveForm.end_date = val.replace(/\d{2}:\d{2}$/, '00:00')
          }else{
            this.leaveForm.end_date = val.replace(/\d{2}:\d{2}$/, '')
          }
        },
        // 提交请假申请
        submitForm() {
          this.leaveFormProcessing = true
          submitApply(this.leaveForm)
            .then(response => {
              this.leaveFormProcessing = false
              if (response.status !== 200) {
                this.$message({
                  type:'error',
                  message: response.info,
                  center:true
                })
              } else {
                this.leaveForm = {
                  type: 1,
                  start_date: '',
                  end_date: '',
                  reason: ''
                }
                this.$message({
                  type:'success',
                  message: '提交请假申请成功，请等待回复',
                  center:true
                })
                this.$router.push({
                  path: this.$route.path,
                  query: {
                    t: new Date().getTime()
                  }
                })
              }
            })
            .catch(err => {
              this.leaveFormProcessing = false
              this.$alert(err);
            })
        },
        checkWarn() {
          applyWarn(this.leaveForm)
            .catch(err => console.warn(err))
            .then(response => {
              if (response.status === 200) {
                this.warning = response.info
              }
            })
        },

        // 获取自己的请假信息
        // 获取我的请假历史
        fetchMyDataMounth() {
          getLeaveUserUsedCount()
            .then(res=>{
              if(res.status === 200){
                this.leaveUsedList = res.data
              }
            })
        },
      }
    }
</script>

<style scoped>

</style>
