<template>
  <div class="ht-content">
    <div class="cont-left-box">
      <keep-alive>
      <!--会话列表-->
        <!--<HtConversList v-if="$route.name === 'chat'"/>-->
        <!--通讯录列表-->
        <!--云端-->
        <HtCloudTabs  v-if="$route.name === 'cloud'"/>
      </keep-alive>
    </div>

    <div class="cont-right-box" v-show="currentChatId!=0">
      <!--<keep-alive>-->
        <router-view/>
      <!--</keep-alive>-->

    </div>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import HtCloudTabs from '@/components/cloud/Ht-CloudTabs'
  export default {
    name: "HtContent",
    data() {
      return {
        screenWidth: document.body.clientWidth,
      }
    },
    watch: {
      screenWidth(nVal, oVal) {
        if (!this.timer) {
          this.screenWidth = nVal
          this.timer = true
          let that = this
          setTimeout(function () {
            that.timer = false
          }, 200)
        }
      }
    },
    computed:{
      ...mapGetters([
        'currentChatId',
      ])
    },
    methods:{

    },
    mounted() {
      console.log(this.currentChatId,';652525')
      // 挂载window.onresize事件
      const that = this
      window.onresize = () => {
        return (() => {
          window.screenWidth = document.body.clientWidth
          that.screenWidth = window.screenWidth
        })()
      }
    },
    components:{HtCloudTabs}
  }
</script>

<style scoped>

</style>
