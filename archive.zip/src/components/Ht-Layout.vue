<template>
  <div class="container" ref="container">
    <!--头部导航栏-->
    <HtHeadNav/>
    <!--主体-->
    <router-view/>
  </div>
</template>

<script>
  import HtHeadNav from '@/components/Ht-HeadNav'  // 头部组件
  export default {
    name: "HtLayout",
    mounted() {
      this.onFileDrag()
    },
    methods:{
      // 文件拖动事件委托
      onFileDrag() {
        const holder = this.$refs.container;
        holder.ondragover = (e) => {
          e.preventDefault()
        };
        holder.ondragleave = holder.ondragend = (e) => {
          e.preventDefault()
        };
        holder.ondrop = (e) => {
          e.preventDefault()
        }
      }
    },
    components:{HtHeadNav}
  }
</script>

