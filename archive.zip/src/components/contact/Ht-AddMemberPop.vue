<template>
  <div class="ht-creat-group">
    <div class="creat-group__cont">
      <div class="creat-group__head">
        <div class="log-title">
          <i class="iconfont icon-group-icon"></i>
          邀请员工入群
        </div>
        <div class="handle-bar">
       <span class="close-btn" @click.stop="handleClose">
          <i class="iconfont icon-close"></i>
       </span>
        </div>
      </div>
      <div class="creat-group__body">
        <!--邀请成员设置-->
        <div class="invite-setting default">
          <div class="shuttle-box">
            <div class="shuttle-item selected-item">
              <!--搜索-->
              <div class="shuttle-item__search">
                <input type="text" placeholder="搜索成员"
                       v-model="filterWords"
                       @keyup.enter="resultSelectEnter"
                       @keydown.down.prevent="resultSelectDown"
                       @keydown.up.prevent="resultSelectUp">
              </div>
              <!--成员-->
              <div class="shuttle-item__list">
                <SmScroll :listenData="fullGroupsList">
                  <ul class="shuttle-menu">
                    <li class="menu-item" v-for="(gItem,gIndex) in fullGroupsList" :key="gIndex">
                      <!--标题栏-->
                      <div class="menu-item__title tran" :class="{'active':outOptIndex === gIndex}"
                           @click="handleMenuOpenToggle(gIndex)">
                        <span class="title-name">{{gItem.name}}</span>
                        <!--<span class="title-name">{{gItem.userList.length}}</span>-->
                        <span class="add-all" @click.stop="handleSelectAll(gItem.part_id)">
                          <i class="iconfont icon-group-add tran"></i>
                        </span>
                        <i class="tit-arr iconfont icon-group-arrow tran"></i>
                      </div>
                      <!--详细列表-->
                      <ul class="sub-shuttle__menu" v-show="outOptIndex === gIndex">
                        <li class="sub-menu__item tran"
                            v-for="(uItem, uIndex) in gItem.userList"
                            @click="handleSelectUser(uItem.uid)"
                            :key="uIndex">
                          <img :src="uItem.avatar" :alt="uItem.full_name" class="member-avatar">
                          <p class="member-name">
                            <span>{{uItem.full_name}}</span>
                            <span v-if="uItem.team_name">-{{uItem.team_name}}</span>
                            <span v-if="uItem.job_name">-{{uItem.job_name}}</span>
                          </p>
                        </li>
                      </ul>
                    </li>
                  </ul>
                </SmScroll>
              </div>

              <!--搜索结果-->
              <div class="shuttle-search__result" v-if="searchFilterResult.length > 0">
                <div class="shuttle-item__list">
                  <SmScroll :listenData="searchFilterResult" ref="searchResultScroll">
                    <ul class="sub-shuttle__menu">
                      <li class="sub-menu__item tran"
                          v-for="(rItem,rIndex) in searchFilterResult"
                          :class="{'active':searchSelectIndex === rIndex}"
                          @click="handleSelectUser(rItem.uid)"
                          :key="rIndex" ref="searchResultLi">
                        <img :src="rItem.avatar" :alt="rItem.full_name" class="member-avatar">
                        <p class="member-name">
                          <span>{{rItem.full_name}}</span>
                          <span v-if="rItem.team_name">-{{rItem.team_name}}</span>
                          <span v-if="rItem.job_name">-{{rItem.job_name}}</span>
                        </p>
                      </li>
                    </ul>
                  </SmScroll>
                </div>
              </div>

            </div>
            <!--选择结果-->
            <div class="shuttle-item resulted-item">
              <div class="shuttle-item__selected-num">
                已选成员({{ alreadySelectedUser.length }})
              </div>
              <div class="shuttle-item__list">
                <SmScroll :listenData="alreadySelectedUser">
                  <ul class="sub-shuttle__menu">
                    <li class="sub-menu__item tran"
                        v-for="(sItem,sIndex) in alreadySelectedUser"
                        :key="sIndex">
                      <img :src="sItem.avatar" :alt="sItem.full_name" class="member-avatar">
                      <p class="member-name">
                        <span>{{sItem.full_name}}</span>
                        <span v-if="sItem.team_name">-{{sItem.team_name}}</span>
                        <span v-if="sItem.job_name">-{{sItem.job_name}}</span>
                      </p>
                      <i class="remove-select-icon iconfont icon-group-delete" @click="handleSelectUser(sItem.uid)">
                      </i>
                    </li>
                  </ul>
                </SmScroll>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="creat-group__foot">
        <el-button type="default" class="create-step__button" @click="handleSubmit">确定</el-button>
        <el-button type="default" class="create-step__button" @click="handleClose">取消</el-button>
      </div>
    </div>
  </div>
</template>

<script>
  import _ from 'lodash'
  import { getUserList, getGroupList,getUserListByIds,getUserOrganizeList } from '@/api/user'
  export default {
   name: "HtAddMemberPop",
    props:{
      uids:{
        type:Array,
        default:[]
      },
    },
    data(){
     return{
       opened:false,
       outOptIndex:-1,
       innerOptIndex:-1,
       searchSelectIndex:0,
       filterWords:'',
       users:[],
       groups:[{ part_id: 0,name: '所有员工', opened: false}],
       organizeList:[]
     }
    },
    computed:{
      // 所有群组与群组成员列表
      fullGroupsList(){
        let fullGroups = this.groups

        fullGroups.forEach((gItem)=>{
          gItem.userList = []
          this.users.forEach((uItem)=>{
            // 所有员工列表
            if(gItem.part_id === 0){
              gItem.userList.push(uItem)
            }else {
              // 指定的分组列表
              let pos = _.findIndex(uItem.part_full,(o)=>{
                return o === gItem.part_id
              });
              if(pos !== -1){
                gItem.userList.push(uItem)
              }
            }
          });
        })
        console.log(fullGroups,'5t235252525')
        return fullGroups;
      },
      // 已选择的员工列表
      alreadySelectedUser(){
        let arr = []
        this.users.forEach((item)=>{
          item.selected && arr.push(item)
        })
        return arr
      },
      // 搜索结果列表
      searchFilterResult(){
        let arr = []
        if(!this.filterWords) return arr;
        this.users.forEach((item)=>{
          if(!item.job_name){item.job_name = ''}
          if(!item.team_name){item.team_name = ''}
          if(item.full_name.indexOf(this.filterWords) != -1 ||
            item.job_name.indexOf(this.filterWords) != -1 ||
            item.team_name.indexOf(this.filterWords) != -1){
            arr.push(item)
          }
        })
        return arr
      },
    },
    watch:{
      filterWords(val){
        if(!val) this.searchSelectIndex = 0;
      }
    },
    mounted(){
      this.fetchUserAndGroupData()
    },
    methods: {
      // 获取数据
      fetchUserAndGroupData() {
        Promise.all([getUserList(),getUserOrganizeList()])
          .then((res) => {
            // 员工列表
            let userResponse = res[0];
            let userData = userResponse.data;
            let users = []
            userData.forEach((item) => {
              let bool = _.indexOf(this.uids, item.uid) != -1
              users.push({...item, selected: bool})
            })
            this.users = users;
            // // 群组列表
            // let groupResponse = res[1];
            // let groupData = groupResponse.data
            // let groups = [{part_id: 0, name: '所有员工', opened: false}];
            // groupData.forEach((item) => {
            //   let obj = {
            //     part_id: item.id,
            //     name: item.name,
            //     opened: false
            //   }
            //   groups.push(obj)
            // })
            // this.groups = groups
            // console.log(groups,'群组')
            // 组织结构列表
            let organData = res[1].data;
            let oGroups = [{part_id: 0, name: '所有员工', opened: false}]
            organData.forEach((item)=>{
              let obj = {
                part_id: item.team_id,
                name: item.team_name,
                opened: false
              }
              oGroups.push(obj)
            })
            this.groups = oGroups
          })
          .catch((err) => {
            console.log(err)
          })
      },
      // 群组打开收起
      handleMenuOpenToggle(index) {
        if (this.outOptIndex !== index) {
          this.outOptIndex = index
        } else {
          this.outOptIndex = -1
        }
      },
      // 员工选中与取消
      handleSelectUser(uid) {
        let user = _.find(this.users, function (o) {
          return o.uid == uid
        })
        user.selected = !user.selected;
      },
      // 选中全部
      handleSelectAll(parid) {
        this.users.forEach((item) => {
          // 所有员工
          if (parid === 0) {
            item.selected = true
          } else {
            // 在指定项目
            let pos = _.findIndex(item.part_full, function (o) {
              return o == parid
            })
            if (pos !== -1)
              item.selected = true
          }
        })
      },
      // 搜索结果键盘选择
      // 向下选择
      resultSelectDown() {
        if (!this.filterWords) return;
        this.searchSelectIndex++;
        if (this.searchSelectIndex === this.searchFilterResult.length) {
          this.searchSelectIndex = 0;
        }
        this.resultSelectSrcoll(this.searchSelectIndex);
      },
      // 向上选择
      resultSelectUp() {
        if (!this.filterWords) return;
        this.searchSelectIndex--;
        if (this.searchSelectIndex === -1) {
          this.searchSelectIndex = this.searchFilterResult.length - 1;
        }
        this.resultSelectSrcoll(this.searchSelectIndex);
      },
      // 搜索键盘控制滚动
      resultSelectSrcoll(index) {
        let yPos = parseInt(this.$refs.searchResultLi[index].offsetTop -
          this.$refs.searchResultScroll.getSize.container.height + 30)
        this.$refs.searchResultScroll.scrollTo(0, yPos, 300)
      },
      // 搜索选中
      resultSelectEnter() {
        let uid = this.searchFilterResult[this.searchSelectIndex].uid;
        this.selectFilterUser(uid)
        this.searchSelectIndex = 0;
      },
      // 搜索结果选择
      selectFilterUser(uid) {
        this.handleSelectUser(uid);
        this.$nextTick(() => {
          this.filterWords = ''
        })
      },
      handleSubmit(){
        let uids = []
        let list = this.alreadySelectedUser
        this.alreadySelectedUser.forEach(item => {
          uids.push(item.uid)
        })
        this.$emit('handleSubmit',uids,list)
      },
      // 关闭
      handleClose() {
        this.$emit('handleClose')
      }
    }
  }
</script>


<style scoped>

</style>
