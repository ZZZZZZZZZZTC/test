<template>
  <div class="ht-change-avatar">
    <div class="change-avatar__cont">
      <!--头-->
      <div class="change-avatar__head">
        <div class="log-title">
          <i  class="iconfont icon-group-icon"></i>
          更换群图标
        </div>
        <div class="handle-bar">
          <span class="close-btn" @click="handleClose">
            <i class="iconfont icon-close"></i>
          </span>
        </div>
      </div>
      <!--主-->
      <div class="change-avatar__body">
        <div class="default-handle__bar">
          <ul>
            <li class="default-view view-upload" ref="uploadImgBtn">
              <i class="iconfont icon-groupicon-add"></i>
              <input type="file" ref="uploadImgInput"
                     style="display: none"
                     accept="image/jpeg,image/jpg,image/png,image/gif,image/bmp">
            </li>
            <li class="default-view view-list"
                v-for="(img,index) in defaultAvatarSrc"
                :key="index" @click="changeImg(img.src)">
              <img :src="img.src" alt="预设头像">
            </li>
          </ul>
        </div>
        <div class="preview-handel-box clearfix">
          <div class="box-left fl">
            <div class="box-left__crop">
              <VueCropper ref="cropperAvatar"
                          :img="options.img"
                          :outputSize="options.size"
                          :outPutType="options.outputType"
                          :info="options.info"
                          :canScale="options.canScale"
                          :autoCrop="options.autoCrop"
                          :autoCropWidth="options.autoCropWidth"
                          :autoCropHeight="options.autoCropHeight"
                          :fixed="options.fixed"
                          :fixedNumber="options.fixedNumber"
                          @realTime="realTime"></VueCropper>
            </div>
            <div class="box-left__hand">
              <span class="scale-btn tran" @click="startScaleAdd">+</span>
              <span class="scale-btn tran" @click="startScaleRed">-</span>
            </div>
          </div>
          <div class="box-right fr">
            <p class="tit">预览</p>
            <div class="show-preview"
                 :style="{background:`url(${previewsData}) no-repeat center / cover`}"></div>
            <p class="size">86x86</p>
            <el-button type="default" class="right-view__btn" @click="handleBaseImgUpload">确定</el-button>
            <el-button type="default" class="right-view__btn" @click="handleClose">取消</el-button>
          </div>

        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import {mapActions} from 'vuex'
  import {genMsgUId, uploadItem} from '@/utils/utils';
  import VueCropper from 'vue-cropper'
  import {editGroupAvatar} from '@/api/group'
  import {getUploadImgToken} from '@/api/upload'
  export default {
    name: "HtChangeAvatarPop",
    props:{
      groupData:{
        type:[Object,Array],
        default:{},
      }
    },
    data(){
      return{
        defaultAvatarSrc:[
          {
            src:require('@/assets/img/portrait1.png')
          },
          {
            src:require('@/assets/img/portrait2.png')
          },
          {
            src:require('@/assets/img/portrait3.png')
          },
          {
            src:require('@/assets/img/portrait4.png')
          },
        ],
        options:{
          img:require('@/assets/img/portrait1.png'),
          info:false,
          size:1,
          outputType:"jpeg",
          canScale:true,
          autoCrop:true,
          autoCropWidth:100,
          autoCropHeight:100,
          fixed:false,
          fixedNumber:[1,1]
        },
        previewsData:'',
        domain:'',
        expires:0,
        saveKeyPrefix:'',
        upToken:'',
        isDone:true
      }
    },
    methods:{
      ...mapActions([
        'setContactChangeSync'
      ]),
      handleClose(){
        this.$emit('handleClose')
      },
      // 选择默认图
      changeImg(val){
        this.options.img = val
      },
      // 放大
      startScaleAdd(){
        this.$refs.cropperAvatar.changeScale('2')
      },
      // 缩小
      startScaleRed(){
        this.$refs.cropperAvatar.changeScale('-2')
      },
      // 实时预览
      realTime(){
        this.finish()
      },
      finish(){
        var type = 'base64' || 'blob'
        if(type === 'blob'){
          this.$refs.cropperAvatar.getCropBlob((data)=>{
            return this.previewsData = window.URL.createObjectURL(data)
          })
        }else{
          this.$refs.cropperAvatar.getCropData((data)=>{
            return this.previewsData = data
          })
        }
      },

      // 选择本地图片
      handleEventSendImg(){
        if (!this.isDone) {
          return
        }
        let _this = this

        let file = this.$refs.uploadImgInput
        file.onchange = function () {
          let _file = this.files[0];
          console.log(_file)
            getUploadImgToken().then(response => {
                let uuid = genMsgUId();
                if (response.status == 200) {
                    let config = {
                        name: 'file',  // 图片参数名
                        size: 12,  // 可选参数 图片大小，单位为M，1M = 1024kb
                        action: 'http://upload.qiniu.com',  // 服务器地址,
                    };
                    let data = response.data;
                    config.token = data.upToken;
                    _this.$message.warning('图片上传中')
                    uploadItem(_file, config, uuid,{
                        start(e) {

                        },
                        error: function (errorCode) {
                            alert(errorCode)
                            console.log(errorCode)
                            _this.$message.error(errorCode)
                            _this.isDone = true
                        },
                        progress: function (loaded, total) {
                            let percent = Math.floor(loaded / total * 100)
                        },
                        success: function (data) {
                            _this.isDone = true
                            console.log("upload completed")
                            // data.src = _this.domain + '/' + data.key
                            _this.$message.success('上传完成')
                            _this.options.img = data.src
                            /*
                             缩略图： let thumbnail = 'data:image/png;base64,' + data.thumbnail;
                             获取Url：let sourceLink = domain +"/"+ data.key;

                             七牛文档：https://developer.qiniu.com/kodo/sdk/javascript
                             */
                        },
                        change(xhr, formData) {

                        },
                        end(e) {
                            //that.setFileUploadMg(that.filesList);
                        }
                    })
                }

            })
          // UploadClient.initImage(config, function (uploadImage) {
          //   _this.isDone = false
          //   uploadItem(_file, callback)
          //   // 取消上传
          //   /*cancelBtn.onclick = function(){
          //    uploadFile.cancel();
          //    };*/
          // });
        }
        // 点击图标上传
        let btn = this.$refs.uploadImgBtn
        btn.onclick = function () {
          file.click()
        }
      },
      // 处理base64图片上传
      handleBaseImgUpload(){
        if (!this.isDone) {
          return
        }
        let _this = this
        function dataURLtoFile(dataurl, filename) {
          var arr = dataurl.split(','), mime = arr[0].match(/:(.*?);/)[1],
            bstr = atob(arr[1]), n = bstr.length, u8arr = new Uint8Array(n);
          while (n--) {
            u8arr[n] = bstr.charCodeAt(n);
          }
          return new File([u8arr], filename, {type: mime});
        }

        let data = _this.previewsData;
        let file = dataURLtoFile(data, 'a.png');
          getUploadImgToken().then(response => {
              let uuid = genMsgUId();
              if (response.status == 200) {
                  let config = {
                      name: 'file',  // 图片参数名
                      size: 12,  // 可选参数 图片大小，单位为M，1M = 1024kb
                      action: 'http://upload.qiniu.com',  // 服务器地址,
                  };
                  let data = response.data;
                  config.token = data.upToken;
                  uploadItem(file, config, uuid,{
                      error: function (errorCode) {
                          _this.isDone = true
                          _this.$message.error(errorCode)
                      },
                      progress: function (loaded, total) {
                          let percent = Math.floor(loaded / total * 100)
                      },
                      success: function (data) {
                          _this.isDone = true;
                          // data.src = _this.domain + '/' + data.key
                          _this.changeAvatar(data.src)

                      },
                      change(xhr, formData) {

                      },
                      end(e) {
                          //that.setFileUploadMg(that.filesList);
                      },
                      start(e) {

                      },
                  })
              }

          })
      },
      // 更换上传头像
      changeAvatar(url){
        editGroupAvatar(this.groupData.id,url)
          .then(res=>{
            if(res.status === 200){
              this.$emit('changeAvatarOver')
              this.$message({
                type:'success',
                message:'更换头像成功！',
                center:true,
                duration:1000
              })
            }
          }).catch(err=>{console.log(err)})
      }
    },
    mounted(){
      this.handleEventSendImg()
    },
    components:{VueCropper}
  }
</script>

<style scoped>

</style>
