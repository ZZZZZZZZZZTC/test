<template>
<div class="ht-group-related">
  <div class="detail-panel">
    <div class="detail-info">
      <!--头像-->
      <div class="gd-avatar">
        <img :src="groupData.avatar" :alt="groupData.group_name">
        <div class="mask tran" @click="changeAvatarShow" title="更换头像" v-if="(staff.uid === groupData.owner_id) || isManager">
          <i class="iconfont icon-camera"></i>
        </div>
      </div>
      <!--群名称-->
      <div class="gd-name clearfix">
        <h1 v-if="!editable">
            <span class="name-ss" :title="groupData.group_name">{{groupData.group_name}}</span>
          <i class="iconfont icon-contackt-edit tran"  title="编辑群名称" v-if="(staff.uid === groupData.owner_id) || isManager" @click.stop="handleEditGroupName"></i>
        </h1>
        <!--编辑群名称-->
        <div class="edit-box" v-if="editable" v-click-outside="handleCloseEditePut">
          <el-input class="edit-input" :placeholder="groupData.group_name" v-model="groupEditName"></el-input>
          <el-button type="text" class="edit-btn" @click.stop="handleSaveNameEdited">保存</el-button>
        </div>
      </div>
      <div class="gd-content">
        <div class="cont-item clearfix">
          <!--群主-->
          <div class="tit item-box fl">群主/管理员</div>
          <div class="info item-box fr">
            <ul class="clearfix managers">
              <li class="fl" v-for="(item,index) in groupData.group_user_list" :key="index">
                <span class="mg-span">
                  <i class="iconfont icon-manager creater" v-if="item.group_level === 1"></i>
                   <img :src="item.avatar" class="mg-img" :alt="groupData.owner_name" v-if="(item.group_level === 1) || (item.group_level === 2)">
                </span>

              </li>
            </ul>
          </div>
        </div>
        <div class="cont-item clearfix">
          <div class="tit  item-box fl">创建时间&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
          <div class="info item-box fr">{{groupData.created_at | unixDateFormat('YYYY-MM-DD')}}</div>
        </div>
        <div class="cont-item clearfix">
          <div class="tit item-box fl">加群方式&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
          <div class="info item-box fr">{{inviteJoinGroupWays}}</div>
        </div>
      </div>
    </div>
    <!--发送消息按钮-->
    <el-button v-if="contactInfoFrom === 'contact'" type="primary" class="group-sendmsg__btn" @click.native="createConversation">发送消息</el-button>
  </div>


  <!--更换头像弹窗-->
  <HtChangeAvatar   v-if="changeAvatarDialog"
                    :groupData="groupData"
                    @changeAvatarOver="changeAvatarOver"
                    @handleClose="changeAvatarClose"/>

</div>
</template>

<script>

  import {mapGetters,mapActions} from 'vuex'
  import {editGroupName} from '@/api/group'
  import {getGroupInfo} from "@/api/user"
  import HtChangeAvatar from "@/components/contact/Ht-ChangeAvatarPop"
    export default {
      name: "HtGroupInfo",
      props:{
        currentId:{
          type:String,
          default:''
        },
      },
      data(){
        return{
          editable: false,
          groupEditName:'',
          groupOwnerInfo:[],
          groupData:{},
          changeAvatarDialog:false
        }
      },
      watch:{
        // 监听id的变化
        currentId(val){
          if(val){
            this.fetchGroupData()
          }
        },
      },
      computed:{
        ...mapGetters([
          'staff',
          'contactInfoFrom'
        ]),
        // 邀请入群方式
        inviteJoinGroupWays(){
          if(this.groupData.private_type === '1'){
            return '允许群成员邀请成员入群'
          }else if(this.groupData.private_type === '0'){
            return '只许群主/管理员邀请成员入群'
          }
        },
        // 是不是管理员
        isManager(){
          let uid = this.staff.uid
          let bool = false
          let item = this.groupOwnerInfo.find((o)=>{
            return o.uid === uid
          })
          if(item){
            (item.group_level == 2) && (bool = true)
          }
          return bool
        },
      },
      mounted(){
        this.fetchGroupData()
      },
      methods:{
        ...mapActions([
          'setContactChangeSync',
          'createNewConversation',
          'changeConversationGroupInfo'
        ]),
        // 获取群数据
        fetchGroupData(){
          getGroupInfo(this.currentId)
            .then(res => {
              if (res.status === 200) {
                let userList = res.data.group_user_list
                // 默认管理员为第一位显示
                for (let i = 0; i < userList.length; i++) {
                  userList.sort((a,b)=> a.group_level - b.group_level)
                }
                this.groupData = res.data
                this.groupOwnerInfo = this.groupData.owner_info

              }
            }).catch(err => {
            console.log(err)
          })
        },

        // 编辑群名称
        handleEditGroupName() {
          this.editable = true
        },
        // 关闭编辑框
        handleCloseEditePut(){
          this.editable = false
        },
        // 保存群名称
        handleSaveNameEdited() {
          let group_id = this.groupData.id
          editGroupName(group_id,this.groupEditName)
            .then(res=>{
              if(res.status === 200){
                setTimeout(()=>{
                  this.groupEditName = ''
                  this.setContactChangeSync(true)
                  this.fetchGroupData()
                  let obj = {
                    uid:group_id
                  }
                  this.changeConversationGroupInfo(obj)
                },20)
              }
            })
            .catch(err=>{console.log(err)})
          this.editable = false
        },
        changeAvatarOver(){
          this.fetchGroupData()
          this.changeAvatarDialog = false
          this.setContactChangeSync(true)
          let obj = {
            uid: this.groupData.id
          }
          this.changeConversationGroupInfo(obj)
        },
        changeAvatarShow(){
          this.changeAvatarDialog = true
        },
        changeAvatarClose(){
          this.changeAvatarDialog = false
        },
        createConversation(){
          let data = this.groupData;
          console.log('conversation',data);
          this.createNewConversation(data);
          this.$router.push('chat')
        }
      },
      components:{HtChangeAvatar}
    }
</script>

<style scoped>

</style>
