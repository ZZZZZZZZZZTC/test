<template>
    <div class="ht-group-related">
      <div class="setting-panel">
        <div class="set-item">
          <span class="item-title">通知设置：</span>
          <div class="item-box">
            <el-radio-group v-model="shieldMsgRadio" @change="handleReceiveNotify">
              <div class="box-label">
                <el-radio  :label="1">接收所有消息并提醒</el-radio>
              </div>
              <div class="box-label">
                <el-radio :label="2">仅接收@我的消息并提醒</el-radio>
              </div>
            </el-radio-group>
          </div>
        </div>
        <div class="set-item" v-if="isCreater || isManager">
          <span class="item-title">加群方式：</span>
          <div class="item-box">
            <el-radio-group v-model="privateRadio" @change="handleSetGroupPrivate">
              <div class="box-label">
                <el-radio  :label="0">仅允许群主邀请入群</el-radio>
              </div>
              <div class="box-label">
                <el-radio :label="1">允许群成员邀请入群</el-radio>
              </div>
            </el-radio-group>

          </div>
        </div>
        <div class="set-item" v-show="isCreater">
          <span class="item-title">转让：</span>
          <div class="item-box">
            <div class="box-label">
              <el-button type="default" class="setting-btn-quit" @click="handleTransferPopShow">群组转让</el-button>
            </div>
          </div>
        </div>
        <div class="set-item">
          <span class="item-title">其他：</span>
          <div class="item-box">
            <template v-if="isCreater">
              <el-button type="default" class="setting-btn-quit" @click="handleGroupRemoveShow">解散该群</el-button>
            </template>
            <template v-else>
              <el-button type="default" class="setting-btn-quit" @click="handleGroupQuitShow">退出群组</el-button>
            </template>
          </div>
        </div>
      </div>

      <!--转让弹窗-->
      <HtTransferGroupOwner v-if="transferShow"
                            :uids="[]"
                            :groupData="groupData"
                            @handleSubmit="handleTransferSubmit"
                            @handleClose="handleTransferClose"/>

      <!--退出弹窗-->
      <HtNoticeDialog :dialogShow="quitGroupDialog"
                      @handleWork="handleGroupQuit"
                      @handleClose="handleGroupQuitClose">
          <p class="default-arrfim">
            确定要退出群组<span>{{groupData.group_name}}</span>吗？
          </p>
      </HtNoticeDialog>

      <!--解散群组-->
      <HtNoticeDialog :dialogShow="removeGroupDialog"
                      @handleWork="handleGroupRemove"
                      @handleClose="handleGroupRemoveClose">
        <p class="default-arrfim">
          确定要解散群组<span>{{groupData.group_name}}</span>吗？
        </p>
      </HtNoticeDialog>
    </div>
</template>

<script>
  import {mapGetters,mapActions} from 'vuex'
  import {groupDismiss,groupQuit,shieldGroup,unShieldGroup,changeGroupOwner,setGroupPrivate} from '@/api/group'
  import {getGroupInfo} from '@/api/user';
  import HtTransferGroupOwner from '@/components/contact/Ht-TransferGroupOwner'
  import HtNoticeDialog from '@/components/base/Ht-NoticeDialog'
    export default {
      name: "HtGroupSetting",
      props:{
        currentId:{
          type:String,
          default:''
        },
      },
      data(){
          return{
            shieldMsgRadio:1,
            privateRadio: 0,
            checked: false,
            groupData:{},
            groupOwnerInfo:[],
            transferShow:false,
            quitGroupDialog:false,
            removeGroupDialog:false
          }
      },
      computed:{
        ...mapGetters([
          'staff',
          'currentChatId',
          'shieldConversationList'
        ]),
        isCreater(){
          return this.staff.uid === this.groupData.owner_id
        },
        // 是不是管理员
        isManager(){
          let uid = this.staff.uid
          let bool = false
          let item = this.groupOwnerInfo.find((o)=>{
            return o.uid === uid
          })
          if(item){
            (item.group_level == 2) && (bool = true)
          }
          return bool
        },
      },
      mounted(){
        this.fetchGroupData();
        this.isInShieldList()
      },
      methods:{
        ...mapActions([
          'setContactChangeSync',
          'getContactInfoType',
          'addShildItem',
          'delShildItem'
        ]),
        isInShieldList(){
          this.shieldMsgRadio = this.shieldConversationList.some(x=> x ===this.currentChatId) ? 2 : 1
        },

        // 获取群组信息
        fetchGroupData(){
          getGroupInfo(this.currentId)
            .then(res => {
              if (res.status === 200) {
                this.groupData = res.data
                this.groupOwnerInfo = this.groupData.owner_info;
                this.privateRadio = Number(this.groupData.private_type)
              }
            }).catch(err => {
            console.log(err)
          })
        },
        // 移交群主确认
        handleTransferSubmit(uid){
          let owner_uid = uid
          changeGroupOwner(this.groupData.id,owner_uid)
            .then(res=>{
              if(res.status === 200){
                this.fetchGroupData()
                this.$message({
                  type:'success',
                  message:'群主移交成功！',
                  center:true
                })
              }else {
                this.$message({
                  type:'error',
                  message:res.info,
                  center:true
                })
              }
              this.transferShow = false
            })

        },
        // 移交弹窗展示
        handleTransferPopShow(){
          this.transferShow = true
        },
        // 移交弹窗关闭
        handleTransferClose(){
          this.transferShow = false
        },
        // 退出群组
        handleGroupQuit(){
          groupQuit(this.groupData.id)
            .then(res=>{
              if(res.status === 200){
                this.$message({
                  type:'success',
                  message:'退出群组成功！',
                  center:true
                });
                this.setContactChangeSync(true)
                this.getContactInfoType('')
                this.fetchGroupData()
              }else {
                this.$message({
                  type:'error',
                  message:res.info,
                  center:true
                })
              }
              this.quitGroupDialog = false
            })
        },
        handleGroupQuitShow(){
          this.quitGroupDialog = true
        },
        handleGroupQuitClose(){
          this.quitGroupDialog = false
        },
        handleGroupRemove(){
          groupDismiss(this.groupData.id)
            .then(res=>{
              if(res.status === 200){
                this.$message({
                  type:'success',
                  message:'解散群组成功！',
                  center:true
                });
                this.setContactChangeSync(true)
                this.getContactInfoType('')
                this.fetchGroupData()
              }else {
                this.$message({
                  type:'error',
                  message:res.info,
                  center:true
                })
              }
              this.removeGroupDialog = false
            })
        },
        // 解散群组
        handleGroupRemoveShow(){
          this.removeGroupDialog = true
        },
        handleGroupRemoveClose(){
          this.removeGroupDialog = false
        },
        // 屏蔽设置
        handleReceiveNotify(val){
          if(val == 1){
            let that = this
            unShieldGroup(this.currentChatId)
              .then(response => {
                if(response.status === 200){
                 this.delShildItem(this.currentChatId)
                 console.log(response.data,'取消屏蔽成功')
                }
              })
              .catch(error => console.error(error))
          }else if(val == 2){
            let that = this
            shieldGroup(this.currentChatId)
              .then(response => {
                this.addShildItem(this.currentChatId)
                console.log(response.data,'设置屏蔽成功')
              })
              .catch(error => console.error(error))
          }
        },
        // 加群方式设置
        handleSetGroupPrivate(val){
          let that = this;
          if(val === 0){
            setGroupPrivate(this.privateRadio,this.currentChatId)
              .then((res)=>{
                if(res.status === 200){
                  console.log(res.info,'只允许群主邀请人')
                }
              }).catch(err=>{console.log(err)})
          }else if(val === 1){
            setGroupPrivate(this.privateRadio,this.currentChatId)
              .then((res)=>{
                if(res.status === 200){
                  console.log(res.info,'群成员可以邀请人')
                }
              }).catch(err=>{console.log(err)})
          }
        }
      },
      components:{HtTransferGroupOwner,HtNoticeDialog}
    }
</script>

<style scoped>

</style>
