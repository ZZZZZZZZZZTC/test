<template>
  <div class="ht-contact ht-main-section">
    <!--群组标题栏  如果是群组的话会显示-->
    <!--<div class="main-section-menu" v-if="contactInfoType==='G'">-->
    <!--&lt;!&ndash;聊天标题栏&ndash;&gt;-->
    <!--<div class="chat-menu-bar">-->
    <!--<div class="chat-menu-name">-->
    <!--<p>{{contactGroupInfo.group_name}}</p>-->
    <!--</div>-->
    <!--</div>-->
    <!--</div>-->

    <!--内容-->
    <div class="main-section-body">
      <div class="section-work-space">
        <!--个人信息简介-->
        <HtPersonalDetails :currentShowId="currentShowId" v-if="contactInfoType === 'U'"/>
        <!--群组信息简介-->
        <HtGroupDetails  :currentShowId="currentShowId" v-if="contactInfoType === 'G'"/>
      </div>
    </div>
  </div>
</template>

<script>
  import {mapGetters} from 'vuex'
  import HtPersonalDetails from '@/components/contact/Ht-PersonalDetails'
  import HtGroupDetails from '@/components/contact/Ht-GroupDetails'

  export default {
    name: "HtContactContent",
    data() {
      return {}
    },
    props:{
      currentShowId:{
        type:String,
        default:''
      }
    },
    computed: {
      ...mapGetters([
        'contactInfoType',
      ]),
    },
    components: {HtPersonalDetails, HtGroupDetails}
  }
</script>

<style scoped>

</style>
