<template>
<div class="ht-group-related">
  <div class="member-panel">
    <div class="member-bar">
      <div class="member-bar__num">
        成员：{{online_num}}/{{allMemberNum}}  人
      </div>
      <div class="member-bar__hand">
        <div class="member-search__input">
          <input type="text" placeholder="搜索群成员" v-model="filterWords">
          <i class="input-icon iconfont icon-search"></i>
        </div>
        <span class="member-add__btn" title="添加群成员" v-if="isCreater || isManager || groupData.private_type === '1'" @click.stop="addMemberHandelOpen">
          <i class="iconfont icon-group-member-add"></i>
        </span>
      </div>
    </div>
    <div class="member-list">
      <div class="member-list__title-table">
        <ul>
          <li class="title-item">
            <div class="title-item__name item-box">姓名</div>
            <div class="title-item__part item-box">项目组</div>
            <div class="title-item__job item-box">职位</div>
            <div class="title-item__org item-box">组织架构</div>
            <div class="title-item__handle item-box"></div>
          </li>
        </ul>
      </div>
      <div class="member-list__body-table">
        <SmScroll :listenData="groupData">
        <ul>
          <li class="member-item tran"
              @dblclick.prevent="memberDbClick(item)"
              v-for="(item,index) in  this.filterWords ? searchFilterResult : groupMemberData"
              :class="{'isManager':isCreater}"
              :key="index">
            <div class="member-item__name item-box" :class="{'creater':isCreater}">
              <!--如果是群主-->
              <template v-if="isCreater">
                <!--群主-->
                <i class="iconfont icon-manager creater-icon" v-if="item.group_level === 1"></i>
                <!--管理员-->
                <i class="iconfont icon-manager manager-icon"
                   v-else-if="item.group_level === 2" @click.prvent="rmManagerDialogOpen(item)"></i>
                <!--普通人-->
                <i  class="iconfont icon-manager" v-else @click.stop="setManagerDialogOpen(item)"></i>
              </template>

              <!--其他-->
              <template v-else>
                <!--群主-->
                <i class="iconfont icon-manager creater-icon" v-if="item.group_level === 1"></i>
                <!--管理员-->
                <i class="iconfont icon-manager manager-icon"
                   v-else-if="item.group_level === 2"></i>
                <!--普通人-->
                <i  class="iconfont icon-manager" v-else></i>
              </template>

              <img :src="item.avatar" :alt="item.full_name" class="avatar" >
              <span>{{item.full_name}}</span>
            </div>

            <div class="item-box member-item__part ">
              {{item.team_name || item.post_name}}
            </div>
            <div class="item-box member-item__job ">{{item.post_name}}</div>
            <div class="item-box member-item__org ">{{item.post_name}}</div>
            <div class="item-box member-item__handle">
              <template v-if="isCreater">
                <span class="handle-sp" @click.stop="rmMemberDialogOpen(item)" v-if="!(item.group_level === 1)">
                  <i class="iconfont icon-group-member-remove" title="删除" ></i>
                </span>
              </template>
              <template v-else-if="isManager">
                <span class="handle-sp" @click.stop="rmMemberDialogOpen(item)" v-if="item.group_level === 3">
                  <i class="iconfont icon-group-member-remove" title="删除" ></i>
                </span>
              </template>
            </div>
          </li>
        </ul>
        </SmScroll>
      </div>
    </div>
  </div>
  <!--添加管理员提示弹窗-->
  <HtNoticeDialog
    :dialogShow="setManagerDialogShow"
    @handleWork="setManagerHandleWork"
    @handleClose="setManagerHandleClose">
    <p class="default-arrfim">确定要设置<span>{{UserData.full_name}}</span>为管理员吗？</p>
  </HtNoticeDialog>

  <!--移除管理员提示弹窗-->
  <HtNoticeDialog
    :dialogShow="rmManagerDialogShow"
    @handleWork="rmManagerHandleWork"
    @handleClose="rmManagerHandleClose">
    <p class="default-arrfim">确定要取消<span>{{UserData.full_name}}</span>的管理员资格吗？</p>
  </HtNoticeDialog>

  <!--删除群成员提示弹窗-->
  <HtNoticeDialog
    :dialogShow="rmMemberDialogShow"
    @handleWork="rmMemberHandleWork"
    @handleClose="rmMemberHandleClose">
    <p class="default-arrfim">确定要将<span>{{UserData.full_name}}</span>移除该群吗？</p>
  </HtNoticeDialog>


  <!--添加群成员-->
  <HtAddMemberPop v-if="member_pop" :uids="[]" @handleClose="addMemberHandelClose" @handleSubmit="addMemberHandleSubmit"/>

</div>
</template>

<script>
  import {mapGetters,mapActions} from 'vuex'
  import {attachManager,detachManager,groupQuitGroup,groupInviteToJoin,getGroupOnlineStatus} from '@/api/group'
  import {getGroupInfo} from "@/api/user"
  import HtNoticeDialog from '@/components/base/Ht-NoticeDialog'
  import HtAddMemberPop from '@/components/contact/Ht-AddMemberPop'
  export default {
    name: "HtGroupMember",
    props:{
      currentId:{
        type:String,
        default:''
      },
      groupOnlineNum:{
        type:Number,
        default:0
      }
    },
    data(){
      return{
        groupOwnerInfo:[],
        setManagerDialogShow:false,
        rmManagerDialogShow:false,
        rmMemberDialogShow:false,
        UserData:{},
        filterWords:'',
        member_uids:[],
        member_pop:false,
        groupMemberData:[],
        groupData:{},
        allMemberNum:0,
        online_num:0,

      }
    },
    computed:{
      ...mapGetters([
        'staff'
      ]),
      // 创建者
      isCreater(){
        return this.staff.uid === this.groupData.owner_id
      },
      // 管理员
      isManager(){
        let uid = this.staff.uid
        let bool = false
        let item = this.groupOwnerInfo.find((o)=>{
          return o.uid === uid
        })
        if(item){
          (item.group_level == 2) && (bool = true)
        }
        return bool
      },

      // 搜索结果
      searchFilterResult(){
        let userList = this.groupData.group_user_list
        let arr = []
        if(!this.filterWords) return arr
        userList.forEach((item)=>{
          if(item.full_name.indexOf(this.filterWords) != -1){
            arr.push(item)
          }
        })
        return arr
      }
    },
    mounted(){
      this.$nextTick(()=>{
        this.fetchGroupData();
        this.getGroupOnlineNum()
      })
    },
    methods:{
      ...mapActions([
        'createNewConversation',
        'changeConversationGroupInfo'
      ]),
      // 获取群组成员数据
      fetchGroupData(){
        getGroupInfo(this.currentId)
          .then(res => {
            if (res.status === 200) {
              let userList = res.data.group_user_list
              // 默认管理员为第一位显示
              for (let i = 0; i < userList.length; i++) {
                userList.sort((a,b)=> a.group_level - b.group_level)
              }

              this.groupData = res.data
              this.groupOwnerInfo = res.data.owner_info
              this.allMemberNum = res.data.group_user_list.length
              this.groupMemberData = userList
            }
          }).catch(err => {
          console.log(err)
        })
      },
      // 获取成员在线人数
      getGroupOnlineNum(){
        let groupId = this.currentId
        if(!groupId) return
        getGroupOnlineStatus(groupId)
          .then(response=> {
            if(response.status === 200){
              this.online_num = response.data.online_num
            }
          })
      },

      // 设置为管理员弹窗打开
      setManagerDialogOpen(item){
        if(this.staff.uid !== this.groupData.owner_id){
          this.$message({
            type:'warning',
            message:`只有群主才有权限添加管理员`,
            center:true
          })
          return
        }
        let manager_length = this.groupData.owner_info.length
        if(manager_length >= 6){
          this.$message({
            type:'warning',
            message:`管理员最多5个人！`,
            center:true
          })
          return
        }
        this.UserData = item
        this.setManagerDialogShow = true
      },

      // 确定设为设置管理员
      setManagerHandleWork(){
        let group_id = this.groupData.id
        let uid = Number(this.UserData.uid)
        let data = {
          uid:uid,
          group_id:group_id
        }
        attachManager(data)
          .then(res=>{
            if(res.status === 200){
              this.fetchGroupData()
              this.setManagerDialogShow = false
              this.$message({
                type:'success',
                message:`${this.UserData.full_name}已成为管理员！`,
                center:true
              })
              let obj = {
                uid: this.currentId
              }
              this.changeConversationGroupInfo(obj)
            }else {
              this.$message({
                type:'warning',
                message:`${res.info}！`,
                center:true
              })
              return
            }
          }).catch(err=>{
            this.$message.error(err)
          this.setManagerDialogShow = false
        })
      },

      // 移除管理员弹窗打开
      rmManagerDialogOpen(item){
        if(this.staff.uid !== this.groupData.owner_id){
          this.$message({
            type:'warning',
            message:`只有群主才有权限移除管理员`,
            center:true
          })
          return
        }
        this.UserData = item
        this.rmManagerDialogShow = true
      },
      // 确定移除管理员
      rmManagerHandleWork(){
        let group_id = this.groupData.id
        let uid = Number(this.UserData.uid)
        let data ={
          uid:uid,
          group_id:group_id
        }
        detachManager(data)
          .then(res=>{
            if(res.status === 200){
              this.fetchGroupData()
              this.rmManagerDialogShow = false
              this.$message({
                type:'success',
                message:`${this.UserData.full_name}已取消管理员资格！`,
                center:true
              })
              let obj = {
                uid: this.currentId
              }
              this.changeConversationGroupInfo(obj)
            }
          }).catch(err=>{console.log(err)})
      },

      // 删除群成员提示弹窗
      rmMemberDialogOpen(item){
        this.UserData = item
        this.rmMemberDialogShow = true
      },
      // 确定删除群成员
      rmMemberHandleWork(){
        let group_id = this.groupData.id
        let uid = Number(this.UserData.uid)
        groupQuitGroup(group_id,uid)
          .then(res=>{
            if(res.status === 200){
              this.fetchGroupData()
              this.rmMemberDialogShow = false
              this.$message({
                type:'success',
                message:`${this.UserData.full_name}已移出该群！`,
                center:true
              })
              let obj = {
                uid: this.currentId
              }
              this.changeConversationGroupInfo(obj)
            }
          })
          .catch(err=>{console.log(err)})
      },

      // 关闭设为管理员提示弹窗
      setManagerHandleClose(){
        this.setManagerDialogShow = false
      },
      // 关闭移除管理员提示弹窗
      rmManagerHandleClose(){
        this.rmManagerDialogShow = false
        this.UserData = []
      },
      // 关闭删除群成员提示弹窗
      rmMemberHandleClose(){
        this.rmMemberDialogShow = false
        this.UserData = []
      },
      addMemberHandelOpen(){
        this.member_pop = true
      },
      // 添加员工弹窗关闭
      addMemberHandelClose(){
        this.member_pop = false
      },
      // 选择添加群成员
      addMemberHandleSubmit(uids){
        if(uids.length <= 0){
          this.$message({
            type:'warning',
            message:'至少选择一人',
            center: true
          })
          return
        }
       let group_id = this.groupData.id
        groupInviteToJoin(group_id,uids)
          .then(res=>{
            if(res.status === 200){
              this.$message({
                type:"success",
                message:'成功添加群成员！',
                center:true
              })
              this.member_pop = false
              this.fetchGroupData()
              this.getGroupOnlineNum()
              let obj = {
                uid: group_id
              }
              this.changeConversationGroupInfo(obj)
            }else {
              this.$message.error(res.info)
            }
          }).catch(err=>{console.log(err)})

      },
      // 成员双击发送消息
      memberDbClick(item) {
        if(item.uid == this.staff.uid){
          return
        }
        this.createNewConversation(item)
        this.$router.push('chat')
        this.$parent.$parent.groupDetailShow = false
      },
    },
    components:{HtNoticeDialog,HtAddMemberPop}
  }
</script>

<style scoped>

</style>
