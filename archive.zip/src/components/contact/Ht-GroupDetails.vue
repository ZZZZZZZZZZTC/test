<template>
  <div class="ht-group-details">

    <div class="group-details__tabs">
        <ul>
          <li v-for="(item,index) in currentTabs" :key="index"
              :class="{'active':activeIndex === index}"
              @click="handleTabsCut(index)">
            {{item.name}}
          </li>
        </ul>
    </div>

    <div class="group-details__cont">
      <div class="cont-panel">
          <HtGroupInfo v-if="activeIndex === 0" :currentId="contactGroupId"/>
          <HtGroupMember v-if="activeIndex === 1" :currentId="contactGroupId"/>
          <HtGroupSetting v-if="activeIndex === 2" :currentId="contactGroupId"/>
     </div>
    </div>
  </div>
</template>

<script>
  import {mapGetters, mapActions} from 'vuex'
  import HtGroupSetting from '@/components/contact/Ht-GroupSetting'
  import HtGroupMember from '@/components/contact/Ht-GroupMember'
  import HtGroupInfo from '@/components/contact/Ht-GroupInfo'
  import {getGroupInfo} from "@/api/user";
  import {getGroupOnlineStatus} from "@/api/group";

  export default {
    name: "HtGroupDetails",
    data() {
      return {
        currentTabs:[
          {
            tid:0,
            name:'详情',
            type:'first'
          },
          {
            tid:1,
            name:'成员',
            type:"second"
          },
          {
            tid:2,
            name:'设置',
            type:'third'
          }
        ],
        activeIndex: 0,
        groupData: {},
        online_num:0,
        allMemberNum:0
      }
    },
    watch: {
      contactGroupId(nval) {
        if (nval) {
          this.activeIndex = 0
        }
      }
    },
    computed: {
      ...mapGetters(['contactGroupId'])
    },
    mounted() {},
    methods: {
      ...mapActions([
        'getContactInfoType'
      ]),
      // 标题切换
      handleTabsCut(index){
        this.activeIndex = index
      },
      handleClick(tab, event) {
        // this.fetchGroupData()
      },
    },
    components: { HtGroupSetting, HtGroupMember, HtGroupInfo}
  }
</script>

<style scoped>

</style>
