<template>
  <div class="ht-contact-list">
    <el-tabs class="contact-list__tabs" v-model="activeName">
      <el-tab-pane label="常用" name="first">
        <!--好友列表-->
        <div class="contact-list__body">
          <SmScroll :listenData="contactList" ref="contactListScrollRef">
            <!--固定的两项菜单-->
            <ul class="cl-menu">
              <li class="cl-menu-item" v-for="(item,index) in contactList" :key="index">
                <!--标题-->
                <div class="cl-menu__title tran" :class="{'active':item.opened}"
                     @click="handleContactOpenToggle(item.id)">
                  <span>{{item.title}}</span>
                  <i class="cl-menu-down__arrow iconfont icon-triangle-right tran"></i>
                </div>
                <!--次级菜单-->
                <el-collapse-transition>
                  <ul class="cl-menu__submenu" v-show="item.opened">
                    <li class="cl-submenu__item tran"
                        v-for="(subItem,index) in item.list"
                        :class="{'active':subItem.selected}"
                        @click.stop="handleSelectShowInfo(subItem.id)"
                        @dblclick.stop="createConversation(subItem)"
                        :key="index">
                      <img :src="subItem.avatar" alt="" class="item-avatar">
                      <span class="item-name">{{subItem.name}}</span>
                    </li>
                  </ul>
                </el-collapse-transition>
              </li>
            </ul>
          </SmScroll>
        </div>
      </el-tab-pane>
      <!--群组列表-->
      <el-tab-pane label="群" name="second">
        <div class="contact-list__body">
          <!--群-->
          <SmScroll :listenData="groupsList">
            <ul class="cl-menu">
              <li class="cl-menu-item"
                  v-for="(item,index) in groupsList"
                  :key="index">
                <div class="cl-menu__title tran"
                     @click.stop="handleGroupOpenToggle(item.id)"
                     :class="{'active':item.opened}">
                  <span>{{item.title}}</span>
                  <i class="cl-menu-down__arrow iconfont icon-triangle-right tran"></i>
                </div>
                <el-collapse-transition>
                  <ul class="cl-menu__submenu" v-show="item.opened">
                    <li class="cl-submenu__item tran" v-for="(subItem,index) in item.list" @click="handleSelectShowInfo(subItem.id)"  @dblclick.stop="createConversation(subItem)" :key="index">
                      <img :src="subItem.avatar" alt="" class="item-avatar">
                      <span class="item-name">{{subItem.group_name}}</span>
                    </li>
                  </ul>
                </el-collapse-transition>
              </li>
            </ul>
          </SmScroll>
        </div>
      </el-tab-pane>
      <!--组织架构列表-->
      <el-tab-pane label="组织架构" name="third">
        <div class="contact-list__body">
          <!--组织架构-->
          <SmScroll :listenData="organizeList">
            <ul class="cl-menu">
              <li class="cl-menu-item" v-for="(item,index) in organizeList" :key="index">
                <div class="cl-menu__title tran" :class="{'active':item.opened}"
                     @click.stop="handleOpenedToggle(item.team_sign)">
                  <span>{{item.team_name}}</span>
                  <i class="cl-menu-down__arrow iconfont icon-triangle-right tran"></i>
                </div>
                <el-collapse-transition>
                  <ul class="cl-menu__submenu" v-show="item.opened">
                    <li class="cl-submenu__item tran" v-for="(subItem,index) in item.userList" :key="index" @click.stop="handleSelectShowInfo(subItem.uid)"  @dblclick.stop="createConversation(subItem)">
                      <img :src="subItem.avatar" alt="" class="item-avatar">
                      <span class="item-name">{{subItem.full_name}}-{{subItem.post_name}}</span>
                    </li>
                  </ul>
                </el-collapse-transition>
              </li>
            </ul>
          </SmScroll>
        </div>
      </el-tab-pane>
    </el-tabs>

    <!--创建群组按钮-->
    <el-button
      type="primary"
      class="handle-add-btn"
      title="添加群组"
      @click.native="handleCreateGroup" icon="iconfont icon-jiahao">
      <i class=""></i>
    </el-button>

  </div>
</template>
<script>
  import {mapActions,mapGetters} from 'vuex'
  import {getGroupUserGroupList, getRecentChatList,getUserOrganizeList,getUserInfo,getGroupInfo } from '@/api/user'

  export default {
    name: "HtcontactList",
    data() {
      return {
        activeName: 'first',
        contactList: [
          {
            id: 0,
            title: "我的文件助手",
            opened: false,
            list: [{
              id:'-4',
              name: "我的文件助手",
              avatar: "https://pic2.hanmaker.com/im/20171226/5a41baca09b1b.png",
              selected: false
            }]
          },
          {
            id: 1,
            title: "常用联系人",
            opened: false,
            list: []
          },
          {
            id: 2,
            title: "常用群",
            opened: false,
            list: []
          }
        ],
        groupsList: [],
        organizeList: [],
      };
    },
    computed:{
      ...mapGetters(['contactChangeSync'])
    },
    watch:{
      contactChangeSync(nval){
       if(nval){
         setTimeout(()=>{
           this.fetchGrouplistData()
           this.fetchRecentData()
           this.fetchOrganzeData()
         },20)
       }
     }
    },
    mounted() {
     this.$nextTick(()=>{
       this.fetchGrouplistData()
       this.fetchRecentData()
       this.fetchOrganzeData()
     })
    },
    methods: {
      ...mapActions([
        'getContactUserId',
        'getContactGroupId',
        'getContactInfoType',
        'setContactChangeSync',
        'createNewConversation',
        'setContactInfoFrom',
        'createNewConversation'
      ]),
      // 获取群组列表
      fetchGrouplistData() {
        getGroupUserGroupList()
          .then((res) => {
            if (res.status === 200) {
              let arr = []
              let list = res.data
              arr.push({id: 0, title: '我的群组', opened: true, list: list})
              this.groupsList = arr
              this.setContactChangeSync(false)
            }
          }).catch((err) => {
          console.log(err)
        })
      },
      // 获取最近聊天列表
      fetchRecentData() {
        // 获取常用人以及常用群
        Promise.all([getRecentChatList(1), getRecentChatList(2)])
          .catch(err => {
            console.log(err)
          })
          .then(res => {
            let usersData = res[0].data;
            let groupsData = res[1].data;
            let users = [], groups = [];
            usersData.forEach((item) => {
              users.push({...item, selected: false})
            });
            groupsData.forEach((item) => {
              groups.push({...item, selected: false})
            });
            for(let i = 0;i<this.contactList.length;i++){
              this.contactList[1].list = users
              this.contactList[2].list = groups
            }
            if(groupsData.length > 0){
              this.contactList[2].opened = true
            }
          })
      },
      // 获取组织架构列表分组
      fetchOrganzeData(){
        getUserOrganizeList()
          .catch(err=>{console.log(err)})
          .then(res=>{
            if(res.status === 200){
              let data = res.data
              let arr = []
              data.forEach((item)=>{
                let obj = {
                  ...item,
                  opened:false
                }
                arr.push(obj)
              })
              this.organizeList = arr
            }
          })
      },
      // 改变Store里面的值
      handleSelectShowInfo(id) {
        // 工具函数
        if(id === '-4'){
          let data = {}
          data.uid = id
          data.full_name = '我的文件助手'
          data.avatar = 'https://pic2.hanmaker.com/im/20171226/5a41baca09b1b.png'
          this.createNewConversation(data);
          this.$router.push('chat')
        }else {
          if(id.length > 5){
            setTimeout(()=>{
              this.getContactGroupId(id)
              this.getContactInfoType('G')
              this.setContactInfoFrom('contact')
            },20)
          }else {
            setTimeout(()=>{
              this.getContactUserId(id)
              this.getContactInfoType('U')
              this.setContactInfoFrom('contact')
            },20)
          }
        }
      },
      // 自定义展开收起
      handleContactOpenToggle(id) {
        let item = this.contactList.find((o) => {
          return o.id === id
        });
        if (item.opened) {
          item.opened = false
        } else {
          item.opened = !item.opened
        }
      },
      // 群组展开收起
      handleGroupOpenToggle(id) {
        let item = this.groupsList.find((o) => {
          return o.id === id
        })
        if (item.opened) {
          item.opened = false
        } else {
          item.opened = !item.opened
        }
      },
      // 组织架构展开收起
      handleOpenedToggle(team_sign){
        let item = this.organizeList.find((o) => {
          return o.team_sign === team_sign
        })
        if (item.opened) {
          item.opened = false
        } else {
          item.opened = !item.opened
        }
      },
      //创建群组按钮事件
      handleCreateGroup() {
        this.$emit('handleCreateGroup')
      },
      // 创建爱会话
      createConversation(item){
        let data = {
          avatar:item.avatar,
          full_name:item.name || item.full_name,
          id:item.id || item.uid
        }
        this.createNewConversation(data);
        this.$router.push('chat')
      }
    }
  }
</script>

<style scoped>

</style>
