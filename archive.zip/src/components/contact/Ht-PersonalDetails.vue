<template>
    <div class="ht-person-intro">
      <img :src="userInfo.avatar" alt="" class="person-avatar" @dblclick="showBigImg(userInfo.big_img)">
      <h1 class="person-name" title="查看个人主页">
        <span >{{userInfo.full_name}}</span>
        <i class="iconfont icon-contact-link tran" title="查看个人主页" @click="openUserHomePage"></i>
      </h1>
      <ul class="person-info">
        <li class="clearfix">
          <span class="tit fl">项目组</span>
          <span class="inf fr">{{userInfo.team_name || userInfo.part_name}}</span>
        </li>
        <li class="clearfix">
          <span class="tit fl">职位</span>
          <span class="inf fr">{{userInfo.job_name}}</span>
        </li>
        <li class="clearfix">
          <span class="tit fl">组织架构</span>
          <span class="inf fr">{{userInfo.team_name || userInfo.part_name}}</span>
        </li>
        <li class="clearfix">
          <span class="tit fl">手机号</span>
          <span class="inf fr">{{userInfo.mobile}}</span>
        </li>
        <li class="clearfix">
          <span class="tit fl">工龄</span>
          <span class="inf fr">{{userInfo.working_years}}</span>
        </li>
      </ul>
      <el-button type="primary" class="person-sendmsg__btn" @click.native="createConversation">发送消息</el-button>
    </div>
</template>

<script>
  import {mapGetters,mapActions} from 'vuex'
  import {getUserInfo,getUid2staff} from "@/api/user";

  export default {
        name: "HTPersonIntro",
        data(){
          return{
            userInfo:{},
            user_uid2staff_uid:''
          }
        },
      computed:{
        ...mapGetters([
          'contactUserId',
          'isInClient'
        ])
      },
      watch:{
        contactUserId(nval){
          if(nval){
            this.fetchUserData()
            this.getUserUid2staffData()
          }
        }
      },
      mounted(){
        this.fetchUserData()
        this.getUserUid2staffData()
      },
      methods:{
        ...mapActions([
          'createNewConversation'
        ]),
        fetchUserData(){
          getUserInfo(this.contactUserId)
            .then(res=>{
              this.userInfo = res.data
              console.log(this.userInfo)
            }).catch(err=>{console.log(err)})
        },
        getUserUid2staffData(){
          getUid2staff(this.contactUserId)
            .then(res=>{
              if(res.status === 200){
                this.user_uid2staff_uid = res.data.staff_id
              }
            }).catch(err=>{console.log(err)})
        },
        openUserHomePage(){
            window.openURL(`https://hc.hanmaker.com/staff/${this.user_uid2staff_uid}`)
        },
        createConversation(){
          let data = this.userInfo;
          console.log(data);
          this.createNewConversation(data);
          this.$router.push('chat')
        },
        // 查看大图
        showBigImg(src){
          if(!this.isInClient) return
          let data = {
            url: src,
            uuid: '1111',
            data: []
          }
          data = JSON.stringify(data)
          window.hanClient.showImage(data)
        },
      }
    }
</script>

<style scoped>

</style>
