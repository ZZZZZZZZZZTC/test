import SmScroll from './Sm-Scroll'

SmScroll.install = function(Vue){
    Vue.component('SmScroll', SmScroll);
}

export default SmScroll
