<template>
    <div class="ht-notice-dialog" v-if="dialogShow">
      <div class="dialog-cont">
        <!--关闭按钮-->
        <span class="close-btn" @click="handleClose">
          <i class="iconfont icon-close"></i>
        </span>
        <h1>{{title}}</h1>
        <slot>
          <p>确定要设置<span>xxx</span>为管理员吗？</p>
        </slot>

        <div class="foot-btns">
          <el-button type="primary" class="ft-el__btn" @click="handleWork">确定</el-button>
          <el-button type="default" class="ft-el__btn" @click="handleClose">取消</el-button>
        </div>

      </div>
    </div>
</template>

<script>
    export default {
      name: "HtNoticeDialog",
      props:{
          title:{
            type:String,
            default:'提示'
          },
          dialogShow:{
            type:Boolean,
            default:false
          }
      },
      methods:{
        handleClose(){
          this.$emit('handleClose')
        },
        handleWork(){
          this.$emit('handleWork')
        }
      }
    }
</script>

<style scoped>

</style>
