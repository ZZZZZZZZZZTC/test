<template>
    <div class="ht-pagination">
       <span class="page-item" title="首页" :class="{'disabled': current == 1}" @click="setCurrent(1)">
          <i class="iconfont icon-before"></i>
        </span>
      <span class="page-item" title="上一页" :class="{'disabled': current == 1}" @click="setCurrent(current - 1)">
          <i class="iconfont icon-lastpage"></i>
        </span>
      <span class="page-item" title="下一页" :class="{'disabled': current == page}" @click="setCurrent(current + 1)">
          <i class="iconfont icon-nextpage"></i>
        </span>
      <span class="page-item" title="尾页" :class="{'disabled': current == page}" @click="setCurrent(page)">
          <i class="iconfont icon-last"></i>
        </span>
    </div>
</template>

<script>
    export default {
        name: "Ht-Pagination",
      data(){
          return{
            current: this.currentPage
          }
      },
      props: {
        total: {
          // 数据总条数
          type: Number,
          default: 0
        },
        pageSize: {
          // 每页显示条数
          type: Number,
          default: 10
        },
        currentPage: {
          // 当前页码
          type: Number,
          default: 1
        },
        pagegroup: {
          // 分页条数
          type: Number,
          default: 5,
          coerce: function(v) {
            v = v > 0 ? v : 5;
            return v % 2 === 1 ? v : v + 1;
          }
        }
      },
      computed:{
        page: function() {
          // 总页数
          return Math.ceil(this.total / this.pageSize);
        },
      },
      methods:{
        setCurrent(idx) {
          if (this.current != idx && idx > 0 && idx < this.page + 1) {
            this.current = idx;
            this.$emit("pageChange", this.current);
          }
        }
      }
    }
</script>

<style scoped lang="less">
  .ht-pagination{
    min-width: 94px;
    display: inline-block;
    .page-item{
      cursor: pointer;
      margin: 0 2px;
      display: inline-block;
      &:hover{
        i.iconfont{
          color: #338EFF;
        }
      }
      &.disabled{
        i.iconfont{
          color: #ccc;
        }
      }
    }
  }
</style>
