<template>
  <div class="ht-head-nav">
    <div class="head-nav-head">
      <img :src="staff.avatar"
           @click.stop="showPop"
           v-if="!searchShow"
           class="head-avatar">
      <div class="head-input tran" v-if="!searchShow">
        <i class="input-icon tran iconfont icon-search"></i>
        <input type="text" class="tran" placeholder="搜索联系人" @click="searchShowEvent">
      </div>
    </div>
    <div class="head-nav-body">
      <router-link :to="{name:'chat'}" tag="span" class="link-button" title="聊天">
        <svg class="nav-icon" aria-hidden="true">
          <use xlink:href="#icon-menu-chat"></use>
        </svg>
      </router-link>
      <router-link :to="{name:'contact'}" tag="span" class="link-button" title="通讯录">
        <svg class="nav-icon" aria-hidden="true">
          <use xlink:href="#icon-menu-contact"></use>
        </svg>
      </router-link>
      <router-link :to="{name:'leave'}" tag="span" class="link-button" title="请假">
        <svg class="nav-icon" aria-hidden="true">
          <use xlink:href="#icon-menu-leave"></use>
        </svg>
      </router-link>
    </div>
    <div class="head-nav-foot">
      <div class="feedback" @click.stop="chatWithYm">
        <img src="../assets/img/feedback.png" alt="反馈" v-if="staff.uid!=2041">
      </div>
      <template v-if="isInClient && !isMac">
        <span class="foot-patch" @click="minimize">
          <i class="iconfont icon-minimum"></i>
        </span>
        <span class="foot-patch " @click="maximize">
          <i class="iconfont icon-max"></i>
      </span>
        <span class="foot-patch" @click="closeClient">
          <i class="iconfont icon-close"></i>
        </span>
      </template>

    </div>
    <!--介绍弹窗-->
    <transition name="el-zoom-in-top">
      <HtStaffPop v-show="popShow" @close="closePop" v-click-outside="closePop"/>
    </transition>
    <!--搜索联系人-->
    <transition name="slideleft">
      <HtSearchPanel ref="HtSearchPanel" v-if="searchShow" @close="searchCloseEvent"
                     v-click-outside="searchCloseEvent"/>
    </transition>

  </div>
</template>

<script>
  import {mapGetters,mapActions} from 'vuex'
  import HtStaffPop from '@/components/Ht-StaffPop'
  import HtSearchPanel from '@/components/Ht-SearchPanel'
  import {statistics} from '@/api/chat'

  export default {
    name: "HtHeadNav",
    data() {
      return {
        popShow: false,
        searchShow: false,
      }
    },
    computed: {
      ...mapGetters([
        'staff',
        'isInClient'
      ]),
      isMac() {
        return window.hanClient.isMac
      }
    },
    methods: {
      ...mapActions([
        'createNewConversation'
      ]),
      showPop(e) {
        this.popShow = !this.popShow
      },
      closePop(e) {
        this.popShow = false
      },
      // 打开搜索联系人面板
      searchShowEvent() {
        this.searchShow = true
        //
        this.$nextTick(() => {
          this.$refs.HtSearchPanel.$el.querySelector('.search-input > input[type="text"]').focus()
          statistics('main_search');
        })

      },
      // 关闭搜索联系人面板
      searchCloseEvent() {
        this.$refs.HtSearchPanel.$el.querySelector('.search-input').style.display = 'none'
        this.$refs.HtSearchPanel.$el.querySelector('.search-input > input[type="text"]').blur()
        this.searchShow = false
      },
      minimize() {
        window.hanClient.minimize()
      },
      maximize() {
        window.hanClient.maximize()
      },
      closeClient() {
        window.hanClient.close()
      },
      chatWithYm(){
        // let relationship = structRelationship(this.staff.uid,2041)
        // let data ={
        //   avatar:'https://pic2.hanmaker.com/staff/small/20180410/5acc1989546ac.png',
        //   uid:2041,
        //   full_name:'杨明-hantalk-运营',
        //   relationship:relationship
        // }
        // this.chatCreateConversation(data);
        let data = {
          avatar:'https://pic2.hanmaker.com/staff/small/20180410/5acc1989546ac.png',
          full_name:'杨明-hantalk-运营',
          id:2041
        }
        this.createNewConversation(data);
        this.$router.push('chat')
      }
    },
    components: {HtStaffPop, HtSearchPanel}
  }
</script>

