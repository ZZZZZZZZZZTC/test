<template>
  <div class="ht-staff-pop">
    <div class="staff-pop__head">
      <span>{{staff.full_name}}</span>
    </div>
    <div class="staff-pop__body">
      <ul>
        <li class="target-item tran" @click="openMyHomePage">
          <span class="icon-box">
            <i class="iconfont icon-portrait-personal"></i>
          </span>
          <span>个人主页</span>
        </li>
        <!--<li class="target-item tran">-->
          <!--<span class="icon-box">-->
            <!--<i class="iconfont icon-portrait-setting"></i>-->
          <!--</span>-->
          <!--<span>设置</span>-->
        <!--</li>-->
        <li class="target-item tran statistics-tap__about" @click="about()">
          <span class="icon-box">
            <i class="iconfont icon-portrait-about"></i>
          </span>
          <span>关于</span>
        </li>
        <li class="target-item tran statistics-tap__feedback" @click="handleOpenBugFback">
          <span class="icon-box">
            <i class="iconfont icon-portrait-feedback"></i>
          </span>
          <span>意见反馈</span>
        </li>

        <li class="target-item tran statistics-tap__feedback" @click="editPhoto()">
          <span class="icon-box">
            <i class="iconfont icon-camera"></i>
          </span>
          <span>修改头像</span>
        </li>
      </ul>
    </div>

    <router-link :to="{name:'logout'}" tag="div" class="staff-pop__foot">
        <span class="icon-box">
        <i class="iconfont icon-tuichu"></i>
       </span>
        <span>退出账号</span>
      </router-link>

  </div>
</template>

<script>
  import {mapGetters} from 'vuex'
  import {getUid2staff} from '@/api/user'
  import {statistics} from "@/api/chat";
    export default {
      name: "HtStaffPop",
      props:{
      },
      data(){
        return{
          uid2staff_uid:''
        }
      },
      computed:{
        ...mapGetters([
          'staff'
        ])
      },
      mounted(){
        this.getUid2staffData()
      },
      methods:{
        close(){
          this.$emit('close')
        },
        handleOpenBugFback(){
          statistics('tap_feedback')
          window.openURL("https://hc.hanmaker.com/app_common/index.php?m=bug&a=index")
          this.close()
        },
        getUid2staffData(){
          getUid2staff(this.staff.uid)
            .then(res=>{
              if(res.status === 200){
                this.uid2staff_uid = res.data.staff_id
              }
            }).catch(err=>{console.log(err)})
        },
        // 打开个人主页
        openMyHomePage(){
          window.openURL(`https://hc.hanmaker.com/app_common/index.php?m=staff&a=perpage&id=${this.uid2staff_uid}`)
          this.close()
        },
        editPhoto(){
          window.openURL(`https://hc.hanmaker.com/app_common/index.php?m=staff&a=headimg&id=${this.uid2staff_uid}`)
          this.close()
        },
        //统计
        about(){
          statistics('tap_about')
        }
      }
    }
</script>

<style scoped>
.stop{

}
</style>
