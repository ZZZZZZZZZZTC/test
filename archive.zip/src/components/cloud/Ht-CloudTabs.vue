<template>
    <div class="ht-cloud-tabs">
      qiehua
    </div>
</template>

<script>
    export default {
        name: "HtCloudTabs"
    }
</script>

<style scoped>

</style>
