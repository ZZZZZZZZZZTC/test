<template>
  <div class="ht-cloud ht-main-section">
    <!--标题工具栏-->
    <div class="main-section-menu">
      <!--聊天标题栏-->
      <div class="chat-menu-bar">
        <div class="chat-menu-name">
          云端
        </div>
        <div class="chat-menu-tool">
          <ul class="tool-list clearfix">
            <li class="list-item fl tran"
                v-for="(item,index) in toolbarlist"
                :class="{'active':toolTabShow===item.type}"
                :key="index"
                data-type="chat"
                @click="clickToolTabTargetShow(item)">{{item.name}}</li>
          </ul>
        </div>
      </div>
    </div>
    <!---->
    <div class="main-section-body">
      <!--聊天-->
      云端主体
    </div>
    <!--聊天信息框-->
    <!--聊天信息输入发送框-->
  </div>
</template>

<script>
    export default {
        name: "HtCloudContent"
    }
</script>

<style scoped>

</style>
