<template>
    <!--字体选择按钮-->
    <div class="btns-span tran">
        <!--字体选择-->
        <el-popover :open-delay="100"
                    v-model="popoverVisible"
                    :offset='-60'
                    :visible-arrow="true"
                    placement="top"
                    width="50"
                    trigger="click">
        <span slot="reference">
             <i class="iconfont icon-font"></i>
        </span>
            <!--字体大小选择-->
            <el-select
                    v-model="value"
                    placeholder="请选择"
                    size="mini"
                    @change="sizeChange">
                <el-option
                        v-for="item in options"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                </el-option>
            </el-select>
        </el-popover>
    </div>
</template>

<script>
    export default {
        name: "Ht-ChatSetFont",
        props: {
            fontSize: {
                default: 14,
                required: false
            },
        },
        data() {
            return {
                options: [
                    {
                        value: '12',
                        label: '12'
                    }, {
                        value: '13',
                        label: '13'
                    }, {
                        value: '14',
                        label: '14'
                    }, {
                        value: '15',
                        label: '15'
                    }, {
                        value: '16',
                        label: '16'
                    }, {
                        value: '17',
                        label: '17'
                    }, {
                        value: '18',
                        label: '18'
                    }, {
                        value: '19',
                        label: '19'
                    }, {
                        value: '20',
                        label: '20'
                    }, {
                        value: '21',
                        label: '21'
                    }, {
                        value: '22',
                        label: '22'
                    }, {
                        value: '23',
                        label: '23'
                    }, {
                        value: '24',
                        label: '24'
                    }],
                value: this.fontSize,
                popoverVisible: false
            }
        },
        mounted(){
          this.$nextTick(() => {
              this.value = localStorage.getItem('prefix_fontSize') || 14;
              this.$emit('fontSizeChange', this.value)
          })
        },
        methods: {
            sizeChange() {
                this.popoverVisible = false
                localStorage.setItem('prefix_fontSize',this.value);
                this.$emit('fontSizeChange', this.value)
            }
        }
    }
</script>

<style scoped>

</style>
