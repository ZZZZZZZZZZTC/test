<template>
  <div class="ht-chat-members">
    <div class="mb-show-box">
      <div class="static-search">
        <input type="text" v-model="sWords" placeholder="搜索文档"
               @keydown.enter="searchDocShow">
        <span class="sch-icon" @click.stop="searchDocShow" title="搜索">
          <i class="iconfont icon-search"></i>
        </span>
      </div>
      <div class="faster-enter">
        <div class="enter-title">
          快捷入口
        </div>
        <ul class="enter-list clearfix">
          <li class="list-item fl" :class="{'statistics-tap__meeting':item.name === '会议','statistics-tap__book':item.name == '图书','statistics-tap__institution':item.name == '制度','statistics-tap__document':item.name == '文档','statistics-tap__diagnoses':item.name == '调查分析'}" v-for="(item,index) in rapidOpenUrl" :key="index">
            <a href="javascript:;" @click="openRapidUrl(item.url,item.statisticsType)">{{item.name}}</a>
          </li>
        </ul>
      </div>
    </div>
    <!--群成员列表 如果是群组-->
    <template v-if="currentConversationType === 'G'">
      <div class="mb-cont-box" v-click-outside="filterClose">
        <div class="mb-list__num">
          成员（{{currentChatGroupInfo.onlineCount}}/{{currentChatGroupInfo.members.length}}）
        </div>
        <div class="mb-list__search" ref="searchInputBox">
          <i class="lbs-icon iconfont icon-search" ></i>
          <input type="text"
                 placeholder="搜索成员"
                 v-model="filter"
                 @focus.prevent = "filterFocus"
                 @keydown.down.prevent="selectDown"
                 @keydown.enter.prevent="createConversationByEnter"
                 @keydown.up.prevent="selectUp">
          <i class="clean-icon iconfont icon-deletechat "
             @click.stop="filterClose"></i>
        </div>
        <div class="mb-list__view">
          <SmScroll :listenData="members">
            <ul>
              <li class="mb-list__item"
                  v-for="(item,index) in members"
                  :title="item.full_name" :key="item.uid"
                  @dblclick="createUserConversation(item)"
                  @contextmenu.prevent="contextMenu(item)"
              >
                <img :src="item.avatar"
                     :alt="item.full_name"
                     class="item-avatar"
                     :class="{'offline-state__avatar':item.onLine === false}">
                <span class="item-name">{{item.user_team_post_name}}</span>
                <i class="item-manager-icon iconfont icon-manager" :class="{'creater':(item.group_level==1),'manager':(item.group_level==2)}" v-if="(item.group_level<=2)"></i>
              </li>
            </ul>
          </SmScroll>

          <!--搜索结果-->
          <div class="mb-list__search-result" ref="searchResultbox" v-if="filterList.length > 0">
            <SmScroll :listenData="filterList" ref="filterListScroll">
              <ul>
                <li class="mb-list__item search-list"
                    v-for="(item,index) in filterList"
                    :title="item.full_name"
                    :key="item.uid"
                    @dblclick ='createUserConversation(item)'
                    @contextmenu.prevent="contextMenu(item)"
                    :class="{'active':index === selectIndex}" ref="searchResultLi">
                  <img :src="item.avatar"
                       :alt="item.full_name"
                       class="item-avatar"
                  >
                  <span class="item-name">{{item.user_team_post_name}}</span>
                  <i class="iconfont icon-manager item-manager-icon" :class="{'creater':(item.group_level==1),'manager':(item.group_level==2)}" v-if="(item.group_level<=2)"></i>
                </li>
              </ul>
            </SmScroll>
          </div>
        </div>
      </div>
    </template>
    <!--单聊对方信息 如果是单聊-->
    <template v-else-if="currentConversationType === 'U'">
      <div class="mb-cont-box">
        <div class="oth__side-info">
          <a href="javascript:;" class="user-avatar-home" title="点击查看个人主页" @click="openUserHomePage">
            <img :src="currentChatUserInfo.avatar" alt="" class="oth__side-avatar" @dblclick="showBigImg(currentChatUserInfo.big_img)">
          </a>
          <ul class="oth__side-list">
            <li class="side-list-item">
              <span class="icon-span">
                <i class="iconfont icon-chat-team"></i>
              </span>
              <span class="info-span">{{currentChatUserInfo.team_name}}</span>
              <!--<span class="info-span" v-if="!currentChatUserInfo.team_name">韩创科技</span>-->
            </li>
            <li class="side-list-item">
              <span class="icon-span">
                <i class="iconfont icon-chat-job"></i>
              </span>
              <span class="info-span">{{currentChatUserInfo.job_name}}</span>
            </li>
            <li class="side-list-item">
              <span class="icon-span">
                <i class="iconfont icon-chat-structure"></i>
              </span>
              <span class="info-span">{{currentChatUserInfo.part_name}}</span>
            </li>
            <li class="side-list-item">
              <span class="icon-span">
                <i class="iconfont icon-chat-phone-number"></i>
              </span>
              <span class="info-span">{{currentChatUserInfo.mobile}}</span>
            </li>
            <li class="side-list-item">
              <span class="icon-span">
                <i class="iconfont icon-chat-time"></i>
              </span>
              <span class="info-span">{{currentChatUserInfo.working_years}}</span>
            </li>
          </ul>
        </div>
      </div>
    </template>
  </div>
</template>
<script>
  import {mapGetters, mapActions, mapMutations} from 'vuex'
  import {getUid2staff} from "@/api/user";
  import {statistics} from "@/api/chat";
  export default {
      name: "Ht-ChatMembers",
      props:{},
      data(){
        return{
          filter:'',
          selectIndex:0,
          sWords:'',
          memberList:[],
          filterList:[],
          user_uid2staff_uid:'',
          rapidOpenUrl:[
            {
              name:'会议',
              url:'https://hc.hanmaker.com/activity',
              statisticsType:'tap_meeting'
            },{
              name:'图书',
              url:'https://hc.hanmaker.com/book',
              statisticsType:'tap_book'
            },{
              name:'制度',
              url:'https://hc.hanmaker.com/system',
              statisticsType:'tap_institution'
            },{
              name:'文档',
              url:'https://hc.hanmaker.com/document',
              statisticsType:'tap_document'
            },{
              name:'调查分析',
              url:'https://hc.hanmaker.com/analysis',
              statisticsType:'tap_diagnoses'
            }
          ]
        }
      },
      watch:{
        filter(val){
          console.log(val,this.filter)
          if(val){
            let arr = []
            this.members.forEach((item)=>{
              if (item.user_team_post_name.indexOf(this.filter) != -1){
                arr.push(item)
              }
            })
            this.selectIndex = 0;
            this.filterList = arr
          }else{
            this.filterList = [];
            this.selectIndex = 0;
          }
          console.log(this.filterList,this.memberList)
        },
        'currentChatId':'getUserUid2staffData'
      },
      computed:{
        ...mapGetters([
          'currentChatGroupInfo',
          'currentChatUserInfo',
          'currentChatId',
          'currentConversationRelationship',
          'currentConversationType',
          'currentChatUserOnlineType',
          'staff',
          'currentConversationName',
          'isInClient'
        ]),
        members(){
          return this._.orderBy(this.currentChatGroupInfo.members, ['group_level'], ['asc'])
        },
      },
      created(){
        this.getUserUid2staffData()
      },
      methods:{
        ...mapActions([
          'createNewConversation'
        ]),
        openRapidUrl(url,statisticsType){
          statistics(statisticsType)
          window.openURL(url)
        },
        //创建私聊
        createUserConversation(item){
          console.log(item)
          this.filter =''
          this.createNewConversation(item)
          this.$router.push('chat')
        },
        createConversationByEnter(){
          console.log('enter',this.filterList.length)
          if(this.filterList.length ==0){
            return
          }
          let item = this.filterList[this.selectIndex]
          console.log(item)
          this.filter =''
          this.createNewConversation(item)
          this.$router.push('chat')
        },
        // 搜索结果向下选择
        selectDown() {
          if (!this.filter) {
            return
          }
          this.selectIndex++;
          if (this.selectIndex === this.filterList.length) {
            this.selectIndex = 0;
          }
          this.resultSelectSrcoll(this.selectIndex)
        },
        // 搜索结果向上选择
        selectUp() {
          if (!this.filter) {
            return
          }
          this.selectIndex--;
          if (this.selectIndex === -1) {
            this.selectIndex = this.filterList.length - 1;
          }
          this.resultSelectSrcoll(this.selectIndex)
        },
        // 群组搜索键盘选择
        // 搜索键盘控制滚动
        resultSelectSrcoll(index){
          let yPos = parseInt(this.$refs.searchResultLi[index].offsetTop -
            this.$refs.filterListScroll.getSize.container.height + 42)
          this.$refs.filterListScroll.scrollTo(0,yPos,300)
        },
        //抛出搜索文档
        searchDocShow(){
          this.$emit('handleSearchDocShow',this.sWords)
        },
        filterClose(){
          this.selectIndex = 0
          this.filter = ''
          this.$refs.searchInputBox.removeAttribute('style')
          this.$refs.searchInputBox.querySelector('.lbs-icon').removeAttribute('style')
          this.$refs.searchInputBox.querySelector('.clean-icon').removeAttribute('style')
          this.$refs.searchInputBox.querySelector('input[type="text"]').removeAttribute('style')
          this.$refs.searchInputBox.querySelector('input[type="text"]').setAttribute('placeholder','搜索成员');
        },
        filterFocus(){
          this.$refs.searchInputBox.style.padding = '8px 28px 8px 12px'
          this.$refs.searchInputBox.querySelector('.lbs-icon').style.display = 'none'
          this.$refs.searchInputBox.querySelector('.clean-icon').style.display = 'block'
          this.$refs.searchInputBox.querySelector('input[type="text"]').removeAttribute('placeholder')
          this.$refs.searchInputBox.querySelector('input[type="text"]').style.borderBottom = '1px solid #eee'
        },
        // 查看大图
        showBigImg(src){
          if(!this.isInClient) return
          let data = {
            url: src,
            uuid: '1111',
            data: []
          }
          data = JSON.stringify(data)
          window.hanClient.showImage(data)
        },
        contextMenu(item){
          let self = this;
          if(this.staff.uid == item.uid){
            return
          }
          window.hanClient.runChatMenu({
            menu: 'chat_atta',
            onSuccess(response) {
              let data = JSON.parse(response);
              if (data.type == 'chat_atta') {
                self.$emit('sendMessage',item)
              }
            }
          })
        },
        getUserUid2staffData(){
          getUid2staff(this.currentChatId)
            .then(res=>{
              if(res.status === 200){
                this.user_uid2staff_uid = res.data.staff_id
              }
            }).catch(err=>{console.log(err)})
        },
        openUserHomePage(){
          window.openURL(`https://hc.hanmaker.com/staff/${this.user_uid2staff_uid}`)
        },
      }
    }
</script>
<style scoped>
</style>
