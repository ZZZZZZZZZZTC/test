<template>
  <div class="btns-span tran statistics-send__sticker" v-click-outside='closepanel' ref="emojiRefBox">
    <i class="iconfont icon-emoji" @click.stop.prevent="showpanel"></i>

    <div class="chat-emoji-drop" v-show="dropShow" ref="emojiDropBox">
      <div class="emoji-drop-box">
        <div class="chat-emoji-title"> {{emojiTitle}}  </div>
        <div class="chat-emoji-panle">
          <!--默认的表情-->
          <div class="panle-item defaultEmoji-item"
               ref="chatBoxEmojiPanel" v-show="activeTab===0"
               @click.stop="sendEmoji">
          </div>
          <!--自定义表情-->
          <div class="panle-item custom-item"
               v-show="activeTab!==0">
            <SmScroll :listenData="stickList">
              <ul class="item-list">
                <li v-for="(item,index) in stickList"
                    :key="index" @click.stop="sendExpression(item)">
                  <el-popover
                    placement="top"
                    transition="none"
                    trigger="hover">
                    <img :src="item.preview"
                         slot="reference"
                         :alt="item.description"
                         :title="item.description">
                    <img  :src="item.url" :alt="item.description" :title="item.description" class="view-strck-img">
                  </el-popover>
                </li>
              </ul>
            </SmScroll>
          </div>
        </div>
      </div>
      <!--表情切换栏-->
      <div class="emoji-drop-tab">
        <div class="tab-box">
          <ul class="clearfix tran" ref="tabClickBlock">
            <li class="fl" @click="changeTab(0)">
              <div class="tab-item tran" :class="{'active':activeTab === 0}">
                <img :src="defatutTab.url" :alt="defatutTab.name">
              </div>
            </li>
            <li class="fl"
                v-for="(item,index) in tabsList"
                :key="index" @click="changeTab(item.id,item)">
              <div class="tab-item tran" :class="{'active':activeTab === item.id}">
                <img :src="item.url" :alt="item.name">
              </div>
            </li>
          </ul>
        </div>
        <!--上一个按钮-->
        <span class="prev-btn" v-if="prevNextShow" @click="tabPrevBtn">
          <i class="iconfont icon-zuojiantou"></i>
        </span>
        <!--下一个按钮-->
        <span class="next-btn" v-if="prevNextShow" @click="tabNextBtn">
          <i class="iconfont icon-arrow-right"></i>
        </span>
      </div>
    </div>

  </div>
</template>

<script>
  const TABWIDTH = 60; // 切换块宽度
  import {getStickerGroup, getStickerList,statistics} from '@/api/chat'
  import {getRect} from "@/utils/utils";

  export default {
      name: "Ht-ChatEmoji",
      data(){
        return{
          activeTab:0,
          defatutTab: {
            description: "Emoji",
            id: "0",
            name: "默认表情",
            url: require('@/assets/img/defaul-emoji-tab.png'),
          },
          prevNextShow:false,
          liSize:0,
          emojiTitle:'默认表情',
          stickList:[],
          tabsList:[],
          dropShow:false,
        }
      },
      watch:{
        liSize(nval,oval){
          if(nval > 7){
            this.prevNextShow = true
          }else {
            this.prevNextShow = false
          }
        },
        // 监听获取节点的长度
        dropShow(val){
          if(val){
            this.stickerInit()
            setTimeout(()=>{
              let liSize = this.$refs.tabClickBlock.children.length
              this.liSize = liSize;
            },20);
            let rectTop = this.$refs.emojiRefBox.parentNode.parentNode.parentNode.parentNode
            let rectTopPos = getRect(rectTop).top
            if(rectTopPos <= 200){
              this.$refs.emojiDropBox.style.top = '0.5em'
              this.$refs.emojiDropBox.style.bottom = 'initial'
            }else {
              this.$refs.emojiDropBox.style.top = 'initial'
              this.$refs.emojiDropBox.style.bottom = '2.5em'
            }

          }
        },
      },
      created(){
        this.liIndex = 0;
      },
      mounted(){
        // 初始化融云表情
        this.eventEmojiInit();
        this.stickerInit();
        // console.log(this.dragTopPos,'weizhi')
      },
      methods:{
        tabPrevBtn(){
          let box = this.$refs.tabClickBlock
          this.liIndex--

          if(this.liIndex <= 0){
            this.liIndex = 0
            box.style.left = `0`
          }else {
            box.style.left = `-${TABWIDTH * this.liIndex}px`
          }
        },
        tabNextBtn(){
          let box = this.$refs.tabClickBlock
          if(this.liIndex < this.liSize - 6){
            this.liIndex++
            box.style.left = `-${TABWIDTH * this.liIndex}px`
          }else {
            this.liIndex = 0
            box.style.left = `0`
          }
        },
        //展开表情栏
        showpanel() {
          statistics('send_sticker')
          this.dropShow = !this.dropShow;
        },
        //关闭表情栏
        closepanel() {
          this.dropShow = false
        },
        // 初始化emoji表情
        eventEmojiInit() {
          const _this = this
          const RongIMEmoji = RongIMLib.RongIMEmoji
          const panel = this.$refs.chatBoxEmojiPanel
          // const emojis = RongIMEmoji.emojis
          const emojis = getEmojiDetailList()
          for (let i = 0; i < emojis.length; i++) {
            panel.appendChild(emojis[i])
          }

          // 获取表情详情列表
          function getEmojiDetailList() {
            let shadowDomList = []
            for (let i = 0; i < RongIMEmoji.list.length; i++) {
              let value = RongIMEmoji.list[i]
              shadowDomList.push(value.node)
            }
            return shadowDomList
          }
        },
        //发送emoji表情
        sendEmoji(event) {
          let _this = this
          const e = event || window.event;
          const target = e.target || e.srcElement;
          let data = target.getAttribute("name")
          if (data == null) {
            return
          }
          this.show = false;
          _this.$emit('selectedEmoji', data)
          this.closepanel()
          console.log(data)
        },
        // 初始化表情栏
        stickerInit() {
          getStickerGroup()
            .then(response => {
              if (response.status == 200) {
                let emData = response.data
                this.tabsList = emData
              }
            })
            .catch(error => {console.log(error)})
        },
        // 切换表情
        changeTab(id,item){
          this.activeTab = id;
          if(id !== 0){
            this.emojiTitle = item.description
            getStickerList(id)
              .then(response=>{
                if(response.status===200){
                  this.stickList = response.data;
                }
              })
              .catch(error=>{console.log(error)})
          }else {
            this.emojiTitle = '默认表情'
            this.stickList = []
          }

        },
        // 发送自定义表情
        sendExpression(data) {
          this.$emit('sendBiaoQingBaoZi', data)
          this.closepanel()
        },
      }
    }
</script>

<style scoped>
  .view-strck-img{
    max-width: 150px;
    height: auto;
  }
</style>
