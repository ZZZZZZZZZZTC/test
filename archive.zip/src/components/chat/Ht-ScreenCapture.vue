<template>
  <div class="btns-span tran screen-capture">
    <span class="statistics-screenshots"  @click="handlerCaptureClick">
      <i class="iconfont icon-capture"></i>
    </span>
    <!--截图选项-->
   <el-popover :open-delay="100"
               v-model="popoverVisible"
               :offset='80'
               popper-class="screen-capture__ways"
               :visible-arrow="true"
               placement="bottom"
               width="220"
               trigger="click">
             <span class="select-down"  slot="reference">
              <i class="down-arrow tran"></i>
            </span>
            <!--截屏选项切换-->
            <ul>
               <li class="check-li tran" @click="popoverVisible = false;browserWindowHide = false">
                 <i class="iconfont icon-duihao" v-show="browserWindowHide == false"></i>
                 <span>屏幕截图(Ctrl+Alt+S)</span>
               </li>
               <li class="check-li tran" @click="popoverVisible = false;browserWindowHide = true">
                 <i class="iconfont icon-duihao" v-show="browserWindowHide == true"></i>
                 <span>截图时隐藏当前窗口</span>
               </li>
            </ul>
    </el-popover>
  </div>
</template>

<script>
  const SCREEN_CAPTURER_TYPE = 'hc_im_screen_capturer_type'
  import {statistics} from '@/api/chat'
  export default {
    name: "HtScreenCapture",
    mounted() {
      this.browserWindowHide = parseInt(localStorage.getItem(SCREEN_CAPTURER_TYPE)) > 0 ? true : false
    },
    data() {
      return {
        domain: '',
        expires: 0,
        saveKeyPrefix: '',
        upToken: '',
        popoverVisible:false,
        browserWindowHide: false
      };
    },

    computed: {},

    watch: {
      browserWindowHide(val) {
        localStorage.setItem(SCREEN_CAPTURER_TYPE, val ? 1 : 0)
      }
    },

    methods: {
      // 处理截图点击
      handlerCaptureClick() {
        let _this = this
        statistics('screenshots');
        window.hanClient.screenShot({
          mainBrowserWindowHide: _this.browserWindowHide,
          onSuccess: function(response) {
            // console.log(response)
            // _this.handleGetCaptureImg(response)
            let data = JSON.parse(response)
            _this.$emit('handleCaptureImg',data)
          },
          onFailure: function(error_code, error_message) {}
        })
      }
    },

    components: {}
  }
</script>

<style scoped>

</style>
