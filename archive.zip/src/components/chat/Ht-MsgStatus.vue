<template>
    <span>
      <!--发送中-->
        <img v-if="msgData.sentStatus == 1" src="@/assets/img/msg-loading.gif" alt="" title="发送中" class="msg-status-icon">
      <!--未读-->
        <span v-if="msgData.sentStatus == 2" class="msg-status-icon noread status-span">已送达</span>
      <!--已读-->
        <span v-if="msgData.sentStatus == 4" class="msg-status-icon readed status-span">已读</span>
      <!--发送失败-->
        <i v-if="msgData.sentStatus == 10" class="iconfont icon-message-fail msg-status-icon failed" title="发送失败，点击重新发送" @click="resend"></i>
    </span>
</template>

<script>
  export default {
    name: "Ht-MsgStatus",
    data() {
      return {}
    },
    props: {
      msgData: {
        type: Object,
        default() {
          return {}
        }
      }
    },
    methods:{
      resend(){
        // 重新发送
        this.$emit('resend')
      }
    }
  }
</script>

<style scoped>

</style>
