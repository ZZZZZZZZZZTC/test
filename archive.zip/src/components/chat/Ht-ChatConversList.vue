<template>
  <div class="ht-convers-list" ref="conversList">
    <!--待办列表-->
    <div class="upcoming statistics-tap__todo"
         :class="{'common-hidden':leftBarStatus <=1,'last-hidden':leftBarStatus==0}"
         @click="openMissonUrl">
      <img src="../../assets/img/daiban.png" alt="待办"><span>待办 · {{missionNum}}</span>
    </div>
    <!--会话列表-->
    <div class="convers-list-main">
      <SmScroll class="warpper"
                ref="ConverScrollWrapper"
                :listen-data="showConversationList">
        <ul ref="ConverListItem">
          <li class="list-item tran"
              v-for="(item,index) in showConversationList"
              :key="item.relationship"
              :class="{
              'rm-small-show right-hidden':leftBarStatus===0,
              'common-hidden':leftBarStatus<=1,
              'time-hidden':leftBarStatus<=2,
              'active':item.uid ==currentChatId
              }"
              @click.stop="handleConversationChange(item)"
              @contextmenu="stickChatToTop($event,item)"
             >
            <div class="item-avatar">
              <!--offline-state__avatar 离线显示的类名，头像为灰色-->
              <img :src="item.avatar" :title="item.full_name" :alt="item.full_name"
                   :class="{'offline-state__avatar':!currentChatUserOnlineType}">
              <!--小关闭按钮-->
              <i class="remove-small-button iconfont icon-deletechat" @click.stop="delConversation(item)"></i>
              <!--新消息条数提示-->
              <!--没有屏蔽的时候，消息提示用nomarl  屏蔽的时候用shielded-->
              <i class="news-num-point normal" :class="{'shielded':item.isDisturb}" v-show="item.unreadMessageCount>0">{{item.unreadMessageCount}}</i>
            </div>

            <div class="right-cont">
              <div class="cont-main">
                <div class="item-info">
                  <!--时间-->
                  <p class="user-time">{{item.sentTime | chatSimTimeFormat}}</p>
                  <!--用户名-->
                  <div class="info-user" :title="item.full_name">
                    {{item.full_name}}
                  </div>
                  <!--最后一条信息-->
                  <div class="info-common">
                    <span>{{item.content}}</span>
                  </div>
                </div>

              </div>
              <!--关闭按钮-->
              <div class="item-remove tran">
                <i class="remove-button iconfont icon-deletechat" @click.stop="delConversation(item)"></i>
              </div>
            </div>

            <!--置顶图标-->
            <i class="stick-top-label" v-show="item.ConversationToTop"></i>
          </li>
        </ul>
      </SmScroll>

    </div>
    <!--拖动遮罩-->
    <div class="left-box-drag-mask" ref="leftBoxdragMask"></div>
    <!--拖拽线-->
    <div class="left-box-drag-line"
         ref="leftBoxdragLine"
         @mousedown="dragMove"
         v-if="$route.name === 'chat'">
    </div>
  </div>
</template>

<script>
  // import SmScroll from '@/components/base/Sm-Scroll'
  import {hover,addClass,removeClass} from '@/utils/utils'
  import {mapGetters, mapActions, mapMutations} from 'vuex'
  import {checkGroupStatus} from '@/api/group'
  import {getUndoMission,stickChatTop,statistics} from '@/api/chat'
  // 假数据
  export default {
    name: "HtConversList",
    data() {
      return {
        leftBarStatus:3,
        missionNum:0,
        missionUrl:''
      }
    },
    watch:{
      conversationList(val){
        // this.conversationStorage(val)
      }
    },
    computed:{
      ...mapGetters([
        'conversationList',
        'currentChatId',
        'currentConversationRelationship',
        'currentConversationType',
        'currentChatUserOnlineType',
        'staff',
        'currentConversationName',
        'eventErrorInfo',
        'clientWidthOffset',
        'stickList',
        'sendMessageWays',
        'hasNewTrayMessage',
        'isSendMessage',
        'userConfig',
        'shieldConversationList'
      ]),
      showConversationList() {
        return this._.orderBy(this.conversationList, ['ConversationToTop','sentTime'], ['desc','desc'])
      },
      networkError(){
        return true
      }
    },
    methods: {
      ...mapActions([
        'setConversationStickStatus',
        'deleteConversation',
        'changeConversation',
        'resetChatStore',
        'conversationStorage'
      ]),
      dragMove(e) {
        let conversListBox = this.$refs.conversList,
          dgLine = this.$refs.leftBoxdragLine;
        let _this = this;
        let disX = (e || window.event).clientX;
        dgLine.left = dgLine.offsetLeft;
        document.onmousemove = function (e) {
          var e = e || window.event;
          let pos = dgLine.left + (e.clientX - disX);
          (pos >= 256) && (pos = 256);
          (pos <= 0 || pos <= 64) && (pos = 64);
          localStorage.setItem('dragPos', pos);
          _this.dragPos(pos)
          // 改变宽度
          conversListBox.style.width = pos + "px";
          dgLine.style.left = '100%'
          _this.$refs.leftBoxdragMask.style.display = 'block'
          if (pos >= 256 || (pos >= 0 && pos <= 64) || pos < 0) {
            return false
          }
          return false
        };
        document.onmouseup = function () {
          document.onmousemove = null;
          document.onmouseup = null;
          dgLine.releaseCapture && dgLine.releaseCapture()
          _this.$refs.leftBoxdragMask.style.display = 'none'
        };
        dgLine.setCapture && dgLine.setCapture();
        return false
      },
      dragPos(val) {
        if(val<90){
          this.leftBarStatus =0
        }else if(val<150){
          this.leftBarStatus =1
        }else if(val<250){
          this.leftBarStatus =2
        }else{
          this.leftBarStatus =3
        }
      },
      handleConversationChange(item){
        if(item.unreadMessageCount > 0){
          window.hanClient.readMsgByUuid(item.uid)
        }

        if(item.uid>1000000){
          checkGroupStatus(item.uid)
            .then(response=>{
              if(response.status==200){
                if(response.data.status==1){
                  this.changeConversation(item)
                }else{
                  this.deleteConversation(item.uid)
                  this.resetChatStore()
                  this.$message.info('该群已解散')
                }
              }
            })
            .catch(error=>{
              console.log(error)
            })
        }else{
          this.changeConversation(item)
        }
      },
      delConversation(item){
        this.deleteConversation(item.uid)
        this.resetChatStore()
      },
      // 置顶聊天
      stickChatToTop(e, item) {
        console.log(2333)
        e.preventDefault();
        let type = item.relationship.slice(item.relationship.length - 1, item.relationship.length)
        switch (type) {
          case 'U':
            type = 1
            break;
          case 'G':
            type = 3
            break;
          case 'T':
            type = 4
            break;
          case 'M':
            type = 5
            break;
          default:
            break;
        }
        // if (type > 3) {
        //   return
        // }
        let _this = this;
        if (item.ConversationToTop) {
          window.hanClient.runChatMenu({
            menu: 'chat_top,chat_notop',
            onSuccess(response) {
              let data = JSON.parse(response)
              if (data.type == 'chat_notop') {
                stickChatTop(item.uid, type, 0)
                  .then(response => {
                    if(response.status ==200){
                      //取消置顶
                      let odata = {
                        uid:item.uid,
                        type:'del'
                      };
                      _this.setConversationStickStatus(odata)
                      console.log(response)
                    }
                  })
                  .catch(error => console.error(error))
              } else if (data.type == 'chat_top') {
                stickChatTop(item.uid, type, 1)
                  .then(response => {
                    if(response.status ==200){
                      //置顶
                      let odata = {
                        uid:item.uid,
                        type:'add'
                      };
                      _this.setConversationStickStatus(odata)
                      console.log(response)
                    }
                  })
                  .catch(error => console.error(error))
              }
            }
          })
        } else {
          window.hanClient.runChatMenu({
            menu: 'chat_top',
            onSuccess(response) {
              let data = JSON.parse(response)
              if (data.type == 'chat_top') {
                stickChatTop(item.uid, type, 1)
                  .then(response => {
                    if(response.status ==200){
                      //置顶
                      let odata = {
                        uid:item.uid,
                        type:'add'
                      };
                      _this.setConversationStickStatus(odata)
                      console.log(response)
                    }
                  })
                  .catch(error => console.error(error))
              }
            }
          })
        }
      },
      // 跳转待办
      turnMission(){
        getUndoMission()
          .then(response=>{
            this.missionUrl=response.data.url ? response.data.url : 'https://mission.hanmaker.com/project/board';
            this.missionNum=response.data.num ? response.data.num : '0';
          })
          .catch(error=>console.log(error))
      },
      // 打开代办
      openMissonUrl(){
        statistics('tap_todo')
        window.openURL(this.missionUrl)
      }
    },
    mounted() {
      let _this =  this;
      this.turnMission();
      let getMission = setInterval(()=>{
        _this.turnMission()
      },1000*60*15)

      setTimeout(()=>{
        if (this.$route.name === 'chat') {
          // 处理回话栏宽度
          let dPos = Number(localStorage.getItem('dragPos')) || 256;
          this.dragPos(dPos);
          if (dPos !== '') {
            this.$refs.conversList.style.width = this.$refs.leftBoxdragLine.style.left = dPos + 'px'
          }
        }
      },100)
    }
  }
</script>

<style scoped>

</style>
