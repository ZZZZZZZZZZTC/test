<template>
    <div class="chat-setting-space">
      <ul>
        <li class="setting-li tran" @click="handleShowInfo">
           <span class="li-title"> 查看资料</span>
        </li>
        <li class="setting-li tran" @click="addMemberHandelOpen" v-if="isCreater || isManager || isPrivate">
          <span class="li-title">邀请员工入群</span>
        </li>
        <li class="setting-li tran">
         <span class="li-title"> 群消息设置<i class="iconfont icon-triangle-right set-arrow tran"></i></span>
          <!--下拉菜单-->
          <transition name="el-zoom-in-top">
            <ul class="drop-box tran">
              <li class="drop-item" @click="handleUnShieldGroup"><i class="iconfont icon-duihao" v-if="shieldMsgRadio === 1"></i>接收所有消息并提醒</li>
              <li class="drop-item" @click="handleShieldGroup"><i class="iconfont icon-duihao" v-if="shieldMsgRadio === 2"></i>仅接收@我的消息并提醒</li>
            </ul>
          </transition>
        </li>
        <li class="setting-li tran" @click="handleMoreSetting">
          <span class="li-title">更多设置</span>
        </li>
        <template v-if="isCreater || isManager">
          <li class="setting-li tran" @click="handleGroupRemoveShow">
            <span class="li-title">解散群组</span>
          </li>
        </template>
        <template v-else>
          <li class="setting-li tran" @click="handleGroupQuitShow">
            <span class="li-title">退出群</span>
          </li>
        </template>
      </ul>

      <!--退出弹窗-->
      <HtNoticeDialog :dialogShow="quitGroupDialog"
                      @handleWork="handleGroupQuit"
                      @handleClose="handleGroupQuitClose">
        <p class="default-arrfim">
          确定要退出群组<span>{{currentChatName}}</span>吗？
        </p>
      </HtNoticeDialog>
      <!--解散群组-->
      <HtNoticeDialog :dialogShow="removeGroupDialog"
                      @handleWork="handleGroupRemove"
                      @handleClose="handleGroupRemoveClose">
        <p class="default-arrfim">
          确定要解散群组<span>{{currentChatName}}</span>吗？
        </p>
      </HtNoticeDialog>

      <!--添加群成员-->
      <HtAddMemberPop v-if="member_pop" :uids="[]"
                      @handleClose="addMemberHandelClose"
                      @handleSubmit="addMemberHandleSubmit"/>
    </div>
</template>

<script>
  import {mapGetters,mapActions} from 'vuex'
  import {groupQuit,groupInviteToJoin,groupDismiss,shieldGroup,unShieldGroup} from '@/api/group'
  import {getGroupInfo} from "@/api/user"
  import HtNoticeDialog from '@/components/base/Ht-NoticeDialog'
  import HtAddMemberPop from '@/components/contact/Ht-AddMemberPop'
    export default {
      name: "HtSettingFrame",
      data(){
        return{
          quitGroupDialog:false,
          removeGroupDialog:false,
          member_pop:false,
          groupData:{},
          groupOwnerInfo:[],
          shieldMsgRadio:1
        }
      },
      mounted(){
        this.fetchGroupData()
        this.isInShieldList()
        console.log(this.groupData,9090909090909090909)
      },
      computed:{
        ...mapGetters([
          'staff',
          'currentChatName',
          'currentChatId',
          'currentChatGroupInfo',
          'shieldConversationList'
        ]),
        // 创建者
        isCreater(){
          return this.staff.uid === this.groupData.owner_id
        },
        // 管理员
        isManager(){
          this.$nextTick(()=>{
            let uid = this.staff.uid
            let bool = false
            let item = this.groupOwnerInfo.find((o)=>{
              return o.uid === uid
            })
            if(item){
              (item.group_level == 2) && (bool = true)
            }
            return bool
          })
        },
        // 有邀请权限
        isPrivate(){
         return this.groupData.private_type === '1' ? true : false
        }
      },
      methods:{
        ...mapActions([
          'deleteConversation',
          'setContactChangeSync',
          'createNewConversation',
          'changeConversation',
          'addShildItem',
          'delShildItem'
        ]),
        isInShieldList(){
          this.shieldMsgRadio = this.shieldConversationList.some(x=> x ===this.currentChatId) ? 2 : 1
        },
        // 获取群组成员数据
        fetchGroupData(){
          getGroupInfo(this.currentChatId)
            .then(res => {
              if (res.status === 200) {
                let userList = res.data.group_user_list
                // 默认管理员为第一位显示
                for (let i = 0; i < userList.length; i++) {
                  userList.sort((a,b)=> a.group_level - b.group_level)
                }

                this.groupData = res.data
                console.log(res.data,'098098098098')
                this.groupOwnerInfo = res.data.owner_info
              }
            }).catch(err => {
            console.log(err)
          })
        },
        // 关闭弹窗
        closePanel(){
          this.$emit('closePanel')
        },
        // 退出群组
        handleGroupQuit(){
          groupQuit(this.currentChatId)
            .then(res=>{
              if(res.status === 200){
                this.$message({
                  type:'success',
                  message:'退出群组成功！',
                  center:true
                });
                this.setContactChangeSync(true)
                this.deleteConversation(this.currentChatId)
              }else {
                this.$message({
                  type:'error',
                  message:res.info,
                  center:true
                })
              }
              this.quitGroupDialog = false
            })
        },
        handleGroupQuitShow(){
          this.quitGroupDialog = true
        },
        handleGroupQuitClose(){
          this.quitGroupDialog = false
        },
        handleGroupRemove(){
          groupDismiss(this.currentChatId)
            .then(res=>{
              if(res.status === 200){
                this.$message({
                  type:'success',
                  message:'解散群组成功！',
                  center:true
                });
                this.setContactChangeSync(true)
                this.deleteConversation(this.currentChatId)
              }else {
                this.$message({
                  type:'error',
                  message:res.info,
                  center:true
                })
              }
              this.removeGroupDialog = false
            })
        },
        // 解散群组
        handleGroupRemoveShow(){
          this.removeGroupDialog = true
        },
        handleGroupRemoveClose(){
          this.removeGroupDialog = false
        },
        // 添加成员
        addMemberHandelOpen(){
          this.$emit('addMemberHandelOpen')
          this.closePanel()
        },

        // 查看资料
        handleShowInfo(){
          this.$emit('handleShowInfo')
          this.closePanel()
        },
        // 更多设置
        handleMoreSetting(){
          this.$emit('handleMoreSetting')
          this.closePanel()
        },
        // 取消屏蔽
        handleUnShieldGroup(){
          this.shieldMsgRadio = 1
          unShieldGroup(this.currentChatId)
            .then(response => {
              if(response.status === 200){
                this.delShildItem(this.currentChatId)
                console.log(response.data,'取消屏蔽成功')
              }
              this.closePanel()
            })
            .catch(error => console.error(error))
        },
        // 设置屏蔽
        handleShieldGroup(){
          this.shieldMsgRadio = 2
          shieldGroup(this.currentChatId)
            .then(response => {
              if(response.status === 200){
                this.addShildItem(this.currentChatId)
                console.log(response.data,'设置屏蔽成功')
              }
              this.closePanel()
            })
            .catch(error => console.error(error))
        }
      },
      components:{HtNoticeDialog,HtAddMemberPop}
    }
</script>

<style scoped>

</style>
