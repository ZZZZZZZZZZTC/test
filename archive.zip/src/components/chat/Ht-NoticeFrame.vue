<template>
    <div class="section-work-space chat-notice-space">
      <div class="handle-notice-bar">
        <span>共3个公告</span>
        <el-button type="primary" class="public-notice__button">发布新公告</el-button>
      </div>
      <div class="handle-notice-body">
        <div class="notice-list__cont">
          <SmScroll>
            <ul>
              <li class="notice-list__item" v-for="(item,index) in noticeList" :key="index">
                <h3>{{item.title}}</h3>
                <div class="item-info" v-html="item.cont">
                  <!--小伙伴们进群请先改备注~~~格式：姓名-项目组-职位<br>-->
                  <!--本群所涉所有商业交流讨论（如商业模式、数据信息等）均不得外传，仅限本群成员内部交流及知晓，<br>-->
                  <!--群成员应严格遵守保密义务，否则按照公司重大违纪处理。-->
                </div>
                <div class="item-bar">
                  <div class="handle-btns">
                    <span class="h-btn">编辑</span>
                    <span class="h-btn">删除</span>
                  </div>
                  <div class="handle-state">
                    <span class="public-info">
                      <span>{{item.author}}</span>
                      发表于
                      <span>{{item.creatTime}}</span>
                    </span>
                    <span class="readed-num">{{item.readNum}}人已读</span>
                  </div>
                </div>
              </li>
            </ul>
          </SmScroll>
        </div>
      </div>
    </div>
</template>

<script>
  import axios from 'axios'
    export default {
        name: "HtNoticeFrame",
      data(){
          return{
              noticeList:[]
          }
      },
      created(){
        // this.fetchNoticeData()
      },
      methods:{
        fetchNoticeData(){
          axios.get('../../static/testData/chatNotice.json').then((res)=>{
            let data = res.data
            this.noticeList = data.data
          })
        }
      }
    }
</script>

<style scoped>

</style>
