<template>
  <div class="ht-msg-record">
    <div class="record-title">
      <span class="name">消息记录</span>
      <span class="back-icon" @click="recordClose">
          <i class="iconfont icon-close"></i>
        </span>
    </div>
    <div class="record-cont" v-loading="loading" ref="recordContScroll">
      <!--<SmScroll :listen-data="hisMessage" init-pos="bottom" ref="hisMessageScrollBar">-->
      <p v-if="isObjEmpty(hisMessage)" class="msg-empty">暂无消息记录~</p>
      <ul v-else>
        <li class="msg-item" v-for="(block,index) in hisMessage" :key="block.time">
          <div class="his-time">
            <span class="time-box">{{block.time}}</span>
          </div>
          <div class="his-main tran" v-for="item in block.list" :key="item.id">
            <!--系统提示消息 如退群进群提示-->
            <template v-if="item.msg_type_str === 'RC:InfoNtf'">
              <p style="text-align: center;padding: 5px 0;font-size: 12px;color: #338EFF"><span class="time">{{item.timeline | unixDateFormat('HH:mm')}}</span>
              </p>
              <div class="part-sys">
                <div class="system-msg">
                      <span class="system-msg__info">
                        {{item.content}}
                      </span>
                </div>
              </div>
            </template>

            <!--其余不是系统提示消息的消息类型-->
            <template v-else>
              <p class="main-info" :class="{'self':item.from_id === staff.uid}">
                <span class="name" v-html="item.user_team_post_name"></span>
                <span class="time">{{item.timeline | unixDateFormat('HH:mm')}}</span>
              </p>
              <div class="main-part">
                <!--消息类型分类-->
                <!--文件消息-->
                <template v-if="item.msg_type_str === 'RC:FileMsg'">
                  <div class="part-file">
                    <div class="message-file-views">
                      <div class="fv-cont">
                        <div class="cont-img">
                          <!--文件图标 分类-->
                          <!--PSD 文件-->
                          <template v-if="/\.(psd)(\?.*)?$/.test(item.content.type)">
                            <svg class="img-svg-icon psd-icon" aria-hidden="true">
                              <use xlink:href="#icon-psd"></use>
                            </svg>
                          </template>
                          <!--word 文件-->
                          <template v-else-if="/\.(doc|docx)(\?.*)?$/.test(item.content.type)">
                            <svg class="img-svg-icon word-icon" aria-hidden="true">
                              <use xlink:href="#icon-word"></use>
                            </svg>
                          </template>
                          <!--Excel 文件--->
                          <template v-else-if="/\.(xlsx|xls|xlsm|xlt|xltx|xltm)(\?.*)?$/.test(item.content.type)">
                            <svg class="img-svg-icon excel-icon" aria-hidden="true">
                              <use xlink:href="#icon-excel"></use>
                            </svg>
                          </template>
                          <!--txt 文件-->
                          <template v-else-if="/\.(txt)(\?.*)?$/.test(item.content.type)">
                            <svg class="img-svg-icon txt-icon" aria-hidden="true">
                              <use xlink:href="#icon-txt"></use>
                            </svg>
                          </template>
                          <!--PPT 文件-->
                          <template v-else-if="/\.(ppt|pptx)(\?.*)?$/.test(item.content.type)">
                            <svg class="img-svg-icon ppt-icon" aria-hidden="true">
                              <use xlink:href="#icon-ppt"></use>
                            </svg>
                          </template>
                          <!--图片 文件-->
                          <template v-else-if="/\.(png|jpe?g|gif|svg|jpg)(\?.*)?$/.test(item.content.type)">
                            <svg class="img-svg-icon" aria-hidden="true">
                              <use xlink:href="#icon-tupian"></use>
                            </svg>
                          </template>
                          <!--压缩包 文件-->
                          <template v-else-if="/\.(rar|cab|arj|lzh|tar|uue|jar)(\?.*)?$/.test(item.content.type)">
                            <svg class="img-svg-icon" aria-hidden="true">
                              <use xlink:href="#icon-rar"></use>
                            </svg>
                          </template>
                          <template v-else-if="/\.(zip|7-zip|gzip|7z|z)(\?.*)?$/.test(item.content.type)">
                            <svg class="img-svg-icon zip-icon" aria-hidden="true">
                              <use xlink:href="#icon-zip"></use>
                            </svg>
                          </template>
                          <!--xmind 文件-->
                          <template v-else-if="/\.(xmind)(\?.*)?$/.test(item.content.type)">
                            <svg class="img-svg-icon xmind-icon" aria-hidden="true">
                              <use xlink:href="#icon-xmind"></use>
                            </svg>
                          </template>
                          <!--pdf 文件-->
                          <template v-else-if="/\.(pdf)(\?.*)?$/.test(item.content.type)">
                            <svg class="img-svg-icon pdf-icon" aria-hidden="true">
                              <use xlink:href="#icon-pdf"></use>
                            </svg>
                          </template>
                          <!--AI-->
                          <template v-else-if="/\.(ai)(\?.*)?$/.test(item.content.type)">
                            <svg class="img-svg-icon ai-icon" aria-hidden="true">
                              <use xlink:href="#icon-ai"></use>
                            </svg>
                          </template>
                          <!--其他文件-->
                          <template v-else>
                            <svg class="img-svg-icon default-icon" aria-hidden="true">
                              <use xlink:href="#icon-default"></use>
                            </svg>
                          </template>
                        </div>

                        <div class="cont-info">
                          <div class="info-name clearfix">
                            <p class="name-p fl" :title="item.content.name">{{item.content.name}}</p>
                          </div>
                          <div class="info-status">
                            <!--状态-->
                            <div class="status-tips">
                              <span class="size-span fl">({{item.content.size | getFileSize}})</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="fv-handle">
                        <div class="handle-btns">
                          <template v-if="item.downType === 'noDown'">
                            <el-button type="text" class="btns-fileData" @click="downloadFrameFile(item)">下载</el-button>
                            <el-button type="text" class="btns-fileData" @click="downloadOtherFile(item)">另存为
                            </el-button>
                          </template>
                          <el-button v-if="item.downType === 'downloading'" type="text" class="btns-fileData" disabled>
                            下载中...
                          </el-button>
                          <template v-if="item.downType === 'downloaded'">
                            <el-button type="text" class="btns-fileData" @click="openFile">打开</el-button>
                            <el-button type="text" class="btns-fileData" @click="openDir">打开文件夹</el-button>
                          </template>
                          <el-button type="text" class="btns-fileData" @click="handleTransFilePopShow(item)">转发
                          </el-button>

                        </div>
                      </div>
                    </div>
                  </div>
                </template>
                <!--图片消息-->
                <template v-else-if="item.msg_type_str === 'RC:ImgMsg'">
                  <div class="part-img">
                    <img v-lazy="item.content.content" alt="图片" @dblclick="showBigImg(item.content.content)">
                  </div>
                </template>
                <!--表情消息-->
                <template v-if="item.msg_type_str === 'HC:StickerMsg'">
                  <div class="part-img" :title="item.content.name">
                    <img :src="item.content.path" :alt="item.content.name">
                  </div>
                </template>
                <!--语音消息-->
                <template v-else-if="item.msg_type_str === 'RC:VcMsg'">
                  <HtMessageVoice :voiceData.sync="item" :voiceType="'recordVoice'"
                                  :currentPlayVoiceMsgId="currentPlayVoiceMsgId"
                                  @changeCurrentPlayId="changeCurrentPlayId"
                  />
                  <!--<div class="part-voice">-->
                  <!--<div class="message-voice-views" @click="handleControlVoice(item,item.id)">-->
                  <!--<audio :src="'data:audio/wav;base64,'+item.content.content" hidden @ended=over() @loadedmetadata="init($event,item)"></audio>-->
                  <!--<span class="voice-time">{{item.content.duration}}</span>-->
                  <!--<div class="voice-back other-bg-pause"-->
                  <!--:class="{'other-bg-running':voiceIndex===index}"></div>-->
                  <!--</div>-->
                  <!--</div>-->
                </template>
                <!--文档信息-->
                <template v-else-if="item.msg_type_str === 'RC:ImgTextMsg'">
                  <div class="part-doc">
                    <div class="message-docs-views">
                      <a class="docs-views-cont" href="javascript:;"
                         @click="openWindowDocs(item.content.extra.cont)" target="_blank">
                        <img :src="item.content.imgUrl || item.content.extra.image" alt="" class="dvc-img">
                        <div class="dvc-info">
                          <p class="info-title" :title="item.content.title" v v-html="item.content.title"></p>
                          <div class="info-intro" v-html="item.content.content"></div>
                        </div>
                      </a>
                      <div class="docs-view-state">
                        <div class="dvc-name clearfix">
                          <span class="fl">{{item.content.extra.username}}</span>
                        </div>
                        <div class="dvc-state">
                          <el-button class="state-btn" type="text" @click="handleTransDocsPopShow(item)">分享
                          </el-button>
                          <a href="javascript:;" target="_blank" @click="openWindowDocs(item.content.extra.cont)">
                            <el-button class="state-btn" type="text">打开</el-button>
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                </template>
                <!--富文本消息-->
                <template v-else-if="item.msg_type_str === 'HC:TextImage'">
                  <!--字符串-->
                  <div class="part-text" v-if="(typeof item.content) === 'string'">
                    <p v-html="item.content"></p>
                  </div>
                  <!--对象-->
                  <div class="part-text" v-else-if="(typeof item.content) === 'object'">
                    <p v-for="(data,index) in item.content" :key="index">
                        <span v-for="ele in data">
                          <span v-if="ele.type===0" v-html="symbolToHTML(ele.src)"></span>
                          <span v-if="ele.type===1">
                            <img :src="ele.src" @dblclick="showBigImg(ele.src)"/>
                          </span>
                        </span>
                    </p>
                  </div>
                </template>
                <!--普通文本消息-->
                <template v-else-if="item.msg_type_str === 'RC:TxtMsg'">
                  <div class="part-text" v-html="symbolToHTML(item.content)"></div>
                </template>
              </div>
            </template>

          </div>
        </li>
      </ul>
      <!--</SmScroll>-->
    </div>
    <div class="record-foot-bar">
      <div class="bar-left">
        <!--搜索历史-->
        <el-input
          class="msg-record-input"
          placeholder="搜索消息"
          prefix-icon="el-icon-search"
          :clearable="true"
          v-model="keyWord"
          @blur="handleSearchKeyMsg"
          @keyup.enter.native="handleSearchKeyMsg"
          @clear="handleSearchKeyClear">
        </el-input>
        <!--选择日期-->
        <el-date-picker
          class="msg-time-input"
          v-model="dateTime"
          type="date"
          :readonly='false'
          placeholder="选择日期"
          @change="dateChange"
          :picker-options="pickerOptions">
        </el-date-picker>
      </div>
      <div class="bar-right">
        <HtPagination :total="total" :current-page="currentPage" :page-size='pageSize' @pageChange="pageChange"/>
      </div>
    </div>

  </div>
</template>

<script>
  import {mapGetters, mapActions} from 'vuex'
  import moment from 'moment'
  import {unescapeHTML, transformMsgType, structRelationship, toChineseWords} from '@/utils/utils'
  import {chatListByTime} from '@/api/chat'
  import HtPagination from '@/components/base/Ht-Pagination'
  import HtMessageVoice from '@/components/chat/Ht-MessageVoice' // 语音


  export default {
    name: "HtMsgRecord",
    data() {
      return {
        hisMessage: {},
        chatHistory: [],
        time: 0,
        dateTime: '',
        changeTimeline: 0,
        voiceIndex: 0,
        loading: false,
        testTransData: {},
        pickerOptions: {
          disabledDate(time) {
            return time.getTime() > Date.now() - 8.64e6;
          }
        },
        keyWord: '',
        total: 0,
        pageSize: 20,
        currentPage: 1,
        currentPlayVoiceMsgId: '',
      }
    },
    watch: {
      currentChatId() {
        this.fetchHisMessageData()
      },
      // currentPage(){
      //   this.fetchHisMessageData()
      // },
      changeTimeline() {
        this.fetchHisMessageData()
      },
      hisMessage(val) {
        if (val) {
          this.$nextTick(() => {
            this.handleScrollBottom()
          })
        }
      }
    },
    computed: {
      ...mapGetters([
        'staff',
        'currentChatId',
        'currentConversationType',
        'currentConversationRelationship',
        'isInClient'
      ])
    },
    mounted() {
      this.fetchHisMessageData();
    },
    methods: {
      ...mapActions([
        'getTransPondData',
        'setTransPondShowToggle'
      ]),
      // 打开文档
      openWindowDocs(url) {
        window.openURL(url)
      },
      recordClose() {
        this.$emit('recordClose')
      },
      fetchHisMessageData() {
        this.loading = true;
        console.log(this.currentPage, '页数', this.changeTimeline, '时间', this.keyWord, '搜索')
        chatListByTime(this.currentConversationRelationship, this.currentPage, this.changeTimeline, this.keyWord)
          .then((res) => {
            if (res.status === 200) {
              this.loading = false;
              this.total = parseInt(res.data.count)
              // this.currentPage = res.data.page
              this.pageSize = res.data.pageSize
              this.reRender(res)
            }
          })
          .catch(err => {
            console.log(err)
          })
        this.handleScrollBottom()
      },
      // 抽离渲染数据的处理函数
      reRender(response) {
        let list = response.data.list.reverse()
        for (let i = 0; i < list.length; i++) {
          list[i].msg_type_str = transformMsgType(list[i].msg_type)
          list[i].content = unescapeHTML(list[i].content)
          if (list[i].version == '0') {
            list[i].content = JSON.stringify(list[i].content)
          } else if (list[i].version == '1') {
            list[i].content = JSON.parse(list[i].content)
          }
          console.log(list[i].version, '版本')

          switch (list[i].msg_type_str) {
            case "RC:TxtMsg": // 文本RC:TxtMsg'
              if (list[i].content.content) {
                list[i].content = list[i].content.content
              }
              break;
            case "RC:ImgMsg":// 图片'RC:ImgMsg'
              break;
            case "RC:FileMsg":// 文件消息'RC:FileMsg'
              list[i].content = {
                size: list[i].content.fileSize || list[i].content.size,
                name: list[i].content.filename || list[i].content.name,
                type: list[i].content.fileType || list[i].content.type,
                content: list[i].content.src || list[i].content.content
              };
              list[i].downType = 'noDown';
              break;
            case "RC:VcMsg":// 语音消息'RC:VcMsg'
              break;
            case "RC:ImgTextMsg": // 文档图文消息'RC:ImgTextMsg'
              if ((typeof list[i].content) === 'object') {
                if (list[i].content.imageUri) {
                  list[i].content.imgUrl = list[i].content.imageUri
                }
                if (!list[i].content.extra) {
                  list[i].content.extra = JSON.parse(list[i].content.extra)
                }
              } else {
                if ((typeof list[i].content) === 'string' && list[i].version == '0') {
                  list[i].content = toChineseWords(JSON.parse(list[i].content))
                  try {
                    list[i].content.extra = JSON.parse(list[i].content.extra)
                    list[i].content.content.extra.cont = list[i].content.content.url
                  }catch (e){
                    list[i].msg_type_str = 'RC:TxtMsg'
                    list[i].content = `<div style="text-align: center;color: #00b3ee;">文档已损坏失效，无法查看</div>`
                  }
                }
              }
              break;
            case "RC:InfoNtf": // 系统通知消息'RC:InfoNtf'
              break;
            case "HC:StickerMsg": // 表情自定义消息'HC:StickerMsg'
              break;
            case "HC:TextImage": // 富文本消息'HC:TextImage'
              if (list[i].content.content) {
                list[i].content = list[i].content.content
              }
              break;
          }
        }
        this.hisMessage = this._transformChatList(list)
        console.log(this.hisMessage, '消息体')
      },
      // 转换聊天记录 时间分割
      _transformChatList(list) {
        if (list.length <= 0) return {}
        let chatList = {}
        list.forEach(item => {
          let day = moment.unix(item.timeline).format('Y-MM-DD');
          if (!chatList[day]) {
            chatList[day] = {
              time: day,
              list: []
            }
          }
          chatList[day].list.push(item)
        })
        return chatList
      },
      // 分页控制
      pageChange(page) {
        this.currentPage = page
        this.changeTimeline = 0
        this.fetchHisMessageData()
      },
      // 日期变化
      dateChange(val) {
        if (!val) {
          this.changeTimeline = 0;
          this.currentPage = 1;
          this.fetchHisMessageData()
          return
        }
        this.dateTime = val
        let time = val.getTime() / 1000
        this.changeTimeline = time
      },
      // 搜索历史
      handleSearchKeyMsg() {
        if (!this.keyWord) {
          this.keyWord = ''
          this.currentPage = 1
          this.changeTimeline = 0
          return
        }
        ;
        this.fetchHisMessageData()
      },
      handleSearchKeyClear() {
        this.keyWord = ''
        this.currentPage = 1
        this.changeTimeline = 0
        this.fetchHisMessageData()
      },
      // 文件转发
      handleTransFilePopShow(item) {
        if (!item.content.content) {
          this.$message.error('文件已损坏，无法转发')
          return
        }
        let _relationship = structRelationship(this.staff.uid, item.targetId)
        let data = {
          content: item,
          relationship: item.relationship ? item.relationship : _relationship,
          fromPath: 'msgRecord',
          type: 4
        };
        this.setTransPondShowToggle(true)
        this.getTransPondData(data)
      },
      // 文档转发
      handleTransDocsPopShow(item) {
        let data = {
          content: item,
          type: 8,
          fromPath: 'msgRecord'
        }
        this.setTransPondShowToggle(true)
        this.getTransPondData(data)
      },
      // 打开文件夹
      openDir() {
        let url = this.downloadUrl
        window.hanClient.openFileFloder('floder', url)
      },
      // 打开文件
      openFile() {
        let url = this.downloadUrl
        window.hanClient.openFileFloder('file', url);
      },
      // 下载文件
      downloadFrameFile(item) {
        if (!item.content.content) {
          this.$message.error('文件已损坏，无法下载')
          return
        }
        let _this = this
        _this.$set(item, 'downType', 'downloading')
        if (this.isInClient) {
          window.hanClient.downloadFile({
            strUrl: item.content.content,
            strFileName: item.content.name,
            strDownloadType: "1",
            onSuccess: function (response) {
              _this.$message.success('文件已保存');
              _this.$set(item, 'downType', 'downloaded')
              _this.downloadUrl = response
            },
            onFailure: function (error_code, error_message) {
              if (error_code == 1) {
                _this.$set(item, 'downType', 'noDown')
              } else {
                _this.$message.error(error_message);
              }

            },
          })
        } else {
          window.hanClient.downloadFile({
            strUrl: item.content.content,
            strFileName: item.content.name,
            strDownloadType: "1",
          })
        }
      },
      // 另存为
      downloadOtherFile(item) {
        console.log(item)
        if (!item.content.content) {
          this.$message.error('文件已损坏，无法下载')
          return
        }
        let _this = this
        _this.$set(item, 'downType', 'downloading')
        if (this.isInClient) {
          window.hanClient.downloadFile({
            strUrl: item.content.content,
            strFileName: item.content.name,
            strDownloadType: "2",
            onSuccess: function (response) {
              _this.$message.success('文件已保存');
              _this.$set(item, 'downType', 'downloaded')
              _this.downloadUrl = response
            },
            onFailure: function (error_code, error_message) {
              if (error_code == 1) {
                _this.$set(item, 'downType', 'noDown')
              } else {
                _this.$message.error(error_message);
              }
            }
          })
        } else {
          window.hanClient.downloadFile({
            strUrl: item.content,
            strFileName: item.name,
            strDownloadType: "2"
          })
        }
      },
      // 查看大图
      showBigImg(src) {
        if (!this.isInClient) return
        let data = {
          url: src,
          uuid: '1111',
          data: []
        }
        data = JSON.stringify(data)
        window.hanClient.showImage(data)
      },
      // 滚动条默认固定底部
      handleScrollBottom() {
        let el = this.$refs.recordContScroll
        if (el) {
          this.$nextTick(() => {
            el.scrollTop = el.scrollHeight - el.clientHeight
          })
        } else {
          setTimeout(() => {
            el = this.$refs.recordContScroll
            if (el)
              el.scrollTop = el.scrollHeight - el.clientHeight
          }, 10)
        }
      },
      // 处理融云表情消息
      symbolToHTML(str, mentionedInfo) {
        if (typeof str !== 'string') return
        let html = str;
        try {
          html = RongIMLib.RongIMEmoji.symbolToHTML(str)
        } catch (e) {
          html = str
        }
        let imgReg = /<img.*?(?:>|\/>)/gi;
        if(!html.match(imgReg)){
          let httpreg = /(http:\/\/|https:\/\/)((\w|=|\?|\.|\/|&|-|\:|\;|\+|\%|\#)+)/g;
          html = html.replace(httpreg, '<a href="javascript:;" class="outer-url" data-url=$1$2 onclick="openURL(\'$1$2\')">$1$2</a>');
        }
        return html
      },
      isObjEmpty(obj) {
        return JSON.stringify(obj) == '{}'
      },
      changeCurrentPlayId(val) {
        console.log(val)
        this.currentPlayVoiceMsgId = val
      },
    },
    components: {HtPagination, HtMessageVoice}
  }
</script>

<style scoped>
  .msg-empty {
    text-align: center;
    padding: 40px;
    color: rgb(51, 142, 255);
    font-size: 16px;
  }
</style>
