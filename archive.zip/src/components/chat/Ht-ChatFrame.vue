<template>
  <div class="chat-view-space">
    <!--聊天-->
    <div class="message-container">
      <div class="message-show-box" @drop="dropFileUpload($event,1)" ref="msgShowBox">
        <!--initPos 初始化位置-->
        <!--<SmScroll-->
        <!--ref="ChatScrollWrapper"-->
        <!--:listen-data="message"-->
        <!--init-pos="bottom"-->
        <!--@pullScroll="pullDownScroll"-->
        <!--:over-enable="true">-->
        <div class="message-show-view" ref="messageBox">
          <!--查看更多-->
          <div style="height: 40px;display: flex;align-items: center;justify-content: center"
               v-show="!pullDownLoad&&hasMoreMessage">
            <el-button type="text" @click.native="getMoreMessage">查看更多消息</el-button>
          </div>
          <!--下拉加载-->
          <div class="pull-down" v-show="pullDownLoad"
               style="width: 100%;height: 50px;position: relative; text-align: center">
            <img src="@/assets/img/msg-loading.gif" alt="">
            <p>加载中......</p>
          </div>
          <!--会话列表-->
          <ul ref="messages" @mousewheel.passive="pullDownScroll($event)">
            <!--对话类型-->
            <li class="message-scope clearfix"
                v-for="(item,index) in message"
                ref="MessageScopeItem">
              <!--系统提示消息 如退群入群消息-->
              <template v-if="item.objectName ==='RC:InfoNtf'">
                <p class="scope-time"
                   v-if="index==0?true:(parseInt(item.timeline - (message[(index - 1)].timeline)) > 300)">
                  <span class="time-span">{{ item.timeline | handleChatTimeFormat(message[(index - 1) <= 0 ? 0 : (index - 1)].timeline) }}</span>
                </p>
                <div class="system-msg">
                      <span class="system-msg__info">
                        {{item.content}}
                      </span>
                </div>
              </template>
              <template v-else-if="item.objectName ==='RC:RcCmd'">
                <p class="scope-time"
                   v-if="index==0?true:(parseInt(item.timeline - (message[(index - 1)].timeline)) > 300)">
                  <span class="time-span">{{ item.timeline | handleChatTimeFormat(message[(index - 1) <= 0 ? 0 : (index - 1)].timeline) }}</span>
                </p>
                <div class="system-msg">
                      <span class="system-msg__info">
                        {{item.content}}
                      </span>
                </div>
              </template>
              <!--其余不是系统的消息类型-->
              <template v-else>
                <!--对话时间-->
                <p class="scope-time"
                   v-if="index==0?true:(parseInt(item.timeline - (message[(index - 1)].timeline)) > 300)">
                  <span class="time-span">{{ item.timeline | handleChatTimeFormat(message[(index - 1) <= 0 ? 0 : (index - 1)].timeline) }}</span>
                </p>
                <div class="scope-main" :class="{'self':item.senderUserId == staff.uid}">
                  <!--头像-->
                  <img :src="item.avatar" :alt="item.name" class="scope-avatar" @dblclick.stop="changeConversation(item)">
                  <!--人名称-->
                  <p class="scope-name" v-if="!(item.senderUserId == staff.uid) && currentConversationType === 'G'">
                    {{item.name}}</p>
                  <!--内容主体-->
                  <div class="scope-content">
                    <!--图片-->
                    <template v-if="item.objectName === 'RC:ImgMsg'">
                      <!--图片发送完成-->
                      <div class="picture clearfix" v-if="item.sentStatus >=2 && item.sentStatus <= 4">
                        <!--消息状态 s-->
                        <template v-if="item.senderUserId == staff.uid && currentConversationType==='U'">
                          <span class="status-queue">
                            <HtMsgStatus :msgData="item"/>
                          </span>
                        </template>
                        <!--消息状态 e-->
                        <img @contextmenu.prevent="contextMenu(item.objectName,item,index)" class="msg-img"
                             v-lazy="item.content.content" alt=""
                             @dblclick="showBigImg(item.content.content)">
                      </div>
                      <!--图片发送进度-->
                      <div class="imgPlaceholder" v-if="item.sentStatus < 2">
                        <img class="placeholder-img" src="@/assets/img/img-loading.gif">
                        <p>{{item.complete}}%</p>
                        <!--消息状态 s-->
                        <template v-if="item.senderUserId == staff.uid && currentConversationType==='U'">
                          <span class="status-queue">
                            <!--发送中-->
                            <img v-if="item.sentStatus <= 1" src="@/assets/img/msg-loading.gif" alt="" title="发送中"
                                 class="msg-status-icon">
                          </span>
                        </template>
                        <!--消息状态 e-->
                      </div>
                    </template>
                    <!--表情-->
                    <template v-if="item.objectName === 'HC:StickerMsg'">
                      <div class="picture clearfix">
                        <!--消息状态 s-->
                        <template v-if="item.senderUserId == staff.uid && currentConversationType==='U'">
                          <span class="status-queue">
                            <HtMsgStatus :msgData="item"/>
                          </span>
                        </template>
                        <!--消息状态 e-->
                        <img @contextmenu.prevent="contextMenu(item.objectName,item,index)" class="msg-img"
                             :src="item.content.path" :alt="item.content.name">
                      </div>
                    </template>
                    <!--视频-->
                    <!--<template v-else-if="item.msgType === 'Msg_Video'">-->
                    <!--<div class="message-video-views">-->
                    <!--</div>-->
                    <!--</template>-->
                    <!--文档-->
                    <template v-else-if="item.objectName === 'RC:ImgTextMsg'">
                      <div class="bubble-outer bubble-defalut-bgcolor bubble-arrow"
                           :class="{'bubble-self-bgcolor':(item.senderUserId == staff.uid)}">
                        <div class="bubble-cont">
                          <div class="plain">
                            <div class="message-docs-views">
                              <a class="docs-views-cont" :href="item.content.url || item.content.extra.cont"
                                 target="_blank">
                                <template v-if="item.content.imgUrl || item.content.extra.image">
                                  <img :src="item.content.imgUrl || item.content.extra.image" alt="图片" class="dvc-img">
                                </template>
                                <img v-else src="https://pic2.hanmaker.com/im/default/20180109/5a542f5886d9b.png"
                                     alt="图片" class="dvc-img">
                                <div class="dvc-info">
                                  <p class="info-title" :title="item.content.title | delHtmlTag"
                                     v-html="item.content.title"></p>
                                  <div class="info-intro" v-html="item.content.content"></div>
                                </div>
                              </a>
                              <div class="docs-view-state">
                                <div class="dvc-name clearfix">
                                  <template v-if="item.content.extra.username">
                                    <span class="fl">{{item.content.extra.username}}</span>
                                  </template>
                                </div>
                                <div class="dvc-state">
                                  <el-button class="state-btn" type="text" @click="handleDocsShare(item)">分享</el-button>
                                  <a :href="item.content.extra.cont" target="_blank">
                                    <el-button class="state-btn" type="text">打开</el-button>
                                  </a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <!--消息状态 s-->
                        <template v-if="item.senderUserId == staff.uid && currentConversationType==='U'">
                          <!--发送中-->
                          <img v-if="item.sentStatus == 1" src="@/assets/img/msg-loading.gif" alt="" title="发送中"
                               class="msg-status-icon">
                          <!--未读-->
                          <span v-if="item.sentStatus == 2" class="msg-status-icon noread status-span">已送达</span>
                          <!--已读-->
                          <span v-if="item.sentStatus == 4" class="msg-status-icon readed status-span">已读</span>
                          <!--发送失败-->
                          <!--<i v-if="item.sentStatus == 10" class="iconfont icon-message-fail msg-status-icon failed" title="发送失败，点击重新发送"></i>-->
                        </template>
                        <!--消息状态 e-->
                      </div>
                    </template>
                    <!--语音音频-->
                    <template v-else-if="item.objectName === 'RC:VcMsg'">
                      <div class="bubble-outer bubble-defalut-bgcolor bubble-arrow"
                           :class="{'bubble-self-bgcolor':(item.senderUserId === staff.uid)}">
                        <div class="bubble-cont">
                          <div class="plain">
                            <!--语音-->
                            <HtMessageVoice :voiceData.sync="item" :voiceIndex="item.id" :voiceType="'chatVoice'"
                                            :currentPlayVoiceMsgId="currentPlayVoiceMsgId"
                                            @changeCurrentPlayId="changeCurrentPlayId"/>
                            <!--语音 end-->
                          </div>
                          <!--消息状态 s-->
                          <template v-if="item.senderUserId === staff.uid && currentConversationType==='U'">
                            <HtMsgStatus :msgData="item"/>
                          </template>
                          <!--消息状态 e-->
                        </div>
                      </div>

                    </template>
                    <!--文件-->
                    <template v-else-if="item.objectName === 'RC:FileMsg'">
                      <div class="bubble-outer bubble-defalut-bgcolor bubble-arrow"
                           :class="{'bubble-self-bgcolor':(item.senderUserId == staff.uid)}">
                        <div class="bubble-cont">
                          <div class="plain" @contextmenu.prevent="contextMenu(item.objectName,item,index)">
                            <HtMessageFiles :fileData.sync="item"/>
                          </div>
                        </div>
                        <!--消息状态 s-->
                        <template v-if="item.senderUserId == staff.uid && currentConversationType==='U'">
                          <HtMsgStatus :msgData="item"/>
                        </template>
                        <!--消息状态 e-->
                      </div>
                    </template>
                    <!--富文本-->
                    <template v-else-if="item.objectName === 'HC:TextImage'">
                      <div class="bubble-outer bubble-defalut-bgcolor bubble-arrow"
                           :class="{'bubble-self-bgcolor':(item.senderUserId == staff.uid)}">
                        <div class="bubble-cont"
                             @contextmenu.prevent="contextMenu(item.objectName,item,index,$event)">
                          <div class="plain">
                            <template v-if="item.version == '1'">
                              <div class="text" :style="{fontSize:fontSize+'px'}">
                                <p v-for="(data,index) in item.content.content">
                                  <span v-for="ele in data">
                                     <span v-if="ele.type===0"
                                           v-html="symbolToHTML(ele.src,item.content.mentionedInfo)"></span>
                                      <span v-if="ele.type===1">
                                        <img :src="ele.src" @dblclick="showBigImg(ele.src)"/>
                                      </span>
                                  </span>
                                </p>
                              </div>
                            </template>
                            <template v-else>
                              <div class="text" :style="{fontSize:fontSize+'px'}"
                                   v-html="symbolToHTML((item.content || item.content.content),item.content.mentionedInfo)"></div>
                            </template>
                          </div>
                        </div>
                        <!--消息状态 s-->
                        <template v-if="item.senderUserId == staff.uid && currentConversationType==='U'">
                          <HtMsgStatus :msgData="item"/>
                        </template>
                        <!--消息状态 e-->
                      </div>
                    </template>
                    <!--文本-->
                    <template v-else-if="item.objectName === 'RC:TxtMsg'">
                      <div class="bubble-outer bubble-defalut-bgcolor bubble-arrow"
                           :class="{'bubble-self-bgcolor':(item.senderUserId == staff.uid)}">
                        <div class="bubble-cont"
                             @contextmenu.prevent="contextMenu(item.objectName,item,index)">
                          <div class="plain" :style="{fontSize:fontSize+'px'}">
                            <div class="text" v-html="symbolToHTML(item.content.content || item.content)"></div>
                          </div>
                        </div>
                        <!--消息状态 s-->
                        <template v-if="item.senderUserId == staff.uid && currentConversationType==='U'">
                          <HtMsgStatus :msgData="item"/>
                        </template>
                        <!--消息状态 e-->
                      </div>
                    </template>
                  </div>
                </div>
              </template>
            </li>
          </ul>
        </div>
        <!--</SmScroll>-->
        <!--右边拓展收缩按钮-->
        <div class="message-extend__button tran" :class="{'opened':extendOpened}" @click="handleExtendOpen">
          <i class="extent-arrow-icon"></i>
        </div>
      </div>
      <div class="message-send-box" @drop="dropFileUpload($event,2)" ref="msgSendBox">
        <!--拖拽线-->
        <div class="message-box-drag-line" @mousedown="handleDragPosMove" ref="msgBoxdragLine"></div>
        <!--表情之类的一些按钮，之后会是-->
        <div class="message-tool-bar">
          <!--操作按-->
          <div class="operate-tool-box">
            <div class="operate-tool-btns">
              <!--字体选择-->
              <HtChatSetFont @fontSizeChange="fontSizeChange" :fontSize="fontSize"/>
              <!--表情按钮-->
              <HtChatEmoji @selectedEmoji="selectedEmoji" @sendBiaoQingBaoZi="sendSticker"/>
              <!--截图按钮-->
              <HtScreenCapture v-if="isInClient" @handleCaptureImg="handleCaptureImg"/>
              <!--发送图片-->
              <HtChatUploadImg @uploadImg="handleUploadImg"/>
              <!--发送文件按钮-->
              <HtChatUploadFile @uploadFile="handleUploadFile"/>
              <!--消息记录-->
            </div>
            <span class="history-message-btn fr statistics-show__history" @click="handleMsgRecordShow">消息记录</span>
          </div>
        </div>
        <!--聊天输入框-->
        <div class="message-input-textarea">
          <at-ta :members="members" ref="AtTa" @intAtMsg="insertAtMsg" @hasAtMsg="hasAtMsg"
                 @deleteAtUid="deleteAtUid">
            <han-editor :value="newMessage" @input="bindMessage" ref="newMessageBox">
            </han-editor>
          </at-ta>
        </div>
        <!--发送按钮-->
        <div class="message-send-button" :title="sendModeTitle" :class="{disabled:newMessage=== ''}">
          <button class="button-text" @click.stop="handleSendInputMessage" :disabled="newMessage=== ''"><span>发送</span>
          </button>
          <!--下拉菜单选择-->
          <!--@command="handleSendWaysCommand"-->
          <el-dropdown trigger="click" type="primary" @command="handleSendWaysCommand">
            <!--选择发送方式小箭头-->
            <span class="choose-arrow tran">
                <i class="arrow-btn"></i>
            </span>
            <el-dropdown-menu slot="dropdown" class="send-mode__dropmenu">
              <el-dropdown-item command="1">
                <i class="iconfont icon-duihao" v-show="sendMessageWays == '1'"></i>
                按Enter键发送消息
              </el-dropdown-item>
              <el-dropdown-item command="2">
                <i class="iconfont icon-duihao" v-show="sendMessageWays == '2'"></i>
                按Ctrl+Enter键发送消息
              </el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </div>
      </div>
      <!--网络连接状态提示-->
      <div class="net-work-status" style="display: none">
        <div class="status-info">
          <i class="iconfont icon-message-fail"></i>
          <span>当前网络连接不可用，请检查网络设置</span>
          <!--<span>当前所处网络环境不稳定...</span>-->
          <!--<span>无法连接服务器，请退出重试</span>-->
        </div>
        <i class="iconfont icon-group-member-remove remove-icon"></i>
      </div>
    </div>
    <!--群成员，消息记录，搜索-->
    <div class="extend-container" v-show="extendOpened" ref="extendContainer">
      <!--搜索-->
      <!--成员列表在线状态等-->
      <HtChatMembers @sendMessage="sendMsg" v-if="extShowToggle === 1"
                     @handleSearchDocShow="handleSearchDocShow"/>
      <!--搜索文档等-->
      <HtSearchDocs v-if="extShowToggle === 2"
                    ref="HtSearchDocsComp"
                    :currentChatId="currentChatId"
                    :searchWords="searchDocWords"
                    @handleSearchBack="handleSearchBack"/>
      <!--消息记录等-->
      <HtMsgRecord v-if="extShowToggle === 3 "
                   @recordClose="handleMsgRecordClose"/>
    </div>
  </div>
</template>

<script>
  import {mapGetters, mapActions, mapMutations} from 'vuex'
  import HtMessageVoice from '@/components/chat/Ht-MessageVoice' // 语音
  import HtMessageFiles from '@/components/chat/Ht-MessageFiles' // 群文件
  import HtChatMembers from '@/components/chat/Ht-ChatMembers' // 聊天成员
  import HtSearchDocs from '@/components/chat/Ht-SearchDocs' // 搜索文档界面
  import HtMsgRecord from '@/components/chat/Ht-MsgRecord' // 消息 界面
  import HtScreenCapture from "@/components/chat/Ht-ScreenCapture" // 截图按钮
  import HtChatSetFont from "@/components/chat/Ht-ChatSetFont" // 修改字体按钮
  import HtChatEmoji from "@/components/chat/Ht-ChatEmoji" // 选择表情按钮
  import HtChatUploadImg from "@/components/chat/Ht-ChatUploadImg" // 发送图片按钮
  import HtChatUploadFile from "@/components/chat/Ht-ChatUploadFile"// 发送文件按钮
  import HtChatTranspondPop from '@/components/chat/Ht-ChatTranspondPop' // 转发弹窗
  import HtMsgStatus from '@/components/chat/Ht-MsgStatus' // 消息状态
  import AtTa from '@/components/common/At/At'
  import HanEditor from '@/components/common/Editor/Editor'
  import {getScrollOffsets, uploadItem, genUId, unixDateFormat, getRect} from '@/utils/utils'
  import {getUploadImgToken} from '@/api/upload'
  import {setConversationFontSize, getMessageListNew, updateSendType, statistics} from '@/api/chat'

  export default {
    name: "Ht-ChatFrame",
    data() {
      return {
        // 假对话消息
        sendMode: 1, // 选择发送消息的方式
        pullDownLoad: false, // 上拉刷新加载
        fontSize: 14, // 默认字体大小
        extShowToggle: 1, // 拓展默认打开项 1 为成员  2为搜索文档  3为消息记录
        extendOpened: true, // 拓展栏的开启与关闭
        searchDocWords: '',
        newMessage: '',
        hasInsertAt: 0,
        mentionType: 0,
        mentionUidList: [],
        isScroll: true,
        currentPlayVoiceMsgId: '',
        FetchingHistoryMessage: false,
        completeCount: 0,
        imageCount:0,
        tempArr: [],
        imageUrl: '',
      }
    },
    watch: {
      isSendMessage(val) {
        if (val) {
          this.handleSendInputMessage()
        }
      },
      message(data) {
        let olength = data.length
        if (olength === 0) {
          return
        }
        setTimeout(() => {
          if (this.isScroll) {
            this.handleScrollBottom()
          }
        }, 50)
      },
      currentChatId(val) {
        this.handleConversationStorage(val)
        this.isScroll = true;
        this.$nextTick(() => {
          if (this.message.length === 0) {
            this.getMoreMessage()
          }
          if(val<1000000){
            console.log('切换私聊')
            setTimeout(()=>{
              let odata = {
                targetId:val,
                uid:this.staff.uid
              }
              this.syncMessageStatus(odata)
            },2000)
          }
        })
        this.$refs.newMessageBox.editor.focus();
        this.handleMsgRecordClose()
      }
    },
    computed: {
      ...mapGetters([
        'sendMessageWays',
        'currentChatId',
        'messages',
        'staff',
        'currentConversationType',
        "currentChatGroupInfo",
        'isSendMessage',
        'hasMoreMessage',
        'currentConversationRelationship',
        'isInClient'
      ]),
      members() {
        if (this.currentChatGroupInfo.members.length > 1) {
          let data = [{
            full_name: "所有人",
            uid: ""
          }]
          let odata = data.concat(this.currentChatGroupInfo.members)
          let tempData = [];
          odata.forEach((val) => {
            if (val.uid != this.staff.uid) {
              tempData.push(val);
            }
          });
          return tempData;
        } else {
          return []
        }
      },
      message() {
        let messagesObj = this._.find(this.messages, (o) => {
          return o.targetId == this.currentChatId
        });
        if (this._.isObject(messagesObj)) {
          return messagesObj.messageList;
        }
        else
          return []
        // return this._.orderBy(data, ['timeline'], ['asc'])
      },
      sendModeTitle() {
        if (this.sendMessageWays == '1') {
          return '按Enter键发送消息，按Ctrl+Enter键换行'
        } else if (this.sendMessageWays == '2') {
          return '按Ctrl+Enter键发送消息，按Enter键换行'
        }
      },
    },
    methods: {
      ...mapActions([
        'setSendMessageWays',
        'changeSendStatus',
        'sendChatMessage',
        'getTransPondData',
        'setTransPondShowToggle',
        'getMoreMessages',
        'revokeMessage',
        'uploadFile',
        'createNewConversation'
      ]),
      ...mapMutations({
        syncMessageStatus: 'SYNC_CONVERSATION_CHAT_SENTSTATUS'
      }),
      fontSizeChange(val) {
        setConversationFontSize(val)
          .then(response => {
            if (response.status == 200) {
              this.fontSize = val
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      handleDragPosMove(e) {
        // 获取
        let msgSendBox = this.$refs.msgSendBox,
          msgShowBox = this.$refs.msgShowBox,
          scroll = getScrollOffsets(),
          startY = e.clientY + scroll.y,
          _startY = parseInt(startY);
        document.addEventListener("mousemove", moveHandler, true);
        document.addEventListener("mouseup", upHandler, true);
        if (event.stopPropagation) event.stopPropagation(); //标准模型
        else event.cancelBubble = true;
        //现在阻止任何默认操作
        if (event.preventDefault) event.preventDefault();
        else event.returnValue = false;

        function moveHandler(e) {
          if (!e) e = window.event; //ie事件模型
          let startY = parseInt(e.clientY);
          let deltaY = startY - _startY;
          if (_startY > startY) {
            if (msgSendBox.style.height >= '480px') {
              return false
            } else {
              let nowHeight = msgSendBox.offsetHeight - deltaY;
              msgSendBox.style.height = nowHeight + "px";
              msgShowBox.setAttribute('style', 'height:calc(100% - ' + nowHeight + "px" + ')')
            }

          } else {
            if (msgSendBox.style.height <= '156px') {
              return false
            } else {
              let nowHeight = msgSendBox.offsetHeight - deltaY;
              msgSendBox.style.height = nowHeight + "px";
              msgShowBox.setAttribute('style', 'height:calc(100% - ' + nowHeight + "px" + ')')
            }
          }
          _startY = startY;
          if (msgSendBox.style.height > '480px') {
            msgSendBox.style.height = '480px';
            msgShowBox.setAttribute('style', 'height:calc(100% - 480px)')
          } else if (msgSendBox.style.height < '156px') {
            msgSendBox.style.height = '156px';
            msgShowBox.setAttribute('style', 'height:calc(100% - 156px)')
          }
          if (e.stopPropagation) e.stopPropagation(); //标准模型
          else e.cancelBubble = true;
        }

        function upHandler(e) {
          if (!e) e = window.event; //ie事件模型
          //注销捕获事件处理程序
          document.removeEventListener("mousemove", moveHandler, true);
          document.removeEventListener("mouseup", upHandler, true);
          if (e.stopPropagation) e.stopPropagation(); //标准模型m
          else e.cancelBubble = true;
        }
      },
      listenScroll(pos) {
        // console.log(pos,'scroll')
      },
      pullDownScroll(e) {
        let up = e.wheelDelta ? e.wheelDelta > 0 : e.detail < 0;
        if (this.FetchingHistoryMessage) {
          return
        }
        if (up) {
          let top = this.$refs.messageBox.scrollTop;
          this.isScroll = false
          if (top <= 30) {
            this.pullDownLoad = true;
            let id = this.message[0].id;
            this.FetchingHistoryMessage = true;
            getMessageListNew(id, this.currentConversationRelationship)
              .then(response => {
                if (response.status == 200) {
                  if (response.data.list.length <= 0) {
                    this.$refs.messageBox.scrollTop = 0
                    this.pullDownLoad = false;
                    this.FetchingHistoryMessage = false
                    return
                  }
                  let payload = {};
                  payload.id = this.currentChatId;
                  payload.list = response.data.list.reverse();
                  this.getMoreMessages(payload)
                  let msgLength = this.$refs.MessageScopeItem.length
                  let tempLi = 0
                  if (msgLength < 10) {
                    tempLi = this.$refs.MessageScopeItem[msgLength - 1]
                  } else {
                    tempLi = this.$refs.MessageScopeItem[10]
                  }

                  if (tempLi.offsetTop) {
                    this.$refs.messageBox.scrollTop = tempLi.offsetTop
                  }
                  this.pullDownLoad = false;
                  this.FetchingHistoryMessage = false
                } else {
                  this.pullDownLoad = false;
                  this.FetchingHistoryMessage = false
                }
              })
              .catch(error => {
                this.pullDownLoad = false;
                this.FetchingHistoryMessage = false
                console.log(error)
              })
          }
        } else {
          let el = this.$refs.messageBox;
          let top = this.$refs.messageBox.scrollTop;
          let dis = el.scrollHeight - el.clientHeight;
          if (top === dis) {
            this.isScroll = true;
          }
        }
      },
      handleMentionInfo(mentionedInfo) {
        if (mentionedInfo) {
          if (mentionedInfo.type == 1) {
            const keywords = '@所有人'
            let reg = new RegExp(keywords)
            str = str.replace(reg, '<em>' + keywords + '</em>')
          } else {
            let isMentioned = mentionedInfo.userIdList.includes(this.staff.uid)
            if (isMentioned) {
              let keywords = '@' + this.staff.full_name
              let reg = new RegExp(keywords)
              str = str.replace(reg, '<em>' + keywords + '</em>')
            }
          }
        }
      },
      handleRichTextToJson() {
        let self = this;
        self.completeCount = 0;
        self.imageCount = 0;
        let parent = this.$refs.newMessageBox.$el.querySelector('.ql-editor');
        let chidren = parent.querySelectorAll('p');
        let contentArr = [];
        for (let i = 0; i < chidren.length; i++) {
          let text = chidren[i].innerHTML;
          let tempImgArr = [];
          if ((/.*?<span.*?/).test(text)) {
            continue;
          }
          let imgNodeList = chidren[i].querySelectorAll('img');
          this.imageCount += chidren[i].querySelectorAll('img').length;
          for (let i = 0; i < imgNodeList.length; i++) {
            if (imgNodeList[i].complete) {
              self.completeCount++;
            }
            let src = imgNodeList[i].src;
            tempImgArr.push(src)
          }
          let lineArr = [];
          let imgIndex = 0;
          console.log('text',text,imgNodeList)
          text = text.replace(/<(br|BR)(.*?)>/g, '');
          text = text.replace(/<(img|IMG)(.*?)>/g, function (rs, offset) {
            imgIndex++;
            return '$#@' + tempImgArr[imgIndex - 1] + '$#@'
          });
          lineArr = text.split('$#@');
          console.log('lineArr',lineArr)
          let jsonArr = [];
          let imgreg = /https:\/\/pic2.hanmaker.com/;
          let imgreg2 = /https:\/\/upload.hanmaker.com/;
          for (let i = 0; i < lineArr.length; i++) {
            if (lineArr[i] !== '') {
              let isImg = imgreg.test(lineArr[i]) || imgreg2.test(lineArr[i])
              if (isImg) {
                jsonArr.push({
                  "type": 1,
                  "src": lineArr[i]
                })
              } else {
                jsonArr.push({
                  "type": 0,
                  "src": lineArr[i]
                })
              }
            }
          }
          // if (self.completeCount != imgNodeList.length) {
          //   contentArr.push(jsonArr)
          //   continue;
          // }
          contentArr.push(jsonArr)
        }
        return contentArr
      },
      handleSendInputMessage() {
        statistics('send_msg');
        // 发送消息滚动条默认滚到底部
        // const text = this.newMessage;
        let text = this.handleRichTextToJson();
        // if(Array.isArray(text) && (/^</).test(text[0][0].src)){
        //     return;
        // }
        this.changeSendStatus(false)
        //每一行都为空则不发送
        let msgCount = 0;
        let maxText = '';
        for (let i = 0; i < text.length; i++) {
          text[i].forEach((val) => {
            maxText += val.src;
          })
          if (text[i].length === 0) {
            msgCount++
          }
        }
        if (msgCount === text.length) {
          return
        }
        if (this.hasInsertAt == 1) {
          this.hasInsertAt = 0;
          return;
        }
        console.log(this.completeCount + 'this is box' + this.imageCount);
        if(this.completeCount != this.imageCount){
          return;
        }
        // if (maxText.length > 100) {
        //   this.$message({
        //     type: 'warning',
        //     message: '发送消息内容超长，请分条发送。',
        //     center: true
        //   })
        //   return;
        // }
        let mentionInfo = {};
        mentionInfo.mentionType = this.mentionType;
        mentionInfo.userIdList = this.mentionUidList;
        let data = {
          uid: this.currentChatId,
          content: {
            content: text,
            mentionedInfo: mentionInfo
          },
          type: 10
        };
        this.sendChatMessage(data);
        this.mentionUidList = [];
        this.isScroll = true;
        this.newMessage = '';
        this.$refs.newMessageBox.editor.focus()
        this.completeCount = 0;
      },
      handleUploadFile() {
        this.isScroll = true;
      },
      handleUploadImg() {
        this.isScroll = true;
      },
      symbolToHTML(str, mentionedInfo) {
        if (typeof str !== 'string') return
        let html = str;
        try {
          html = RongIMLib.RongIMEmoji.symbolToHTML(str)
        } catch (e) {
          html = str
        }
        if (mentionedInfo) {
          if (mentionedInfo.mentionType == 1) {
            const keywords = '@所有人'
            const keywords2 = '@' + this.staff.full_name
            let reg = new RegExp(keywords)
            let reg2 = new RegExp(keywords2)
            html = html.replace(reg, '<em>' + keywords + '</em>')
            html = html.replace(reg2, '<em>' + keywords2 + '</em>')
          } else {
           try {
             let isMentioned = mentionedInfo.userIdList.includes(this.staff.uid)
             if (isMentioned) {
               let keywords = '@' + this.staff.full_name
               let reg = new RegExp(keywords)
               html = html.replace(reg, '<em>' + keywords + '</em>')
             }
           }catch (e){}
          }
        }
        let imgReg = /<img.*?(?:>|\/>)/gi;
        let spanReg = /<span.*>(.*)<\/span>/gi;
        if(!html.match(imgReg) && !html.match(spanReg) ){
          let httpreg = /(http:\/\/|https:\/\/)((\w|=|\?|\.|\/|&|-|\:|\;|\+|\%|\#)+)/g;
          html = html.replace(httpreg, '<a href="javascript:;" class="outer-url" data-url=$1$2 onclick="openURL(\'$1$2\')">$1$2</a>');
        }
        return html
      },
      handleConversationStorage(uid) {
        let tempMsg = sessionStorage.getItem(uid)
        if (tempMsg != '' && tempMsg != null) {
          this.newMessage = tempMsg;
          setTimeout(() => {
            const self = this.$refs.newMessageBox.editor;
            let length = (self.getSelection() || {}).index || self.getLength();
            self.setSelection(length)
          }, 10)
        } else {
          this.newMessage = '';
        }
      },
      changeConversation(item){
        if(item.senderUserId==this.staff.uid){
          return
        }
        let data = {
          avatar:item.avatar,
          full_name:item.name,
          id:item.senderUserId
        }
        this.createNewConversation(data);
      },
      insertAtMsg(val) {
        this.hasInsertAt = val
      },
      hasAtMsg(data) {
        //是否是全局消息
        this.mentionType = 0;
        if (data.uid === '') {
          this.mentionType = 1
        } else {
          let isExist = this.mentionUidList.some(v => {
            return v == data.uid
          })
          if (!isExist) {
            this.mentionUidList.push(data.uid)
          }
        }
        this.isAllMention()
      },
      isAllMention() {
        if (this.mentionType == 1) {
          return
        }
        if (this.mentionUidList.length >= this.members.length - 1) {
          this.mentionType = 1;
        } else if (this.mentionUidList.length > 0) {
          this.mentionType = 2;
        } else {
          this.mentionType = 0;
        }
      },
      deleteAtUid(data) {
        if (data.uid == '') {
          let length = this.mentionUidList.length
          length === 0 ? this.mentionType = '' : this.mentionType = 2;
          return
        }
        let Index = this.mentionUidList.findIndex(v => {
          return v == data.uid
        });
        this.mentionUidList.splice(Index, 1)
        this.isAllMention()
        this.hasInsertAt = 0
      },
      sendSticker(data) {
        let content = {
          name: data.name,
          path: data.url,
          key: '',
          category: data.group_name,
        }
        odata = JSON.stringify(odata);
        let odata = {
          uid: this.currentChatId,
          content: content,
          type: 3
        }
        this.sendChatMessage(odata)
        this.isScroll = true;
      },
      handleExtendOpen() {
        this.extendOpened = !this.extendOpened
      },
      handleMsgRecordShow() {
        if (!this.extendOpened) {
          this.extendOpened = true
          statistics('show_history')
        }
        if (this.extShowToggle !== 3) {
          this.$refs.extendContainer.style.width = '334px' // 历史记录宽度为300px;
          this.extShowToggle = 3
          this.extendOpened = true
        } else {
          this.$refs.extendContainer.style.width = ''
          this.extShowToggle = 1
        }
      },
      handleMsgRecordClose() {
        this.$refs.extendContainer.style.width = ''
        this.extShowToggle = 1
      },
      handleSearchDocShow(sWords) {
        this.searchDocWords = sWords
        if (!this.extendOpened) {
          this.extendOpened = true
        }
        if (this.extShowToggle !== 2) {
          this.$refs.extendContainer.style.width = '300px' // 历史记录宽度为300px;
          this.extendOpened = true
          this.extShowToggle = 2
        }
      },
      handleSearchBack() {
        this.$refs.extendContainer.style.width = ''
        this.extShowToggle = 1
      },
      bindMessage(val) {
        this.newMessage = val;
        sessionStorage.setItem(this.currentChatId, this.newMessage)
      },
      handleSendWaysCommand(commond) {
        this.setSendMessageWays(commond)
        this.changeSendStatus(false)
        window.localStorage.setItem('send_ways', commond)
      },
      handleDocsShare(item) {
        let data = {
          content: item.content,
          type: 8,
          fromPath: 'chatFrame'
        }
        this.setTransPondShowToggle(true)
        this.getTransPondData(data)
      },
      insertImg(url, chatId) {
        if (chatId != this.currentChatId) {
          return
        }
        const self = this.$refs.newMessageBox.editor;
        self.focus();
        let length = (self.getSelection() || {}).sindex || self.getLength();
        self.insertEmbed(length - 1, 'image', url);
        self.setSelection(length + 1)
      },
      insertText(data) {
        const self = this.$refs.newMessageBox.editor;
        self.focus();
        let length = (self.getSelection() || {}).sindex || self.getLength();
        self.insertText(length - 1, data);
        // self.setSelection(length + 1)
      },
      selectedEmoji(emoji) {
        this.insertText(emoji)
      },
      showBigImg(src) {
        let data = {
          url: src,
          uuid: '1111',
          data: []
        }
        if (this.isInClient) {
          data = JSON.stringify(data)
          window.hanClient.showImage(data)
        } else {
          window.openURL(data.url)
        }

      },
      handleCaptureImg(imageData, chatId) {
        chatId = chatId || this.currentChatId;
        let _this = this;

        function dataURLtoFile(dataurl, filename) {
          var arr = dataurl.split(','), mime = arr[0].match(/:(.*?);/)[1],
            bstr = atob(arr[1]), n = bstr.length, u8arr = new Uint8Array(n);
          while (n--) {
            u8arr[n] = bstr.charCodeAt(n);
          }
          return new File([u8arr], filename, {type: mime});
        }

        /*
        const clipboard = this.$electron.clipboard
        const clipboard = this.$electron.clipboard
        let file = dataURLtoFile(clipboard.readImage().toDataURL(), 'a.png');
        */
        // _this.previewImgDes.height = data.height;
        // _this.previewImgDes.width = data.width;
        let file = dataURLtoFile(imageData.data, 'a.png');
        // _this.previewImgSrc = data.data
        if (file.size > (12 * 1024 * 1024)) {
          _this.$message.info('您的图片超出12M文件大小限制，请使用文件发送')
          return
        }
        let config = {
          name: 'file',  // 图片参数名
          size: 12,  // 可选参数 图片大小，单位为M，1M = 1024kb
          action: 'http://upload.qiniu.com',  // 服务器地址,
          token: ''
        };
        let uuid = genUId()
        getUploadImgToken()
          .then(response => {
            if (response.status == 200) {
              config.token = response.data.upToken;
              uploadItem(file, config, uuid, {
                start() {
                },
                success(res) {
                  _this.insertImg(res.src + '?' + 'imageHeight=' + res.imageHeight + '#' + 'imageWidth=' + res.imageWidth, chatId)
                },
                error() {
                },
                progress(complete, e) {
                },
                end(e) {
                },
                change() {
                }
              })
            }
          })
          .catch(error => {
            console.log(error)
          })
      },
      changeCurrentPlayId(val) {
        this.currentPlayVoiceMsgId = val
      },
      handleScrollBottom() {
        let el = this.$refs.messageBox;
        if (el) {
          // let distance  = el.scrollTop;
          this.$nextTick(() => {
            el.scrollTop = el.scrollHeight - el.clientHeight
          })
        } else {
          setTimeout(() => {
            el = this.$refs.messageBox;
            if (el)
              el.scrollTop = el.scrollHeight - el.clientHeight
          }, 10)
        }
      },
      getMoreMessage() {
        if (this.FetchingHistoryMessage) {
          return
        }
        this.FetchingHistoryMessage = true;
        let id = 0;
        let relationship = this.currentConversationRelationship;
        console.log(1111,this.message.length)
        if (this.message.length !== 0) {
          console.log(this.message[0]);
          id = this.message[0].id || this.message[0].messageId;
        }
        getMessageListNew(id, relationship, 1)
          .then(response => {
            if (response.status == 200) {
              let payload = {};
              payload.id = this.currentChatId;
              payload.list = response.data.list.reverse();
              this.getMoreMessages(payload)
              let msgLength = this.$refs.MessageScopeItem.length;
              let tempLi = 0;
              if (msgLength < 10) {
                tempLi = this.$refs.MessageScopeItem[msgLength - 1]
              } else {
                tempLi = this.$refs.MessageScopeItem[10]
              }
              if (tempLi.offsetTop) {
                this.$nextTick(function () {
                  this.$refs.messageBox.scrollTop = tempLi.offsetTop
                })
              }
              this.FetchingHistoryMessage = false
            } else {
              this.FetchingHistoryMessage = false
            }
          })
          .catch(error => {
            this.FetchingHistoryMessage = false
            console.log(error)
          })
      },
      copyText(text) {
        let textArray = '';
        if (Array.isArray(text)) {
          text.forEach((val) => {
            if (Array.isArray(val) && val.length > 0) {
              val.forEach((value) => {
                textArray += value.src + "\r\n";
              })
            } else {
              textArray += "\r\n";
            }
          });
        } else {
          textArray = text;
        }
        this.$copyText(textArray).then(function (e) {
        }, function (e) {
        })
      },
      copyImg(img) {
        this.$copyText(img).then(function (e) {
        }, function (e) {

        })
      },
      contextMenu(msgType, val, index, $event) {
        var self = this;
        let data = null;
         // this.selectText($event.currentTarget)
        if (self.staff.uid == val.senderUserId) {
          switch (msgType) {
            case 'RC:ImgMsg':
              //图片
              self.imageUrl = val.content.content;
              window.hanClient.runChatMenu({
                menu: 'image_copy,image_saveas,msg_recall',
                data: self.imageUrl,
                onSuccess(response) {
                  data = JSON.parse(response)
                  if (data.type == 'msg_recall') {
                    self.revokeMsg(val, index)
                  }
                }
              })

              break;
            // 表情
            case 'HC:StickerMsg':
              self.imageUrl = val.content.path;
              window.hanClient.runChatMenu({
                menu: 'msg_recall',
                data: self.imageUrl,
                onSuccess(response) {
                  data = JSON.parse(response)
                  if (data.type == 'msg_recall') {
                    self.revokeMsg(val, index)
                  }
                }
              })
              break;
            //文档
            case 'RC:ImgTextMsg':
              window.hanClient.runChatMenu({
                menu: 'msg_recall',
                onSuccess(response) {
                  data = JSON.parse(response)
                  if (data.type == 'msg_recall') {
                    self.revokeMsg(val, index)
                  }
                }
              })
              break;
            //语音
            case 'RC:VcMsg':
              window.hanClient.runChatMenu({
                menu: 'msg_recall',
                onSuccess(response) {
                  data = JSON.parse(response)
                  if (data.type == 'msg_recall') {
                    self.revokeMsg(val, index)
                  }
                }
              })
              break;
            //文件
            case 'RC:FileMsg':
              window.hanClient.runChatMenu({
                menu: 'msg_recall',
                onSuccess(response) {
                  data = JSON.parse(response)
                  if (data.type == 'msg_recall') {
                    self.revokeMsg(val, index)
                  }
                }
              })
              break;

            //富文本
            case 'HC:TextImage':
              window.hanClient.runChatMenu({
                menu: 'text_copy,msg_recall',
                onSuccess(response) {
                  data = JSON.parse(response)
                  if (data.type == 'text_copy') {
                    var selection = window.getSelection();
                    let textContent = selection.toString();
                    if (textContent == '') {
                      self.copyText(val.content.content)
                    } else {
                      self.$copyText(textContent).then(function (e) {
                      }, function (e) {

                      })
                    }

                  } else if (data.type == 'msg_recall') {
                    self.revokeMsg(val, index)
                  }
                }
              })
              break;
            //文本
            case 'RC:TxtMsg':
              window.hanClient.runChatMenu({
                menu: 'text_copy,msg_recall',
                onSuccess(response) {
                  data = JSON.parse(response)
                  if (data.type == 'text_copy') {
                    var selection = window.getSelection();
                    let textContent = selection.toString();
                    if (textContent == '') {
                      self.copyText(val.content.content)
                    } else {
                      self.$copyText(textContent).then(function (e) {
                      }, function (e) {

                      })
                    }
                  } else if (data.type == 'msg_recall') {
                    self.revokeMsg(val, index)
                  }
                }
              })
              break;

          }
        } else {
          switch (msgType) {
            case 'RC:ImgMsg':
              //图片
              self.imageUrl = val.content.content;
              window.hanClient.runChatMenu({
                menu: 'image_copy,image_saveas',
                data: self.imageUrl,
                onSuccess(response) {
                  // data = JSON.parse(response)
                  // if(data.type == 'msg_recall'){
                  //   self.revokeMsg(val, index)
                  // }
                }
              })

              break;
            // 表情
            case 'HC:StickerMsg':
              // self.imageUrl = val.content.path;
              // window.hanClient.runChatMenu({
              //   menu: 'text_copy',
              //   data:self.imageUrl,
              //   onSuccess(response) {
              //     data = JSON.parse(response)
              //     if(data.type == 'text_copy'){
              //
              //     }
              //   }
              // })
              break;
            //文档
            case 'RC:ImgTextMsg':
              // window.hanClient.runChatMenu({
              //   menu: 'msg_recall',
              //   onSuccess(response) {
              //     data = JSON.parse(response)
              //     if(data.type == 'msg_recall'){
              //
              //     }
              //   }
              // })
              break;
            //文件
            case 'RC:FileMsg':
              // window.hanClient.runChatMenu({
              //   menu: 'msg_recall',
              //   onSuccess(response) {
              //     data = JSON.parse(response)
              //     if(data.type == 'msg_recall'){
              //       self.revokeMsg(val, index)
              //     }
              //   }
              // })
              break;

            //富文本
            case 'HC:TextImage':
              // setTimeout(() => {
              //   this.selectText($event.currentTarget);
              // },0)
              window.hanClient.runChatMenu({
                menu: 'text_copy',
                onSuccess(response) {
                  data = JSON.parse(response)
                  if (data.type == 'text_copy') {
                    var selection = window.getSelection();
                    let textContent = selection.toString();
                    if (textContent == '') {
                      self.copyText(val.content.content)
                    } else {
                      self.$copyText(textContent).then(function (e) {
                      }, function (e) {

                      })
                    }
                  }
                }
              })
              break;
            //文本
            case 'RC:TxtMsg':
              window.hanClient.runChatMenu({
                menu: 'text_copy',
                onSuccess(response) {
                  data = JSON.parse(response)
                  if (data.type == 'text_copy') {
                    var selection = window.getSelection();
                    let textContent = selection.toString();
                    if (textContent == '') {
                      self.copyText(val.content.content)
                    } else {
                      self.$copyText(textContent).then(function (e) {
                      }, function (e) {

                      })
                    }
                  }
                }
              })
              break;

          }
        }
      },
      sendMsg(item) {
        let number = this.currentChatGroupInfo.members.length;
        this.tempArr.push(item.uid)
        this.mentionUidList = [...new Set(this.tempArr)];
        if ((number - 1) == this.mentionUidList.length) {
          this.mentionType = 1
        } else {
          this.mentionType = 2;
        }
        this.insertText('@' + item.full_name)
      },
      revokeMsg(msgItem, index) {
        if (((new Date().getTime()) - (new Date(unixDateFormat(msgItem.timeline)).getTime())) > 120000) {
          this.$message.error('消息已超过两分钟，不能撤回！');
          return;
        }
        updateSendType(msgItem).then((resp) => {
          if (resp.status == 200) {
            // this.revokeMessage({'currentChatId': this.currentChatId, 'index': index})
          } else {
            this.$message.error(resp.info);
          }
        }).catch((error) => {
          this.$message.error('撤回消息失败!');
        })
      },
      selectText(text) {
        if (document.body.createTextRange) {
          var range = document.body.createTextRange();
          range.moveToElementText(text);
          range.select();
        } else if (window.getSelection) {
          var selection = window.getSelection();
          var range = document.createRange();
          range.selectNodeContents(text);
          selection.removeAllRanges();
          selection.addRange(range);
        }
      },
      dropFileUpload($event, type) {
        $event.preventDefault();
        statistics('send_file');
        let _file = $event.dataTransfer.files; //获取要上传的文件对象
        console.log(_file)
        if (_file.length < 1) {
          return;
        }
        if (type == 2) {
          if ((!(/(\.)(png|jpe?g|gif|bmp|webp|svg)(\?.*)?$/.test(_file[0].name)))) {
            let data = {
              file: _file[0],
              type: 4,
              id: this.currentChatId
            }
            this.uploadFile(data)
          }
        } else {
          if ((/(\.)(png|jpe?g|gif|bmp|webp|svg)(\?.*)?$/.test(_file[0].name))) {
            let config = {
              name: 'file',  // 图片参数名
              size: 12,  // 可选参数 图片大小，单位为M，1M = 1024kb
              action: 'http://upload.qiniu.com',  // 服务器地址,
              token: ''
            };
            let _this = this;
            let uuid = genUId()
            getUploadImgToken()
              .then(response => {
                if (response.status == 200) {
                  config.token = response.data.upToken;
                  uploadItem(_file[0], config, uuid, {
                    start() {
                    },
                    success(res) {
                      _this.insertImg(res.src + '?' + 'imageHeight=' + res.imageHeight + '#' + 'imageWidth=' + res.imageWidth, _this.currentChatId)
                    },
                    error() {
                    },
                    progress(complete, e) {
                    },
                    end(e) {
                    },
                    change() {
                    }
                  })
                }
              })
              .catch(error => {
                console.log(error)
              })
          }else{
            let data = {
              file: _file[0],
              type: 4,
              id: this.currentChatId
            }
            this.uploadFile(data)
          }
        }

        this.isScroll = true;
      }
    },
    mounted() {
    },
    components: {
      HtMessageFiles,
      HtChatMembers,
      HtSearchDocs,
      HtMsgRecord,
      HtScreenCapture,
      HtChatSetFont,
      HtChatEmoji,
      HtChatUploadImg,
      HtChatUploadFile,
      AtTa,
      HanEditor,
      HtChatTranspondPop,
      HtMessageVoice,
      HtMsgStatus
    }
  }
</script>

<style scoped>

</style>
