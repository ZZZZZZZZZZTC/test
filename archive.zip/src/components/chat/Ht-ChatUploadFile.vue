<template>
  <div class="btns-span tran statistics-send__file"  ref="uploadFileBtn">
    <i class="iconfont icon-files"></i>
    <div class="loading-mask" v-show="loading">
      <span class="el-icon-loading" ></span>
    </div>
    <input type="file" ref="uploadFileInput" style="display: none" />
  </div>
</template>

<script>
  import {mapGetters, mapActions, mapMutations} from 'vuex'
  import {getUploadFileToken} from '@/api/upload'
  import {statistics} from '@/api/chat'
    export default {
      name: "Ht-ChatUploadFile",
      data(){
        return{
          domain: '',
          expires: 0,
          saveKeyPrefix: '',
          upToken: '',
          loading:false,
        }
      },
      mounted(){
          this.eventUpload()
      },
      computed: {
        ...mapGetters([
          'currentChatId',
        ]),
      },
      methods:{
        ...mapActions([
          'uploadFile'
        ]),
        eventUpload() {
          let _this = this;
          let file = this.$refs.uploadFileInput;
          file.onchange = function (e) {
            let _file = this.files[0];
            if(!_file){
              return
            }
            let data ={
              file:_file,
              type:4,
              id:_this.currentChatId
            }
            _this.uploadFile(data)
            _this.$emit('uploadFile')
            file.value = ''
          }
          // 点击图标上传
          let btn = this.$refs.uploadFileBtn
          btn.onclick = function () {
            statistics('send_file');
            file.click()
          }
        },
      }
    }
</script>

<style scoped>

</style>
