<template>
  <div class="ht-chat ht-main-section" v-if="currentChatName">
    <!--标题工具栏-->
    <div class="main-section-menu">
      <!--聊天标题栏-->
      <div class="chat-menu-bar">
        <template v-if="this.currentConversationType === 'G'">
          <div class="chat-menu-name group-name" @click="handleShowGroupDetail">
            {{currentChatName}}
          </div>
        </template>
        <template v-else>
          <div class="chat-menu-name">
            {{currentChatName}}
            <span v-if="this.currentConversationType !== 'T' && currentChatUserOnlineType.info !==''"
                  class="online-status"
                  :class="[(currentChatUserOnlineType.type !== 0) ? 'online' : 'offline']">
                                     ({{currentChatUserOnlineType.info}})
            </span>
          </div>
        </template>

        <div class="chat-menu-tool">
          <ul class="tool-list clearfix">
            <li class="list-item fl tran"
                v-for="(item,index) in toolbarlist"
                :class="{'active':toolTabShow===item.type,'statistics-show__image':item.type === 'image','statistics-show__file':item.type === 'file'}"
                :key="index"
                data-type="chat"
                @click="clickToolTabTargetShow(item)">{{item.name}}
            </li>
            <li class="fl tran set-item" @click.stop="handelSettingPanelShow" v-if="currentConversationType=='G'">
             <span class="setting-icon tran">
                <i class="iconfont icon-groupchat-setting"></i>
             </span>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <!---->
    <div class="main-section-body">
      <!--聊天-->
      <HtChatFrame/>
      <!--文件-->
      <HtFilesFrame v-if="toolTabShow === 'file'"/>
      <!--图片-->
      <HtImagesFrame v-if="toolTabShow === 'image'"/>
      <!--公告-->
      <!--<HtNoticeFrame v-if="toolTabShow === 'notice'"/>-->
      <!--设置-->
      <transition name="el-zoom-in-top">
        <HtSettingFrame v-if="settingPanel && currentConversationType == 'G'"
                        @handleMoreSetting="handleMoreSetting"
                        @handleShowInfo="handleShowInfo"
                        @addMemberHandelOpen="addMemberHandelOpen"
                        @closePanel="closeSetting"
                        v-click-outside="closeSetting"/>
      </transition>
      <!--群信息组件-->
      <HtGroupDetail
        ref="HtGroupDetailBox"
        v-if="groupDetailShow && currentConversationType == 'G'"/>
    </div>
    <!--聊天信息框-->
    <!--聊天信息输入发送框-->
    <!--添加群成员-->
    <HtAddMemberPop v-if="member_pop" :uids="[]"
                    @handleClose="addMemberHandelClose"
                    @handleSubmit="addMemberHandleSubmit"/>


    <!--转发弹窗-->
    <!--转发弹窗-->
    <HtChatTranspondPop :show="transpondShow"
                        :defaultSelectedUids="[]"
                        @handleClose="handleTranspondClose"/>

  </div>
</template>

<script>
  import {mapActions, mapGetters} from 'vuex'
  import HtChatFrame from '@/components/chat/Ht-ChatFrame'
  import HtFilesFrame from '@/components/chat/Ht-FilesFrame'
  import HtNoticeFrame from '@/components/chat/Ht-NoticeFrame'
  import HtImagesFrame from '@/components/chat/Ht-ImagesFrame'
  import HtSettingFrame from '@/components/chat/Ht-SettingFrame'
  // 群详情
  import HtGroupDetail from '@/components/contact/Ht-GroupDetails' // 群详情
  import HtAddMemberPop from '@/components/contact/Ht-AddMemberPop'
  // 群设置
  // 群成员
  import {groupInviteToJoin} from '@/api/group'
  import HtChatTranspondPop from '@/components/chat/Ht-ChatTranspondPop'
  import {statistics} from "../../api/chat"; // 转发弹窗
  export default {
    name: "HtChat",
    data() {
      return {
        toolTabShow: 'chat',
        toolTabActive: true,
        settingPanel: false,
        groupDetailShow: false, // 显示群信息,
        member_pop: false
      }
    },
    watch: {
      currentChatId(val) {
        this.toolTabShow = 'chat'
        this.groupDetailShow = false
      }
    },
    mounted() {

    },
    computed: {
      ...mapGetters([
        'staff',
        'currentChatId',
        'currentConversationRelationship',
        'currentConversationType',
        'currentChatUserOnlineType',
        'currentChatName',
        'transpondShow',
        'currentChatUserOnlineType'
      ]),
      toolbarlist() {
        let personalToolList = [
          {
            name: '聊天',
            type: 'chat',
          }, {
            name: '文件',
            type: 'file',
            statisticsType: 'show_file'
          }, {
            name: '图片',
            type: 'image',
            statisticsType: 'show_image'
          }
        ]; // 单聊工具
        let groupToolList = [
          {
            name: '聊天',
            type: 'chat',
          }, {
            name: '文件',
            type: 'file',
            statisticsType: 'show_file'
          }, {
            name: '图片',
            type: 'image',
            statisticsType: 'show_image'
          },
          // {
          //   name:'公告',
          //   type:'notice',
          // }
        ]; // 群聊工具

        return this.currentConversationType === 'G' ? groupToolList : personalToolList
      }
    },
    methods: {
      ...mapActions([
        'getContactGroupId',
        'changeConversation',
        'setContactInfoFrom',
        'setTransPondShowToggle',
        'changeConversationGroupInfo'
      ]),
      clickToolTabTargetShow(item) {
        this.toolTabShow = item.type
        if (item.statisticsType) {
          statistics(item.statisticsType);
        }
        if (this.groupDetailShow) {
          this.groupDetailShow = false
        }
      },
      handelSettingPanelShow() {
        this.settingPanel = !this.settingPanel
      },
      closeSetting() {
        this.settingPanel = false
      },
      // 查看群信息
      handleShowGroupDetail() {
        this.groupDetailShow = !this.groupDetailShow
        this.getContactGroupId(String(this.currentChatId))
        this.setContactInfoFrom('chat')
      },
      // 更多设置
      handleMoreSetting() {
        this.setContactInfoFrom('chat')
        if (!this.groupDetailShow) {
          this.groupDetailShow = true;
          this.getContactGroupId(String(this.currentChatId));
          this.$nextTick(() => {
            this.$refs.HtGroupDetailBox.activeIndex = 2
          })
        }
        this.$nextTick(() => {
          this.$refs.HtGroupDetailBox.activeIndex = 2
        })
      },
      // 查看资料
      handleShowInfo() {
        this.setContactInfoFrom('chat')

        if (!this.groupDetailShow) {
          this.groupDetailShow = true;
          this.getContactGroupId(String(this.currentChatId));
          this.$nextTick(() => {
            this.$refs.HtGroupDetailBox.activeIndex = 0
          })
        }
        this.$nextTick(() => {
          this.$refs.HtGroupDetailBox.activeIndex = 0
        })
      },
      // 邀请入群
      addMemberHandelOpen() {
        this.member_pop = true
        this.groupDetailShow = false;
      },
      // 添加员工弹窗关闭
      addMemberHandelClose() {
        this.member_pop = false
      },
      // 选择添加群成员
      addMemberHandleSubmit(uids, list) {
        console.log('5252525262362')
        if (uids.length <= 0) {
          this.$message({
            type: 'warning',
            message: '至少选择一人',
            center: true
          })
          return
        }
        let group_id = this.currentChatId
        groupInviteToJoin(group_id, uids)
          .then(res => {
            if (res.status === 200) {
              this.$message({
                type: "success",
                message: '成功添加群成员！',
                center: true
              })
              this.member_pop = false
              let obj = {
                uid: group_id
              }
              this.changeConversationGroupInfo(obj)
            } else {
              this.$message.error(res.info)
            }
          }).catch(err => {
          console.log(err)
        })

      },
      // 关闭转发弹窗
      handleTranspondClose() {
        this.setTransPondShowToggle(false)
      }
    },
    components: {
      HtChatFrame,
      HtFilesFrame,
      HtNoticeFrame,
      HtImagesFrame,
      HtSettingFrame,
      HtGroupDetail,
      HtAddMemberPop,
      HtChatTranspondPop
    }
  }
</script>

<style scoped>

</style>
