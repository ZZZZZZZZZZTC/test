<template>
  <div class="message-file-views">
    <div class="fv-cont">
      <div class="cont-img">
        <!--文件图标 分类-->
        <!--PSD 文件-->
        <template v-if="/\.(psd)(\?.*)?$/.test(fileData.content.type)">
          <svg class="img-svg-icon psd-icon" aria-hidden="true">
            <use xlink:href="#icon-psd"></use>
          </svg>
        </template>
        <!--word 文件-->
        <template v-else-if="/\.(doc|docx)(\?.*)?$/.test(fileData.content.type)">
          <svg class="img-svg-icon word-icon" aria-hidden="true">
            <use xlink:href="#icon-word"></use>
          </svg>
        </template>
        <!--Excel 文件--->
        <template v-else-if="/\.(xlsx|xls|xlsm|xlt|xltx|xltm)(\?.*)?$/.test(fileData.content.type)">
          <svg class="img-svg-icon excel-icon" aria-hidden="true">
            <use xlink:href="#icon-excel"></use>
          </svg>
        </template>
        <!--txt 文件-->
        <template v-else-if="/\.(txt)(\?.*)?$/.test(fileData.content.type)">
          <svg class="img-svg-icon txt-icon" aria-hidden="true">
            <use xlink:href="#icon-txt"></use>
          </svg>
        </template>
        <!--PPT 文件-->
        <template v-else-if="/\.(ppt|pptx)(\?.*)?$/.test(fileData.content.type)">
          <svg class="img-svg-icon ppt-icon" aria-hidden="true">
            <use xlink:href="#icon-ppt"></use>
          </svg>
        </template>
        <!--图片 文件-->
        <template v-else-if="/\.(png|jpe?g|gif|svg|jpg)(\?.*)?$/.test(fileData.content.type)">
          <svg class="img-svg-icon" aria-hidden="true">
            <use xlink:href="#icon-tupian"></use>
          </svg>
        </template>
        <!--压缩包 文件-->
        <template v-else-if="/\.(rar|cab|arj|lzh|tar|uue|jar)(\?.*)?$/.test(fileData.content.type)">
          <svg class="img-svg-icon" aria-hidden="true">
            <use xlink:href="#icon-rar"></use>
          </svg>
        </template>
        <template v-else-if="/\.(zip|7-zip|gzip|7z|z)(\?.*)?$/.test(fileData.content.type)">
          <svg class="img-svg-icon zip-icon" aria-hidden="true">
            <use xlink:href="#icon-zip"></use>
          </svg>
        </template>
        <!--xmind 文件-->
        <template v-else-if="/\.(xmind)(\?.*)?$/.test(fileData.content.type)">
          <svg class="img-svg-icon xmind-icon" aria-hidden="true">
            <use xlink:href="#icon-xmind"></use>
          </svg>
        </template>
        <!--pdf 文件-->
        <template v-else-if="/\.(pdf)(\?.*)?$/.test(fileData.content.type)">
          <svg class="img-svg-icon pdf-icon" aria-hidden="true">
            <use xlink:href="#icon-pdf"></use>
          </svg>
        </template>
        <!--AI-->
        <template v-else-if="/\.(ai)(\?.*)?$/.test(fileData.content.type)">
          <svg class="img-svg-icon ai-icon" aria-hidden="true">
            <use xlink:href="#icon-ai"></use>
          </svg>
        </template>
        <!--其他文件-->
        <template v-else>
          <svg class="img-svg-icon default-icon" aria-hidden="true">
            <use xlink:href="#icon-default"></use>
          </svg>
        </template>
      </div>

      <div class="cont-info">
        <div class="info-name clearfix">
          <p class="name-p fl" :title="fileData.content.name">{{fileData.content.name}}</p>
          <span class="size-span fl">({{fileData.content.size | getFileSize}})</span>
        </div>
        <div class="info-status">
          <div class="status-progress"
               v-if="fileData.complete && fileData.complete<100"
          >
            <el-progress :percentage="fileData.complete" :stroke-width="3"></el-progress>
          </div>
          <!--状态-->
          <div class="status-tips">
            <!--发送成功-->
            <span v-if="fileData.sentStatus === 2&& fileData.senderUserId===staff.uid"><i
              class="iconfont icon-file-done status-icon success-icon"></i>成功发送文件</span>
            <!--发送失败-->
            <span v-if="fileData.sentStatus === 10"><i class="iconfont icon-file-cancel status-icon error-icon"></i>发送文件失败</span>
            <!--接收成功-->
            <span v-if="fileData.sentStatus === 2&& fileData.senderUserId!==staff.uid&&isDownloaded" ><i
              class="iconfont icon-file-done status-icon success-icon"></i>成功接收文件</span>
            <!--接收失败-->
            <!--<span><i class="iconfont icon-file-cancel status-icon error-icon"></i>文件接收失败</span>-->
          </div>
        </div>
      </div>
    </div>
    <div class="fv-handle">
      <!--默认-->
      <div class="handle-btns" v-if="(fileData.sentStatus == 2||fileData.sentStatus == 4) && fileData.senderUserId==staff.uid">
        <!--<el-button type="text" class="btns-fileData">打开</el-button>-->
        <!--<el-button type="text" class="btns-fileData">打开文件夹</el-button>-->
        <el-button type="text" class="btns-fileData" @click="handleTransFile(fileData)">转发</el-button>
      </div>
      <!--发送取消-->
      <div class="handle-btns" v-if="fileData.sentStatus < 2">
        <el-button type="text" class="btns-fileData" @click.stop="cancelUpload(fileData.messageUId)">取消</el-button>
      </div>
      <!--接收-->
      <div class="handle-btns" style="" v-if="(fileData.sentStatus == 2||fileData.sentStatus == 4)&& fileData.senderUserId!=staff.uid">
        <el-button type="text" class="btns-fileData" @click="openFile" v-if="isDownloaded">打开</el-button>
        <el-button type="text" class="btns-fileData" @click="openDir" v-if="isDownloaded">打开文件夹</el-button>
        <el-button type="text" class="btns-fileData" @click="receiveFile(fileData.content)" v-if="!isDownloaded">接收
        </el-button>
        <el-button type="text" class="btns-fileData" @click="downloadFile(fileData.content)" v-if="!isDownloaded">另存为
        </el-button>
        <el-button type="text" class="btns-fileData" @click="handleTransFile(fileData)">转发</el-button>
      </div>
    </div>


  </div>
</template>

<script>
  import {mapGetters, mapActions, mapMutations} from 'vuex'
  import {structRelationship} from '@/utils/utils'

  export default {
    name: "HtMessageFiles",
    props: {
      fileData: {
        type: Object,
        default: {}
      }
    },
    computed: {
      ...mapGetters([
        'staff',
        'isInClient'
      ]),
    },
    data() {
      return {
        isDownloaded: false,
        downloadUrl: ''
      }
    },
    methods: {
      ...mapActions([
        'getTransPondData',
        'setTransPondShowToggle',
        'cancelUploadFile'
      ]),
      handleTransFile(item) {
        console.log(item, 333)
        if (!item.content.content) {
          this.$message.error('文件已损坏，无法转发')
          return
        }
        let _relationship = structRelationship(this.staff.uid, item.targetId)
        let data = {
          content: item,
          relationship: item.relationship ? item.relationship : _relationship,
          fromPath: 'chatFrame',
          type: 4
        };
        this.getTransPondData(data);
        this.setTransPondShowToggle(true)
      },
      downloadFile(item) {
        console.log(item)
        let _this = this
        if (this.isInClient) {
          window.hanClient.downloadFile({
            strUrl: item.content,
            strFileName: item.name,
            strDownloadType: "2",
            onSuccess: function (response) {
              _this.$message.success('文件已保存');
              _this.isDownloaded = true
              _this.downloadUrl = response
              // let payload = {
              //   message_id: item.message_id,
              //   relationshipId: tempRelationship,
              //   key, response
              // }
              // _this.openConversationFile(payload)
            },
            onFailure: function (error_code, error_message) {
              if (error_code == 1) {
                // let data = {
                //   message_id: item.message_id,
                //   relationshipId: tempRelationship,
                //   key
                // }
                // _this.resetConversationFile(data)
              } else {
                _this.$message.error(error_message);
              }

            }
          })
        } else {
          window.hanClient.downloadFile({
            strUrl: item.content,
            strFileName: item.name,
            strDownloadType: "2"
          })
        }
      },
      receiveFile(item) {
        let _this = this
        if (this.isInClient) {
          window.hanClient.downloadFile({
            strUrl: item.content,
            strFileName: item.name,
            strDownloadType: "1",
            onSuccess: function (response) {
              _this.$message.success('文件已保存');
              _this.isDownloaded = true
              _this.downloadUrl = response
              // let payload = {
              //   message_id: item.message_id,
              //   relationshipId: tempRelationship,
              //   key, response
              // }
              // _this.openConversationFile(payload)
            },
            onFailure: function (error_code, error_message) {
              if (error_code == 1) {
                // let data = {
                //   message_id: item.message_id,
                //   relationshipId: tempRelationship,
                //   key
                // }
                // _this.resetConversationFile(data)
              } else {
                _this.$message.error(error_message);
              }

            }
          })
        } else {
          window.hanClient.downloadFile({
            strUrl: item.content,
            strFileName: item.name,
            strDownloadType: "1"
          })
        }
      },
      openFile() {
        let url = this.downloadUrl
        window.hanClient.openFileFloder('file', url)
      },
      openDir() {
        let url = this.downloadUrl
        window.hanClient.openFileFloder('floder', url)
      },
      cancelUpload(uid){
        this.cancelUploadFile(uid)
      }
    },
    components: {}
  }
</script>

<style scoped>

</style>
