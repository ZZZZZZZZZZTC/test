<template>
  <div class="btns-span tran statistics-send__image" ref="uploadImageBtn">
    <i class="iconfont icon-picture"></i>
    <div class="loading-mask" v-show="loading">
      <span class="el-icon-loading" ></span>
    </div>

    <input type="file" ref="uploadImageInput" style="display: none" accept="image/*" />
  </div>

</template>

<script>
  import {mapGetters, mapActions, mapMutations} from 'vuex'
  import {statistics} from '@/api/chat'
  export default {
    name: "Ht-ChatUploadImg",
    data() {
      return {
        domain: '',
        expires: 0,
        saveKeyPrefix: '',
        upToken: '',
        loading: false
      }
    },
    mounted() {
      this.eventSendImage()
    },
    computed: {
      ...mapGetters([
        'currentChatId',
      ]),
    },
    methods: {
      ...mapActions([
        'uploadFile'
      ]),
      eventSendImage() {
        let _this = this;
        let file = this.$refs.uploadImageInput
        file.onchange = function () {
          let _file = this.files[0];
          if (_file.size > 12 * 1024 * 1024) {
            _this.$message.info('您的图片超出12M文件大小限制，请使用文件发送')
            return
          }
          // if(img.fileSize>10*1024){
          //
          // }
          console.log(_file)
          let data ={
            file:_file,
            type:2,
            id:_this.currentChatId
          }
          _this.uploadFile(data)
          _this.$emit('uploadImg')
          file.value = ''
        };
        // 点击图标上传
        let btn = this.$refs.uploadImageBtn
        btn.onclick = function () {
          statistics('send_image');
          file.click()
        }
      },
    },
  }
</script>

<style scoped>

</style>
