<template>
  <div>
    <div v-if="voiceType == 'chatVoice'" @click="player" class="message-voice-views"
         :class="{'self-video-views':(voiceData.senderUserId === staff.uid)}">
      <audio hidden @ended=over() @loadedmetadata="init($event)">
        <source :src="prix + voiceData.content.content" type="audio/wav">
        <!--prix + voiceData.content.content-->
      </audio>
      <!--语音时长-->
      <span class="voice-time">{{voiceData.content.duration}}"</span>
      <!--播放背景动画-->
      <div class="voice-back "
           :class="[{'other-bg-pause':voiceData.senderUserId != staff.uid},
         {'self-bg-pause':voiceData.senderUserId == staff.uid},
         {'other-bg-running':(voiceData.senderUserId != staff.uid)&&(voiceStatus==1)},
         {'self-bg-running':(voiceData.senderUserId == staff.uid)&&(voiceStatus==2)}]"></div>
      <!-- 未读提示红点-->
      <span class="voice-point" v-if="!isRead && (voiceData.senderUserId != staff.uid)"></span>
    </div>
    <div class="part-voice" v-if="voiceType == 'recordVoice'">
      <div class="message-voice-views"  @click="player">
        <audio :src="prix + voiceData.content.content" hidden @ended=over() @loadedmetadata="init($event)"></audio>
        <span class="voice-time">{{voiceData.content.duration}}</span>
        <div class="voice-back other-bg-pause"
             :class="{'other-bg-running':voiceStatus == 1}"></div>
      </div>
    </div>
  </div>
</template>

<script>
  import {mapGetters, mapActions} from 'vuex'
  export default {
    name: "Ht-MessageVoice",
    props: {
      voiceData: {
        type: Object,
        default: {}
      },
      currentPlayVoiceMsgId: {
        type: String,
        default: ''
      },
      voiceType:{
        type:String,
        default:'chatVoice'
      }
    },
    data() {
      return {
        prix: 'data:audio/wav;base64,',
        audio: null,
        loadFlag: false,//语音加载完成
        voiceStatus: 0,
        isRead:false,
        voice:''
      }
    },
    watch: {
      currentPlayVoiceMsgId(val,oldval){
        if(val == this.voiceData.id){

        }else{
          this.audio.pause();
          this.audio.currentTime = 0;
          this.voiceStatus = 0
        }
      }
    },
    computed: {
      ...mapGetters([
        'staff'
      ]),
    },
    mounted() {
      console.log(this.voiceData, '语音数据')
    },
    methods: {
      ...mapActions([]),
      //等待语音加载完成
      init($event) {
        this.loadFlag = true;
        this.audio = $event.currentTarget;
      },
      //开始播放
      player() {
        if (!this.loadFlag) {
          return;
        }
        this.isRead = true;
        this.$emit('changeCurrentPlayId',this.voiceData.id)
       // let audioItem = this.$refs.audio;
        if(!this.audio.paused){
            this.audio.pause();
            this.audio.currentTime = 0;
          this.voiceStatus = 0;
        }else{
          if(this.voiceData.senderUserId == this.staff.uid){
            this.voiceStatus = 2;
          }else{
            this.voiceStatus = 1;
          }
          this.audio.play();
        }
        console.log(this.voiceStatus)
      },
      //停止播放
      stop() {
        this.audio.pause();
        this.audio.currentTime = 0;
      },
      //播放结束
      over() {
        this.audio.currentTime = 0;
        this.voiceStatus = 0;
        this.$emit('changeCurrentPlayId','')
      }
    }
  }
</script>

<style scoped>

</style>
