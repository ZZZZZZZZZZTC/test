<template>
  <div class="ht-search-docs" :class="{'hasPage':activeName !== 'all'}">
    <div class="search-docs__top">
      <!--返回按钮-->
      <span class="search-back" @click="handleSearchBack">
          <svg class="back-icon" aria-hidden="true">
            <use xlink:href="#icon-search-back"></use>
          </svg>
          返回
        </span>
      <!--搜索框-->
      <div class="top-search-input">
        <input type="text"
               ref="searchDosInput"
               v-model="keyWord"
               @keydown.enter="getSearchResult">
        <span class="delet-icon" @click="deleteSearchWords" v-if="keyWord">
            <i class="iconfont icon-deletechat"></i>
         </span>
      </div>
    </div>

    <div v-if="!inSearchStatus"  class="noHas-tip">
      <el-button type="text">
        请输入关键词搜索文档
      </el-button>
    </div>
    <div class="search-docs__cont" v-if="inSearchStatus">
      <el-tabs v-model="activeName" class="docs-tabs">
        <el-tab-pane label="全部" name="all">
          <SmScroll>
            <div class="cont-main-box">
              <!--调查分析-->
              <div class="box-block" v-if="analysisList.total > 0">
                <div class="block-title">
                  <h4>调查分析</h4>
                </div>
                <ul class="block-list">
                  <li class="list-item" v-for="item in analysisList.list" :key="item.id">
                    <a :href="'https://hc.hanmaker.com/analysis/s-3-2-'+item.id" target="_blank"
                       class="item-title tran">
                        <span class="result-light title-name"
                              :title="item.title | delHtmlTag"
                              v-html=" item.title">
                        </span>
                    </a>
                    <div class="item-info result-light" v-html="item.info">
                    </div>
                    <div class="item-handle clearfix">
                      <span class="handle-name result-light fl">
                        <span class="result-light" v-html="item.create_name"></span>
                        更新于
                       <span> {{item.create_time | unixDateFormat('YYYY-MM-DD')}}</span>
                      </span>
                      <span class="handle-butn fr">
                          <el-button type="text" class="hd-btn" @click.native="handleTransPopShow(item)">转发</el-button>
                          <el-button type="text" class="hd-btn" @click="handleSendImgTextMsg(item)">发送</el-button>
                        </span>
                    </div>
                  </li>
                </ul>
                <span class="block-more" v-show="analysisList.total > 3" @click="activeName = 'analysis'">
                    查看更多“{{keyWord}}”相关调查分析搜索结果
                </span>
              </div>
              <!--文档-->
              <div class="box-block" v-if="docsList.total > 0">
                <div class="block-title">
                  <h4>文档</h4>
                </div>
                <ul class="block-list">
                  <li class="list-item" v-for="item in docsList.list" :key="item.id">
                    <a :href="'https://hc.hanmaker.com/document/'+item.id" target="_blank" class="item-title tran">
                        <span class="result-light title-name"
                              :title="item.title | delHtmlTag"
                              v-html="item.title">
                        </span>
                    </a>
                    <div class="item-info result-light" v-html="item.info">
                    </div>
                    <div class="item-handle clearfix">
                      <span class="handle-name result-light fl">
                        <span class="result-light"
                              v-html="item.create_name">
                        </span>
                        更新于
                       <span> {{item.create_time | unixDateFormat('YYYY-MM-DD')}}</span>
                      </span>
                      <span class="handle-butn fr">
                          <el-button type="text" class="hd-btn" @click.native="handleTransPopShow(item)">转发</el-button>
                          <el-button type="text" class="hd-btn" @click="handleSendImgTextMsg(item)">发送</el-button>
                        </span>
                    </div>
                  </li>
                </ul>
                <span class="block-more" v-show="docsList.total > 3" @click="activeName = 'docs'">
                    查看更多“{{keyWord}}”相关文档搜索结果
                  </span>
              </div>
              <!--制度-->
              <div class="box-block" v-if="systemList.total > 0">
                <div class="block-title">
                  <h4>制度</h4>
                </div>
                <ul class="block-list">
                  <li class="list-item" v-for="item in systemList.list" :key="item.id">
                    <a :href="'https://hc.hanmaker.com/system/'+item.id" target="_blank" class="item-title tran">
                        <span class="result-light title-name"
                              :title="item.title | delHtmlTag"
                              v-html=" item.title">
                        </span>
                    </a>
                    <div class="item-info result-light" v-html="item.info">
                    </div>
                    <div class="item-handle clearfix">
                      <span class="handle-name result-light fl">
                           <span class="result-light"
                                 v-html="item.create_name">
                        </span>
                        更新于
                       <span> {{item.create_time | unixDateFormat('YYYY-MM-DD')}}</span>
                      </span>
                      <span class="handle-butn fr">
                          <el-button type="text" class="hd-btn" @click.native="handleTransPopShow(item)">转发</el-button>
                          <el-button type="text" class="hd-btn" @click="handleSendImgTextMsg(item)">发送</el-button>
                        </span>
                    </div>
                  </li>
                </ul>
                <span class="block-more" v-show="systemList.total > 3" @click="activeName = 'system'">
                    查看更多“{{keyWord}}”相关制度搜索结果
                  </span>
              </div>
            </div>
          </SmScroll>
        </el-tab-pane>
        <el-tab-pane label="调查分析" name="analysis">
          <SmScroll>
            <div class="cont-main-box">
              <div class="box-block">
                <div class="block-title">
                  <h4>调查分析</h4>
                </div>
                <ul class="block-list" v-if="analysisList.total > 0">
                  <li class="list-item" v-for="item in analysisList.list" :key="item.id">
                    <a :href="'https://hc.hanmaker.com/analysis/s-3-2-'+item.id" target="_blank"
                       class="item-title tran">
                        <span class="result-light title-name"
                              :title="item.title | delHtmlTag"
                              v-html=" item.title">
                        </span>
                    </a>
                    <div class="item-info result-light" v-html="item.info">
                    </div>
                    <div class="item-handle clearfix">
                      <span class="handle-name result-light fl">
                        <span class="result-light" v-html="item.create_name"></span>
                        更新于
                       <span> {{item.create_time | unixDateFormat('YYYY-MM-DD')}}</span>
                      </span>
                      <span class="handle-butn fr">
                          <el-button type="text" class="hd-btn" @click.native="handleTransPopShow(item)">转发</el-button>
                          <el-button type="text" class="hd-btn" @click="handleSendImgTextMsg(item)">发送</el-button>
                        </span>
                    </div>
                  </li>
                </ul>
                <p style="padding: 20px 0;text-align: center" v-if="analysisList.total == 0">
                  <el-button type="text">
                    没有搜到任何结果哦~~
                  </el-button>
                </p>
              </div>
            </div>
          </SmScroll>
        </el-tab-pane>
        <el-tab-pane label="文档" name="docs">
          <SmScroll>
            <div class="cont-main-box">
              <!--文档-->
              <div class="box-block">
                <div class="block-title">
                  <h4>文档</h4>
                </div>
                <ul class="block-list" v-if="docsList.total > 0">
                  <li class="list-item" v-for="item in docsList.list" :key="item.id">
                    <a :href="'https://hc.hanmaker.com/document/'+item.id" target="_blank" class="item-title tran">
                        <span class="result-light title-name"
                              :title="item.title | delHtmlTag"
                              v-html="item.title">
                        </span>
                    </a>
                    <div class="item-info result-light" v-html="item.info">
                    </div>
                    <div class="item-handle clearfix">
                      <span class="handle-name result-light fl">
                        <span class="result-light"
                              v-html="item.create_name">
                        </span>
                        更新于
                       <span> {{item.create_time | unixDateFormat('YYYY-MM-DD')}}</span>
                      </span>
                      <span class="handle-butn fr">
                          <el-button type="text" class="hd-btn" @click.native="handleTransPopShow(item)">转发</el-button>
                          <el-button type="text" class="hd-btn" @click="handleSendImgTextMsg(item)">发送</el-button>
                        </span>
                    </div>
                  </li>
                </ul>
                <p style="padding: 20px 0;text-align: center" v-if="docsList.total == 0 ">
                  <el-button type="text">
                    没有搜到任何结果哦~~
                  </el-button>
                </p>
              </div>
            </div>
          </SmScroll>
        </el-tab-pane>
        <el-tab-pane label="制度" name="system">
          <SmScroll>
            <div class="cont-main-box">
              <!--制度-->
              <div class="box-block">
                <div class="block-title">
                  <h4>制度</h4>
                </div>
                <ul class="block-list" v-if="systemList.total > 0">
                  <li class="list-item" v-for="item in systemList.list" :key="item.id">
                    <a :href="'https://hc.hanmaker.com/system/'+item.id" target="_blank" class="item-title tran">
                        <span class="result-light title-name"
                              :title="item.title | delHtmlTag"
                              v-html=" item.title">
                        </span>
                    </a>
                    <div class="item-info result-light" v-html="item.info">
                    </div>
                    <div class="item-handle clearfix">
                      <span class="handle-name result-light fl">
                           <span class="result-light"
                                 v-html="item.create_name">
                        </span>
                        更新于
                       <span> {{item.create_time | unixDateFormat('YYYY-MM-DD')}}</span>
                      </span>
                      <span class="handle-butn fr">
                          <el-button type="text" class="hd-btn" @click.native="handleTransPopShow(item)">转发</el-button>
                          <el-button type="text" class="hd-btn" @click="handleSendImgTextMsg(item)">发送</el-button>
                        </span>
                    </div>
                  </li>
                </ul>
                <p style="padding: 20px 0;text-align: center" v-if="systemList.total === 0">
                  <el-button type="text">
                    没有搜到任何结果哦~~
                  </el-button>
                </p>
              </div>
            </div>
          </SmScroll>
        </el-tab-pane>
      </el-tabs>
    </div>

    <!--分页-->
    <div class="pages" v-if="activeName != 'all'">
      <el-pagination
        small
        layout="prev, pager, next"
        :page-size="pageSize"
        :total="total"
        :current-page.sync="currentPage"/>
    </div>
  </div>
</template>
<script>
  import {mapGetters, mapActions} from 'vuex'
  import {getSo} from '@/api/chat.js'
  import {unixDateFormat,delHtmlTag} from '@/filters/index'
  export default {
    name: "HtSearchDocs",
    props: {
      currentChatId: {
        type: [String, Number],
        default: ''
      },
      searchWords: {
        type: String,
        default: ''
      }
    },
    mounted() {
      this.keyWord = this.searchWords
      this.$nextTick(() => {
        if (!this.keyWord) return
        if (this.activeName === 'all' && this.keyWord) {
          this.inSearchStatus = true
          this.getFetchData(4, 3)
          this.getFetchData(5, 3)
          this.getFetchData(6, 3)
        }
      })
    },
    data() {
      return {
        keyWord: '',
        activeName: 'all',
        docsList: [], // 文档
        analysisList: [], // 调查分析
        systemList: [], // 制度,
        total: 0,
        inSearchStatus: false,

        currentPage: 1,
        pageSize: 20,
      }
    },
    watch: {
      activeName(nVal) {
        switch (nVal) {
          case 'all':
            this.getFetchData(4, 3)
            this.getFetchData(5, 3)
            this.getFetchData(6, 3)

            break;
          case 'docs':
            this.currentPage = 1
            this.getFetchData(4, 20)

            break;
          case 'analysis':
            this.currentPage = 1
            this.getFetchData(5, 20)

            break;
          case 'system':
            this.currentPage = 1
            this.getFetchData(6, 20)
            // this.$refs.elTabScrollCont.$el.children[1].scrollTop = 0
            break;
        }
      },
      currentPage() {
        switch (this.activeName) {
          case 'all':
            this.getFetchData(4, 3)
            this.getFetchData(5, 3)
            this.getFetchData(6, 3)
            // this.$refs.elTabScrollCont.$el.children[1].scrollTop = 0
            break;
          case 'docs':
            this.getFetchData(4, 20)
            // this.$refs.elTabScrollCont.$el.children[1].scrollTop = 0
            break;
          case 'analysis':
            this.getFetchData(5, 20)
            // this.$refs.elTabScrollCont.$el.children[1].scrollTop = 0
            break;
          case 'system':
            this.getFetchData(6, 20)
            // this.$refs.elTabScrollCont.$el.children[1].scrollTop = 0
            break;
        }
      },
      keyWord(val){
        if(val == ''){
          this.docsList =  []; // 文档
          this.analysisList = []; // 调查分析
          this.systemList =  []; // 制度,
        }
      }
    },
    methods: {
      ...mapActions([
        'sendChatMessage',
        'getTransPondData',
        'setTransPondShowToggle'
      ]),
      // 获取数据
      getFetchData(type, size) {
        if (!this.keyWord) return
        //  搜索文档请求部分
        switch (type) {
          case 4:
            getSo(4, this.keyWord, this.currentPage, size)
              .then(res => {
                this.docsList = res.data
                this.total = this.docsList.total
              }).catch(err => {
              console.log(err)
            })
            break;
          case 5:      // 获取调查分析
            getSo(5, this.keyWord, this.currentPage, size)
              .then(res => {
                this.analysisList = res.data
                this.total = this.analysisList.total
              }).catch(err => {
              console.log(err)
            })
            break;
          case 6:// 获取制度
            getSo(6, this.keyWord, this.currentPage, size)
              .then(res => {
                this.systemList = res.data
                this.total = this.systemList.total
              }).catch(err => {
              console.log(err)
            })
            break;
        }

      },
      getSearchResult() {
        this.inSearchStatus = true
        switch (this.activeName) {
          case 'all':
            this.getFetchData(4, 3)
            this.getFetchData(5, 3)
            this.getFetchData(6, 3)
            break;
          case 'docs':
            this.getFetchData(4, 20)
            break;
          case 'analysis':
            this.getFetchData(5, 20)
            break;
          case 'system':
            this.getFetchData(6, 20)
            break;
        }

        // this.$nextTick(()=>{
        //   this.$refs.elTabScrollCont.$el.children[1].scrollTop = 0
        // })
      },
      handleSearchBack() {
        this.$emit("handleSearchBack")
        this.keyWord = ''
      },
      // 清空input框
      deleteSearchWords() {
        this.keyWord = ''
      },
      // 发送消息
      handleSendImgTextMsg(item) {
        let url = '';
        let _document;
        switch (item._index) {
          case 'common_analysis':
            url = `https://hc.hanmaker.com/analysis/s-3-2-${item.id}`
            _document = 1
            break;
          case 'common_system':
            url = `https://hc.hanmaker.com/system/${item.id}`
            _document = 2
            break;
          case 'common_document':
            url = `https://hc.hanmaker.com/document/${item.id}`
            _document = 3
            break;
          case 'common_compete':
            _document = 4
            break;
        }
        let data = {
          uid: this.currentChatId,
          content:{
            title:delHtmlTag(item.title),
            content:delHtmlTag(item.info),
            imgUrl:'https://pic2.hanmaker.com/im/default/20180109/5a542f5886d9b.png',
            extra:{
              id:item.id,
              document:_document,
              type:1,
              cont:url,
              username:item.create_name + ' 更新于' + unixDateFormat(item.create_time, 'YYYY-MM-DD'),
              image:'https://pic2.hanmaker.com/im/default/20180109/5a542f5886d9b.png'
            },
            url:url
          },
          objectName:'RC:ImgTextMsg',
          type: 8
        }
        this.sendChatMessage(data);
      },
      // 转发弹窗展示
      handleTransPopShow(item) {
        let url = ''
        let _document;
        switch (item._index) {
          case 'common_analysis':
            url = `https://hc.hanmaker.com/analysis/s-3-2-${item.id}`
            _document = 1
            break;
          case 'common_system':
            url = `https://hc.hanmaker.com/system/${item.id}`
            _document = 2
            break;
          case 'common_document':
            url = `https://hc.hanmaker.com/document/${item.id}`
            _document = 3
            break;
          case 'common_compete':
            _document = 4
            break;
        }
        let data = {
          content:{
            title:delHtmlTag(item.title),
            content:delHtmlTag(item.info),
            imgUrl:'https://pic2.hanmaker.com/im/default/20180109/5a542f5886d9b.png',
            extra:{
              id:item.id,
              document:_document,
              type:1,
              cont:url,
              username:item.create_name + ' 更新于' + unixDateFormat(item.create_time, 'YYYY-MM-DD'),
              image:'https://pic2.hanmaker.com/im/default/20180109/5a542f5886d9b.png'
            },
            url:url
          },
          fromPath:'searchDocs',
          type: 8
        }
        this.setTransPondShowToggle(true)
        this.getTransPondData(data)
      },
    }
  }
</script>
<style scoped>

</style>
