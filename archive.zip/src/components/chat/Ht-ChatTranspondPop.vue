<template>
  <div class="ht-creat-group" v-if="show">
    <div class="creat-group__cont">
      <div class="creat-group__head">
        <div class="log-title">
          <i class="iconfont icon-group-icon"></i>
          转发
        </div>
        <div class="handle-bar">
       <span class="close-btn" @click.stop="handleClose">
          <i class="iconfont icon-close"></i>
       </span>
        </div>
      </div>
      <div class="creat-group__body">
        <!--邀请成员设置-->
        <div class="invite-setting default">
          <div class="shuttle-box">
            <div class="shuttle-item selected-item">
              <!--搜索-->
              <div class="shuttle-item__search">
                <input type="text" placeholder="搜索成员"
                       v-model="filterWords"
                       @keyup.enter="resultSelectEnter"
                       @keydown.down.prevent="resultSelectDown"
                       @keydown.up.prevent="resultSelectUp">
              </div>
              <!--成员-->
              <div class="shuttle-item__list">
                <SmScroll>
                  <ul class="shuttle-menu">
                    <!--群组默认成员-->
                    <li class="menu-item" v-for="(item,index) in outerList" :key="item.part_id">
                      <!--标题栏-->
                      <div class="menu-item__title tran" :class="{'active':item.opened}"
                           @click="outerOpen(item.part_id)">
                        <span class="title-name"> {{item.name}}</span>
                        <i class="tit-arr iconfont icon-group-arrow tran"></i>
                      </div>
                      <!--群组-->
                      <template v-if="item.type === 'groupes'">
                        <ul class="sub-shuttle__menu left-list__menu">
                          <li class="sub-menu__item tran"
                              v-for="(item,index) in ownGroupList"
                              @click="selectOwnGroupList(item.id)"
                              :key="item.id">
                            <img :src="item.avatar" :alt="item.group_name" class="member-avatar">
                            <p class="member-name">
                              {{item.group_name}}
                            </p>
                            <i class="iconfont icon-duihao selected-icon" v-show='item.selected'></i>
                          </li>
                        </ul>
                      </template>
                      <!--组织架构-->
                      <template v-if="item.type === 'organization'">
                        <ul class="sub-shuttle__menu left-list__menu">
                          <ul class="shuttle-menu">
                            <li class="menu-item" v-for="(item,index) in fullGroupsList"
                                :key="index">
                              <!--标题栏-->
                              <div class="menu-item__title tran" :class="{'active':item.opened}"
                                   @click="orgOpen(item.part_id)">
                                <span class="title-name"> {{item.name}}</span>
                                <i class="tit-arr iconfont icon-group-arrow tran"></i>
                              </div>
                              <!--列表-->
                              <ul class="sub-shuttle__menu left-list__menu">
                                <li class="sub-menu__item tran"
                                    v-for="(uitem,key) in item.userList" :key="uitem.uid"
                                    @click="selectRenceChat(uitem.uid)">
                                  <img :src="uitem.avatar" :alt="uitem.full_name" class="member-avatar">
                                  <p class="member-name" :title="uitem.full_name">
                                    <span>{{uitem.full_name}}</span>
                                  </p>
                                  <i class="iconfont icon-duihao selected-icon" v-show='uitem.selected'></i>
                                </li>
                              </ul>
                            </li>
                          </ul>
                        </ul>
                      </template>
                      <!--最近联系人-->
                      <template v-else-if="item.type === 'recentChat'">
                        <ul class="sub-shuttle__menu left-list__menu">
                          <li class="sub-menu__item tran"
                              v-for="(item,index) in recentChatList" :key="item.id"
                              @click="selectRenceChat(item.id)">
                            <img :src="item.avatar" :alt="item.name" class="member-avatar">
                            <p class="member-name">
                              {{item.name}}
                            </p>
                            <i class="iconfont icon-duihao selected-icon" v-show='item.selected'></i>
                          </li>
                        </ul>
                      </template>
                    </li>
                  </ul>
                </SmScroll>
              </div>

              <!--搜索结果-->
              <div class="shuttle-search__result" v-if="searchFilterResult.length > 0">
                <div class="shuttle-item__list">
                  <SmScroll :listenData="searchFilterResult" ref="searchResultScroll">
                    <ul class="sub-shuttle__menu">
                      <li class="sub-menu__item tran"
                          v-for="(rItem,rIndex) in searchFilterResult"
                          :class="{'active':searchSelectIndex === rIndex}"
                          @click="handleSelectUser(rItem.uid)"
                          :key="rIndex" ref="searchResultLi">
                        <img :src="rItem.avatar" :alt="rItem.name" class="member-avatar">
                        <p class="member-name">
                          <span>{{rItem.name}}</span>
                        </p>
                      </li>
                    </ul>
                  </SmScroll>
                </div>
              </div>

            </div>
            <!--选择结果-->
            <div class="shuttle-item  trans-shuttle-item">
              <!--文档图文消息-->
              <template v-if="transpondData.objectName === 'RC:ImgTextMsg'">
                <div class="transpond-box">
                  <div class="transpond-box__cont">
                    <div class="cont-head">
                      <img :src="transpondData.content.imgUrl || transpondData.content.extra.image || transpondData.content.imageUri" alt="" class="icon-img">
                      <div class="head-info">
                        <p class="info-p" :title="transpondData.content.title | delHtmlTag"
                           v-html="transpondData.content.title"></p>
                        <p class="info-p" v-html="transpondData.content.content"></p>
                      </div>
                    </div>
                    <div class="cont-foot">
                      <p>
                        <span class="result-light" v-html="transpondData.content.extra.username"></span>
                      </p>
                    </div>
                  </div>
                </div>
              </template>

              <!--文件消息-->
              <template v-if="transpondData.objectName === 'RC:FileMsg'">
                <div class="transpond-box">
                  <div class="transpond-box__cont">
                    <div class="cont-head">
                      <!--文件图标 分类-->
                      <!--PSD 文件-->
                      <template v-if="/\.(psd)(\?.*)?$/.test(transpondData.content.type)">
                        <svg class="icon-img psd-icon" aria-hidden="true">
                          <use xlink:href="#icon-psd"></use>
                        </svg>
                      </template>
                      <!--word 文件-->
                      <template v-else-if="/\.(doc|docx)(\?.*)?$/.test(transpondData.content.type)">
                        <svg class="icon-img word-icon" aria-hidden="true">
                          <use xlink:href="#icon-word"></use>
                        </svg>
                      </template>
                      <!--Excel 文件--->
                      <template v-else-if="/\.(xlsx|xls|xlsm|xlt|xltx|xltm)(\?.*)?$/.test(transpondData.content.type)">
                        <svg class="icon-img excel-icon" aria-hidden="true">
                          <use xlink:href="#icon-excel"></use>
                        </svg>
                      </template>
                      <!--txt 文件-->
                      <template v-else-if="/\.(txt)(\?.*)?$/.test(transpondData.content.type)">
                        <svg class="icon-img txt-icon" aria-hidden="true">
                          <use xlink:href="#icon-txt"></use>
                        </svg>
                      </template>
                      <!--PPT 文件-->
                      <template v-else-if="/\.(ppt|pptx)(\?.*)?$/.test(transpondData.content.type)">
                        <svg class="icon-img ppt-icon" aria-hidden="true">
                          <use xlink:href="#icon-ppt"></use>
                        </svg>
                      </template>
                      <!--图片 文件-->
                      <template v-else-if="/\.(png|jpe?g|gif|svg)(\?.*)?$/.test(transpondData.content.type)">
                        <svg class="icon-img" aria-hidden="true">
                          <use xlink:href="#icon-tupian"></use>
                        </svg>
                      </template>
                      <!--压缩包 文件-->
                      <template v-else-if="/\.(rar|cab|arj|lzh|tar|uue|jar)(\?.*)?$/.test(transpondData.content.type)">
                        <svg class="icon-img" aria-hidden="true">
                          <use xlink:href="#icon-rar"></use>
                        </svg>
                      </template>
                      <template v-else-if="/\.(zip|7-zip|gzip|7z|z)(\?.*)?$/.test(transpondData.content.type)">
                        <svg class="icon-img zip-icon" aria-hidden="true">
                          <use xlink:href="#icon-zip"></use>
                        </svg>
                      </template>
                      <!--xmind 文件-->
                      <template v-else-if="/\.(xmind)(\?.*)?$/.test(transpondData.content.type)">
                        <svg class="icon-img xmind-icon" aria-hidden="true">
                          <use xlink:href="#icon-xmind"></use>
                        </svg>
                      </template>
                      <!--pdf 文件-->
                      <template v-else-if="/\.(pdf)(\?.*)?$/.test(transpondData.content.type)">
                        <svg class="icon-img pdf-icon" aria-hidden="true">
                          <use xlink:href="#icon-pdf"></use>
                        </svg>
                      </template>
                      <!--AI-->
                      <template v-else-if="/\.(ai)(\?.*)?$/.test(transpondData.content.type)">
                        <svg class="icon-img ai-icon" aria-hidden="true">
                          <use xlink:href="#icon-ai"></use>
                        </svg>
                      </template>
                      <!--其他文件-->
                      <template v-else>
                        <svg class="icon-img default-icon" aria-hidden="true">
                          <use xlink:href="#icon-default"></use>
                        </svg>
                      </template>
                      <!--信息-->
                      <div class="head-info">
                        <p class="info-p">{{transpondData.content.name}}</p>
                        <p class="info-p">{{transpondData.content.size | getFileSize}}</p>
                      </div>
                    </div>
                    <!--来自哪里-->
                    <div class="cont-foot">
                      <p>来自{{fileFrom}}/{{transpondData.from_name}}</p>
                    </div>
                  </div>
                </div>
              </template>
              <div class="shuttle-item__selected-num">
                转发给以下联系人：{{ alreadySelectedUser.length }}/10
              </div>
              <div class="shuttle-item__list">
                <SmScroll :listenData="alreadySelectedUser">
                  <ul class="sub-shuttle__menu">
                    <li class="sub-menu__item tran"
                        v-for="(sItem,sIndex) in alreadySelectedUser"
                        :key="sIndex">
                      <img :src="sItem.avatar" :alt="sItem.name" class="member-avatar">
                      <p class="member-name">
                        <span>{{sItem.name}}</span>
                      </p>
                      <i class="remove-select-icon iconfont icon-group-delete" @click="removeSelectUser(sItem.uid)">
                      </i>
                    </li>
                  </ul>
                </SmScroll>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="creat-group__foot">
        <el-button type="default" class="create-step__button" @click="handleSubmit">确定</el-button>
        <el-button type="default" class="create-step__button" @click="handleClose">取消</el-button>
      </div>
    </div>
  </div>
</template>

<script>
  import _ from 'lodash'
  import {mapGetters, mapActions} from 'vuex'
  import {getUserList, getGroupList, getRecentChatList, getGroupUserGroupList} from '@/api/user'

  export default {
    name: "HtChatTranspondPop",
    props: {
      defaultSelectedUids: {
        type: Array,
        default: [],
        required: false
      },
      show:{
        type:Boolean,
        default:false
      }
    },
    data() {
      return {
        searchSelectIndex: 0,
        filterWords: '',
        selectedUserId: '',
        outerList: [
          {
            part_id: 0,
            name: '群组',
            opened: false,
            type: 'groupes'
          },
          {
            part_id: 1,
            name: '组织架构',
            opened: false,
            type: 'organization'
          },
          {
            part_id: 2,
            name: '最近聊天',
            opened: false,
            type: 'recentChat'
          }
        ],// 外层分类列表
        users: [],// 所有员工列表
        groups: [],// 组织架构列表
        ownGroupList: [],// 群组列表
        recentChatList: [], // 最近聊天列表
        filter: '',
        selectIndex: 0
      }
    },
    computed: {
      ...mapGetters([
        'staff',
        'transpondData'
      ]),
      // 所有群组与群组成员列表
      fullGroupsList() {
        let fullGroups = this.groups
        fullGroups.forEach((gItem) => {
          gItem.userList = []
          this.users.forEach((uItem) => {
            // 所有员工列表
            if (gItem.part_id === 0) {
              gItem.userList.push(uItem)
            } else {
              // 指定的分组列表
              let pos = _.findIndex(uItem.part_full, (o) => {
                return o === gItem.part_id
              });
              if (pos !== -1) {
                gItem.userList.push(uItem)
              }
            }
          });
        })
        return fullGroups;
      },
      // 已选择的员工列表
      alreadySelectedUser() {
        let arrUser = [];
        let arrGroup = [];
        let recChat = []
        let arr = []
        // 个人
        this.users.forEach((user) => {
          if (user.selected)
            arrUser.push({
              uid: user.uid,
              name: user.full_name,
              avatar: user.avatar,
              from: 'users'
            })
        });
        // 群组
        this.ownGroupList.forEach((list) => {
          if (list.selected)
            arrGroup.push({
              uid: list.id,
              name: list.group_name,
              avatar: list.avatar,
              from: "groups"
            })
        })
        // 最近聊天
        this.recentChatList.forEach((item) => {
          if (item.selected)
            recChat.push({
              uid: item.id,
              name: item.name,
              avatar: item.avatar,
              from: 'reChat'
            })
        })
        arr = [...arrUser, ...arrGroup, ...recChat]
        if (arr.length > 10) {
          arr = arr.slice(0, 10)
        }
        return arr
      },
      // 搜索结果列表
      searchFilterResult() {
        let arrUser = [];
        let arrGroup = [];
        let arr = []
        if (!this.filterWords) return arr
        // 个人
        this.users.forEach((user) => {
          if (user.full_name.indexOf(this.filterWords) != -1)
            arrUser.push({
              uid: user.uid,
              name: user.full_name,
              avatar: user.avatar
            })
        });
        // 群组
        this.ownGroupList.forEach((list) => {
          if (list.group_name.indexOf(this.filterWords) != -1)
            arrGroup.push({
              uid: list.id,
              name: list.group_name,
              avatar: list.avatar
            })
        });
        arr = [...arrUser, ...arrGroup]
        return arr
      },
      // 文件来自哪里
      fileFrom() {
        return this.transpondData.relationship.indexOf('G') != -1 ? '群' : '个人'
      },

    },
    watch: {
      filterWords(val) {
        if (!val) this.searchSelectIndex = 0;
      },
      show(val){
        if(val){
          // 个人
          this.users.forEach(item => {
            item.selected = _.indexOf(this.defaultSelectedUids, item.uid) != -1
          })
          // 群组
          this.ownGroupList.forEach((item) => {
            item.selected = _.indexOf(this.defaultSelectedUids, item.uid) != -1
          });
          this.fetchUserAndGroupData()
        }
      }
    },
    mounted() {
      this.fetchUserAndGroupData()
    },
    methods: {
      ...mapActions([
        'getGroupList',
        'sendChatMessage',
        'getTransPondData'
      ]),
      // 获取数据
      fetchUserAndGroupData() {
        Promise.all([getUserList(), getGroupList(), getGroupUserGroupList(), getRecentChatList()])
          .then(result => {
            // 人员列表
            let response = result[0]
            let data = response.data
            let users = []
            let index = data.findIndex((v) => {
              return v.uid === this.staff.uid
            })
            data.splice(index, 1)
            data.forEach(item => {
              let bool = _.indexOf(this.defaultSelectedUids, item.uid) != -1
              users.push({...item, selected: bool})
            });
            this.users = users;

            // getGroupList 组织架构列表
            response = result[1]
            data = response.data
            let groups = []
            data.forEach(item => {
              groups.push({
                part_id: item.id,
                name: item.name,
                opened: false
              })
            });
            this.groups = groups

            // 个人群组列表
            response = result[2]
            data = response.data
            let list = []
            data.forEach(item => {
              let bool = _.indexOf(this.defaultSelectedUids, item.uid) != -1
              list.push({...item, selected: bool})
            });
            this.ownGroupList = list


            // 最近聊天列表
            response = result[3]
            data = response.data
            let recentChatList = []
            data.forEach(item => {
              let bool = _.indexOf(this.defaultSelectedUids, item.uid) != -1
              recentChatList.push({...item, selected: bool})
            });
            this.recentChatList = recentChatList
          })
          .catch((err) => {
            console.log(err)
          })
      },
      // 组织架构打开关闭
      orgOpen(part_id) {
        let group = _.find(this.groups, function (o) {
          return o.part_id == part_id
        })
        group.opened = !group.opened
      },
      // 外层的关闭打开切换
      outerOpen(part_id) {
        let outerItem = _.find(this.outerList, function (o) {
          return o.part_id === part_id
        })
        outerItem.opened = !outerItem.opened
      },
      // 选择员工
      selectUser(uid) {
        let user = _.find(this.users, function (o) {
          return o.uid === uid
        })
        if (this.alreadySelectedUser.length >= 10 && user.selected == false) {
          this.$message.error('最多转发10人')
          if (user.selected) {
            user.selected = false
          }
          return
        } else {
          user.selected = !user.selected;
        }
      },
      // 选择群组
      selectOwnGroupList(uid) {
        let list = _.find(this.ownGroupList, function (o) {
          return o.id === uid
        })
        if (this.alreadySelectedUser.length >= 10 && list.selected === false) {
          this.$message.error('最多转发10人')
          if (list.selected) {
            list.selected = false
          }
          return
        } else {
          list.selected = !list.selected;
        }
      },
      // 选择最近聊天
      selectRenceChat(uid) {
        if (uid.length > 5) {
          this.selectOwnGroupList(uid)
        } else {
          this.selectUser(uid)
        }
      },
      // 取消选中
      removeSelectUser(uid) {
        let currentItem = this.alreadySelectedUser.find((v) => {
          return v.uid === uid
        })
        if (currentItem.from === 'reChat') {
          this.selectRenceChat(uid)
        } else if (currentItem.from === 'groups') {
          this.selectOwnGroupList(uid)
        } else if (currentItem.from === 'users') {
          this.selectUser(uid)
        }
      },
      // 搜索结果键盘选择
      // 向下选择
      resultSelectDown() {
        if (!this.filterWords) return;
        this.searchSelectIndex++;
        if (this.searchSelectIndex === this.searchFilterResult.length) {
          this.searchSelectIndex = 0;
        }
        this.resultSelectSrcoll(this.searchSelectIndex);
      },
      // 向上选择
      resultSelectUp() {
        if (!this.filterWords) return;
        this.searchSelectIndex--;
        if (this.searchSelectIndex === -1) {
          this.searchSelectIndex = this.searchFilterResult.length - 1;
        }
        this.resultSelectSrcoll(this.searchSelectIndex);
      },
      // 搜索键盘控制滚动
      resultSelectSrcoll(index) {
        let yPos = parseInt(this.$refs.searchResultLi[index].offsetTop -
          this.$refs.searchResultScroll.getSize.container.height + 30)
        this.$refs.searchResultScroll.scrollTo(0, yPos, 300)
      },
      // 搜索选中
      resultSelectEnter() {
        let uid = this.searchFilterResult[this.searchSelectIndex].uid;
        this.selectFilterUser(uid)
        this.searchSelectIndex = 0;
      },
      // 搜索结果选择
      handleSelectUser(uid) {
        if (uid.length > 5) {
          this.selectOwnGroupList(uid)
        } else {
          this.selectUser(uid)
        }
        this.$nextTick(() => {
          this.filterWords = ''
        })
      },
      selectFilterUser(uid) {
        this.handleSelectUser(uid);
        this.$nextTick(() => {
          this.filterWords = ''
        })
      },
      // 点击确定提交
      handleSubmit() {
        if (!this.alreadySelectedUser.length) {
          this.$message.error('请选择转发对象后发送')
          return false
        }
        let uids = []
        this.alreadySelectedUser.forEach(item => {
          uids.push(item.uid)
        });
        let data = {}
        // 文件
        if(this.transpondData.objectName === 'RC:FileMsg'){
          data.content = this.transpondData.content
          data.type = this.transpondData.type
          data.sentStatus = this.transpondData.sentStatus
          data.objectName = this.transpondData.objectName
        }


        if(this.transpondData.objectName === 'RC:ImgTextMsg'){
          data.content = this.transpondData.content
          data.type = this.transpondData.type
          data.sentStatus = this.transpondData.sentStatus
          data.objectName = this.transpondData.objectName
        }

        uids.map((item) => {
          data.uid = item
          this.sendChatMessage(data)
        })
        this.handleClose()
      },
      // 关闭
      handleClose() {
        this.$emit('handleClose');
        this.users = []; // 所有员工列表
        this.groups = []; // 组织架构列表
        this.ownGroupList = []; // 群组列表
        this.recentChatList = []; // 最近聊天列表
        this.getTransPondData({})
        this.outerList.forEach((item) => {
          item.opened = false
        })
        this.groups.forEach((item) => {
          item.opened = false
        })
      }
    }
  }
</script>

<style scoped>

</style>
