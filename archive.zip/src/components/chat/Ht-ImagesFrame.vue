<template>
    <div class="section-work-space">
        <div class="chat-images-space" v-loading="loading">
            <div class="images-list-cont">
                <div class="images-space__block"
                     v-for="item in this.imageList"
                     :key="item.name">
                    <!-- 时间标题-->
                    <div class="block-time-title">
                        <i class="iconfont icon-groupchat-pic-date"></i>
                        <span class="title-span">{{item.name}}</span>
                    </div>
                    <!--图片列表 -->
                    <div class="block-images-list">
                        <ul>
                            <li class="img-item" v-for="list in item.list" :key="list.id"
                                @dblclick="showBigImg(list.content.content)"
                                @contextmenu.prevent="contextMenu(list.content.content)"
                                @click="selectImg(list.id)">
                                <div class="img-item__show"
                                     v-lazy:background-image="list.content.content"
                                     :class="{'active':activeIndex === list.id}"
                                     title="双击查看大图"
                                     style="background-size: cover;background-position: center;"></div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div v-show="total <=0" style="text-align: center;padding: 40px;color: #338eff;font-size:16px;">
                    暂无图片，快去聊天吧~
                </div>
            </div>
            <!--分页-->
            <div class="page-list" v-if="total > 0">
                <el-pagination
                        small
                        layout="prev, pager, next"
                        :page-size="20"
                        :total="total"
                        :current-page.sync="currentPage">
                </el-pagination>
            </div>
        </div>
    </div>
</template>

<script>
    import moment from 'moment'
    import {mapGetters} from 'vuex'
    import {getMessageByType} from '@/api/chat'
    import {parseJson} from '@/utils/utils'

    export default {
        name: "HtImagesFrame",
        data() {
            return {
                imageList: {},
                currentPage: 1,
                total: 0,
                activeIndex: 0,
                loading: true
            }
        },
        watch: {
            'currentPage': 'fetchImageData'
        },
        computed: {
            ...mapGetters([
                'currentChatId',
                'currentConversationType',
                'currentConversationRelationship',
                'isInClient'
            ])
        },
        created() {
            this.fetchImageData();
        },
        methods: {
            fetchImageData() {
              getMessageByType(this.currentConversationRelationship, 1, this.currentPage)
                .then(res => {
                  if (res.status === 200) {
                    this.loading = false
                    let data = res.data.list
                    data.forEach((item) => {
                      item.content = JSON.parse(item.content)
                    })
                    this.total = parseInt(res.data.count)
                    this.imageList = this._transformChatList(data)
                  }
                })
            },
            // 转换数据格式，以时间为key值
            _transformChatList(list) {
                if (list.length <= 0) return {}
                let chatList = {}
                list.forEach(item => {
                    let day = moment.unix(item.timeline).format('Y-MM-DD');
                    if (!chatList[day]) {
                        chatList[day] = {
                            name: day,
                            list: []
                        }
                    }
                    chatList[day].list.push(item)
                })
                return chatList
            },
            // 选中图片
            selectImg(id) {
                this.activeIndex = id
            },
            // 查看大图
            showBigImg(src) {
                let data = {
                    url: src,
                    uuid: '1111',
                    data: []
                }
              if(this.isInClient){
                data = JSON.stringify(data)
                window.hanClient.showImage(data)
              } else {
                window.openURL(data.url)
              }
            },
          //会话消息右键菜单
          contextMenu(src) {
            window.hanClient.runChatMenu({
              menu: 'image_copy,image_saveas',
              data:src,
            })
          },
        }
    }
</script>

<style scoped>

</style>
