<template>
  <div class="section-work-space">
    <div class="chat-files-space" v-loading="loading">
      <div class="files-handle-bar">
        <div class="files-name">
          共{{getFileNumber}}个文件
        </div>
        <div class="files-btns" style="display: none">
          <el-button type="primary" class="upload-btn" @click="upload()">上传</el-button>
          <input type="file" @change="uploadFiles($event)" ref="fileUploadRef" hidden/>
        </div>
      </div>
      <!--文件列表-->
      <div class="files-list-table">
        <!--表格头部-->
        <template v-if="getFileNumber > 0 ">
          <div class="handle-table-header">
            <div class="header-title">
              <div class="title-box file-name-box">文件</div>
              <div class="title-box file-time-box">更新时间</div>
              <div class="title-box file-size-box">大小</div>
              <div class="title-box file-user-box">上传者</div>
              <div class="title-box file-num-box" style="text-align: center;">转发</div>
              <div class="title-box file-hand-box" style="text-align: center;">下载</div>
            </div>
          </div>
          <!--表格内容部分-->
          <div class="handle-table-body">

            <SmScroll :listenData="listedFiles">
              <ul class="file-detail-list">
                <li class="tran detail-item" v-for="item in listedFiles" :key="item.id"
                    v-if="(item.currentChatId == currentChatId || item.from_id)">
                  <div class="item-box file-name-box">
                    <div class="box-scope">
                      <!--文件图标 分类-->
                      <!--PSD 文件-->
                      <template v-if="/(\/|\.)(psd)(\?.*)?$/.test(item.content.type)">
                        <svg class="img-svg-icon psd-icon" aria-hidden="true">
                          <use xlink:href="#icon-psd"></use>
                        </svg>
                      </template>
                      <!--word 文件-->
                      <template v-else-if="/(\/|\.)(doc|docx)(\?.*)?$/.test(item.content.type)">
                        <svg class="img-svg-icon word-icon" aria-hidden="true">
                          <use xlink:href="#icon-word"></use>
                        </svg>
                      </template>
                      <!--Excel 文件--->
                      <template
                        v-else-if="/(\/|\.)(xlsx|xls|xlsm|xlt|xltx|xltm)(\?.*)?$/.test(item.content.type)">
                        <svg class="img-svg-icon excel-icon" aria-hidden="true">
                          <use xlink:href="#icon-excel"></use>
                        </svg>
                      </template>
                      <!--txt 文件-->
                      <template v-else-if="/(\/|\.)(txt)(\?.*)?$/.test(item.content.type)">
                        <svg class="img-svg-icon txt-icon" aria-hidden="true">
                          <use xlink:href="#icon-txt"></use>
                        </svg>
                      </template>
                      <!--PPT 文件-->
                      <template v-else-if="/(\/|\.)(ppt|pptx)(\?.*)?$/.test(item.content.type)">
                        <svg class="img-svg-icon ppt-icon" aria-hidden="true">
                          <use xlink:href="#icon-ppt"></use>
                        </svg>
                      </template>
                      <!--图片 文件-->
                      <template
                        v-else-if="/(\/|\.)(png|jpe?g|gif|svg)(\?.*)?$/.test(item.content.type)">
                        <svg class="img-svg-icon" aria-hidden="true">
                          <use xlink:href="#icon-tupian"></use>
                        </svg>
                      </template>
                      <!--压缩包 文件-->
                      <template
                        v-else-if="/(\/|\.)(rar|cab|arj|lzh|tar|uue|jar)(\?.*)?$/.test(item.content.type)">
                        <svg class="img-svg-icon" aria-hidden="true">
                          <use xlink:href="#icon-rar"></use>
                        </svg>
                      </template>
                      <template
                        v-else-if="/(\/|\.)(zip|7-zip|gzip|7z|z)(\?.*)?$/.test(item.content.type)">
                        <svg class="img-svg-icon zip-icon" aria-hidden="true">
                          <use xlink:href="#icon-zip"></use>
                        </svg>
                      </template>
                      <!--xmind 文件-->
                      <template v-else-if="/(\/|\.)(xmind)(\?.*)?$/.test(item.content.type)">
                        <svg class="img-svg-icon xmind-icon" aria-hidden="true">
                          <use xlink:href="#icon-xmind"></use>
                        </svg>
                      </template>
                      <!--pdf 文件-->
                      <template v-else-if="/(\/|\.)(pdf)(\?.*)?$/.test(item.content.type)">
                        <svg class="img-svg-icon pdf-icon" aria-hidden="true">
                          <use xlink:href="#icon-pdf"></use>
                        </svg>
                      </template>
                      <!--AI-->
                      <template v-else-if="/(\/|\.)(ai)(\?.*)?$/.test(item.content.type)">
                        <svg class="img-svg-icon ai-icon" aria-hidden="true">
                          <use xlink:href="#icon-ai"></use>
                        </svg>
                      </template>
                      <!--其他文件-->
                      <template v-else>
                        <svg class="img-svg-icon default-icon" aria-hidden="true">
                          <use xlink:href="#icon-default"></use>
                        </svg>
                      </template>

                      <span class="file-name">{{ item.content.name }}</span>
                    </div>
                  </div>
                  <div class="item-box file-time-box">
                    <div class="box-scope">
                      <span v-if="(item.process == 100 || item.from_id) && item.time"> {{ item.time | formatDate }}</span>
                      <span v-if="(item.process == 100 || item.from_id) && item.timeline"> {{ item.timeline | unixDateFormat('YYYY-MM-DD h:mm') }}</span>
                      <template v-if="item.process != 100 && !item.from_id">
                        <span>上传进度</span>
                        <div class="upload-progress"
                             style="width: 100%;">
                          <el-progress :percentage="item.process"
                                       :stroke-width="3"
                                       :show-text="true"/>
                        </div>
                      </template>
                    </div>
                  </div>
                  <div class="item-box file-size-box">
                    <div class="box-scope">
                      {{ item.content.size | getFileSize}}
                    </div>
                  </div>
                  <div class="item-box file-user-box">
                    <div class="box-scope">
                      {{ item.full_name }}
                    </div>
                  </div>
                  <div class="item-box file-num-box">
                    <!--<div class="box-scope">-->
                    <!--{{ item.downNum }}次-->
                    <!--</div>-->
                    <!--转发-->
                    <div class="down-handle">
                        <span class="handle-span" @click="fileTransPond(item)">
                        <i class="iconfont icon-file-transmit"></i>
                       </span>
                    </div>
                  </div>
                  <div class="item-box file-hand-box">
                    <div class="box-scope">
                      <div class="down-handle">
                          <!--下载-->
                        <span class="handle-span" v-if="item.type === 'noDown'" @click="downloadFrameFile(item)">
                         <i class="iconfont icon-file-download"></i>
                       </span>
                        <el-button v-if="item.type === 'downloading'" type="text" class="btns-fileData" disabled>下载中...</el-button>
                        <template  v-if="item.type === 'downloaded'">
                          <el-button type="text" class="btns-fileData" @click="openFile">打开</el-button>
                          <el-button type="text" class="btns-fileData" @click="openDir">打开文件夹</el-button>
                        </template>

                      </div>
                      <!--下载进度-->
                      <!--<div class="down-progress" style="width: 30px;height: 30px;"-->
                      <!--v-if="item.type!=='downloaded'">-->
                      <!--<el-progress type="circle" :percentage="25" :width="30"-->
                      <!--:stroke-width="3"></el-progress>-->
                      <!--</div>-->
                    </div>
                  </div>
                </li>
              </ul>
            </SmScroll>

            <!--分页-->
            <div class="page-list" v-if="total > 0">
              <el-pagination
                small
                layout="prev, pager, next"
                :page-size="20"
                :total="total"
                :current-page.sync="currentPage"/>
            </div>

          </div>
        </template>

        <div v-else style="text-align: center;padding: 40px;color: #338eff;font-size:16px;">
          暂无文件~
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import {mapActions, mapGetters} from 'vuex'
  import {genMsgUId, uploadItem,unescapeHTML} from '@/utils/utils';
  import {getUploadImgToken} from '@/api/upload'
  import {getGroupMsg, getUserMsg,getMessageByType} from '@/api/chat'
  export default {
    name: "HtFilesFrame",
    data() {
      return {
        filesList: [],
        uploadIndex: 0,
        temp: [],
        loading: true,
        currentPage: 1,
        total: 0,
        isDownloaded:false,
        isDownloading:false,
        downloadUrl:'',
        fileIndex:0,
        listedFiles:[],
        getFileNumber:0
      }
    },
    created() {
    },
    watch: {
      'currentPage': 'fetchFileData'
    },
    computed: {
      ...mapGetters([
        'fileUploadMq',
        'staff',
        'currentChatId',
        'currentConversationRelationship',
        'currentConversationType',
        'currentChatUserOnlineType',
        'currentChatName',
        'isInClient'
      ]),
      showFileList() {
        let dataList = this.fileUploadMq.slice();
        return this._.orderBy(this.temp.concat(dataList), ['timeline', 'time', 'size'], ['desc', 'desc'])
      },
    },
    mounted() {
      this.fetchFileData();
    },
    methods: {
      ...mapActions([
        'setFileUploadMg',
        'getTransPondData',
        'setTransPondShowToggle'
      ]),
      fetchFileData() {
        getMessageByType(this.currentConversationRelationship, 2, this.currentPage)
          .then(res=>{
            if(res.status === 200){
              this.loading = false;
              let data = res.data.list
              data.forEach((item) => {
                item.content = JSON.parse(item.content)
                item.type = 'noDown'
              })
              this.listedFiles = data
              this.total = this.getFileNumber = parseInt(res.data.count);
            }
          })
          .catch(err=>{console.log(err)})
      },
      upload() {
        let file = this.$refs.fileUploadRef
        file.click()
      },
      uploadFiles(e) {
        var that = this;
        let file = e.target.files[0];
        let uuid = genMsgUId();
        if (!file) {
          return;
        } else {
          let dataContent = {};
          dataContent.content = {};
          dataContent.content.name = file.name;
          dataContent.content.size = file.size;
          dataContent.content.type = file.type;
          dataContent.time = new Date().getTime();
          dataContent.from_name = that.staff.full_name;
          dataContent.downNum = 0;
          dataContent.uploadFlag = false;
          dataContent.currentChatId = that.currentChatId;
          dataContent.uuid = uuid;
          let dataList = that.fileUploadMq.slice();
          dataList.push(dataContent);
          that.setFileUploadMg(dataList);
          that.filesList.push(dataContent);
          (function (uuid) {
            getUploadImgToken().then(response => {
              if (response.status == 200) {
                let config = {
                  name: 'file',  // 图片参数名
                  size: 12,  // 可选参数 图片大小，单位为M，1M = 1024kb
                  action: 'http://upload.qiniu.com',  // 服务器地址,
                };
                let data = response.data;
                config.token = data.upToken;
                uploadItem(file, config, uuid, {
                  success(data) {
                    that.setFileUploadMg({self: that, index: uuid, val: false, 'complete': 100});
                    that.fetchFileData();
                  },
                  error(e) {
                    that.$message.error('文件上传失败！');
                  },
                  start(e) {

                  },
                  progress(complete, e) {
                    if (!dataList.uploadFlag) {
                      that.setFileUploadMg({self: that, 'index': uuid, 'val': true, 'complete': complete});

                    } else {
                      that.setFileUploadMg({self: that, 'index': uuid, val: false, 'complete': complete});
                    }
                  },
                  change(xhr, formData) {

                  },
                  end(e) {

                  }
                })
              }

            })
          })(uuid)
        }
      },
      // 打开文件夹
      openDir() {
        let url =this.downloadUrl
        window.hanClient.openFileFloder('floder', url)
      },
      // 打开文件
      openFile() {
        let url =this.downloadUrl
        window.hanClient.openFileFloder('file', url);
      },
      // 下载文件
      downloadFrameFile(item){
        if(!item.content.content){
          this.$message.error('文件已损坏，无法下载')
          return
        }
        let _this = this
        _this.$set(item,'type', 'downloading')
        if (this.isInClient) {
          window.hanClient.downloadFile({
            strUrl: item.content.content,
            strFileName: item.content.name,
            strDownloadType: "1",
            onSuccess: function (response) {
              _this.$message.success('文件已保存');
              _this.$set(item,'type', 'downloaded')
              _this.downloadUrl = response
              // let payload = {
              //   message_id: item.id,
              //   relationshipId: item.relationship,
              //   key, response
              // }
              // _this.openConversationFile(payload)
            },
            onFailure: function (error_code, error_message) {
              if (error_code == 1) {
                _this.$set(item,'type', 'noDown')
                // let data = {
                //   message_id: item.id,
                //   relationshipId: item.relationship,
                //   key
                // }
                // _this.resetConversationFile(data)
              } else {
                _this.$message.error(error_message);
              }

            },
          })
        } else {
          window.hanClient.downloadFile({
            strUrl: item.content.content,
            strFileName: item.content.name,
            strDownloadType: "1",
          })
        }
      },

      // 转发
      fileTransPond(item){
        if(!item.content.content ){
          this.$message.error('文件已损坏，无法转发')
          return
        }
        let data = {
          content:item,
          relationship:item.relationship,
          fromPath:'fileFrame',
          type:4
        };
        this.getTransPondData(data)
        this.setTransPondShowToggle(true)
      }
    }
  }

</script>

<style scoped>

</style>
