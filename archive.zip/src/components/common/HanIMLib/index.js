/*
// 初始化配置
HanIMLib.HanIMClient.init()

// 获取实例对象
let instance = HanIMClient.getInstance()

// 设置连接状态监听
HanIMClient.setConnectionStatusListener({onChanged() {}})

// 设置接收消息监听
HanIMClient.setOnReceiveMessageListener({onReceived() {}})

// 开始连接
HanIMClient.connect(token, {
  onSuccess(userId) {
    callbacks.getCurrentUser && callbacks.getCurrentUser({userId:userId});
    console.log("链接成功，用户id：" + userId);
  }
})
*/
import {genMsgUId} from '@/utils/utils'
import StropheUtils from '../StropheUtils'

let HanIMLib = {
  // 会话类型属性
  ConversationType: {
    PRIVATE: 1, // 单聊
    DISCUSSION: 2, // 讨论组
    GROUP: 3, // 群组
    CHATROOM: 4, // 聊天室
    CUSTOMER_SERVICE: 5, // 客服
    SYSTEM: 6, // 系统消息
    APP_PUBLIC_SERVICE: 7, // 应用公众账号（应用内私有）
    PUBLIC_SERVICE: 8, // 为公众账号 (公有)
  }
}

let HanIMClient = {

  // 初始化参数
  init(options) {
    //接收用户自定义参数
    for (let property in options) {
      StropheUtils.status[property] = options[property];
    }
  },
  addProperty(data){
    StropheUtils.status.grouplist = data
  },
  addGroupMember(id){
    let data = {...id};
    StropheUtils.status.grouplist.push(data)
  },
  // 消息监听
  setOnReceiveMessageListener(callbacks) {
    if (typeof callbacks.onReceived === 'function') {
      StropheUtils.status.onMessage = callbacks.onReceived
    }
  },
  // 获取IM连接实例
  getInstance() {
    return StropheUtils.status.connection
  },
  getStatus(){
    return StropheUtils.status
  },
  // 获取strophe实例
  getStropheInstance(){
    return StropheUtils
  },
  // 连接IM服务
  connect(uid, password, callbacks) {
    let uuid = 'pc-'+genMsgUId();
    let jid = `${uid}@${StropheUtils.status.APP_SERVICE}/${uuid}`;
    StropheUtils.login(jid, password, callbacks.onSuccess)
  },
  // 发送消息
  sendMessage(conversationType, targetId, msg, callbacks) {
     switch (conversationType) {
       case 1:
         let toJid = `${targetId}@${StropheUtils.status.APP_SERVICE}/spark`
         StropheUtils.sendSingeChat(toJid, msg);

         break;
       case 3:
         let toRJid = `${targetId}@conference.${StropheUtils.status.APP_SERVICE}`
         StropheUtils.sendMultChat(toRJid, msg);

         break;
     }
  },
  joinRoom(rid){
    return StropheUtils.joinRoom(rid)
  },
  sendMultChat(rid,msg){
    return HanIMClient.sendMessage(HanIMLib.ConversationType.GROUP, rid, msg, {})
  }
}

HanIMLib.HanIMClient = HanIMClient

export default {
  install: function (Vue, options) {
    // 接收用户自定义参数
    HanIMLib.HanIMClient.init(options);

    // 全局插件入口
    Vue.prototype.$HanIMLib = HanIMLib
    Vue.prototype.$HanIMClient = HanIMLib.HanIMClient
    window.HanIMLib = HanIMLib;
    window.HanIMClient = HanIMLib.HanIMClient
  }
};

