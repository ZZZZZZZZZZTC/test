/*
* 自研Vue插件
* 通过strophe.js连接openfire服务器bosh接口进行通讯
* @function login 登录
* @function joinRoom 加入群组聊天
* @function sendSingeChat 单聊
* @function sendMultChat 群聊
* @function onConnect 监听连接状态
* @function onLogin 监听登录状态
* @function onMessage 监听接收消息
 */
import {genMsgUId} from '@/utils/utils'
import strophe, {Strophe} from 'strophe.js'

var StropheUtils = {
  //插件状态变量
  status: {
    APP_SERVICE: '', // 应用服务地址
    connection: null,   //连接实例
    connected: false,   //连接状态，如果未连接状态，不允许进行服务器交互
    jid: '',            //当前连接jid
    debug: true,        //是否debug
    onMessage(msg) {}, // 接收消息回调
    connnectCount:0
  },
  /*
  * 私有方法，输出打印控制台信息
  * @param msg 控制台输出内容
   */
  log: function (msg) {
    //如果开发模式，则控制台输出
    if(this.status.debug)
    {
      console.log(msg);
    }
  },
  /*
  * 被动与服务器交互后，返回数据
  * @param data 返回相应数据
   */
  rawInput: function (msg) {
    var self = StropheUtils;
    self.log('RECV: ' + msg);
    // self.onMessage(msg)
  },
  /*
  * 主动与服务器交互后，返回数据
  * @param data 返回相应数据
   */
  rawOutput: function (data) {
    var self = StropheUtils;
    self.log('SENT: ' + data);
  },
  /*
  * 监听连接状态
  * 作出对应相应事件处理
  * 修改connected值
  * @param connStatus 连接状态
   */
  onConnect: function (connStatus) {
    var self = StropheUtils;
    if (connStatus == Strophe.Status.CONNECTING) {
      // console.log('连接中...')
    } else if (connStatus == Strophe.Status.DISCONNECTING) {
      // console.log('断开连接中...')
    } else if (connStatus == Strophe.Status.CONNFAIL) {
      // console.log("连接失败！")
      if(self.status.connnectCount>5){
        return
      }
      self.status.restart = true
      self.login(self.status.username, self.status.password, self.onConnect);
    } else if (connStatus == Strophe.Status.AUTHFAIL) {
      // console.log("登录失败！")
      if(self.status.connnectCount>5){
        return
      }
      self.status.restart = true
      self.login(self.status.username, self.status.password, self.onConnect);
    } else if (connStatus == Strophe.Status.DISCONNECTED) {
      // console.log("连接断开！");
      //修改connected值为false
      self.status.connected = false;
      if(self.status.connnectCount>5){
        return
      }
      self.status.restart = true
      self.login(self.status.username, self.status.password, self.onConnect);
    } else if (connStatus == Strophe.Status.CONNECTED) {
      // console.log("连接成功，可以开始聊天了！");
      //修改connected值为true
      self.status.connected = true;
      //执行登录成功响应事件
      if(self.status.restart){
        for(let i=0;i<self.status.grouplist.length;i++){
          HanIMClient.joinRoom(self.status.grouplist[i].id)
        }
      }
      self.onLogin();
      // self.joinRoom()

      // let refreshConnect = function () {
      //   console.log('234124233333')
      //   self.status.connected = false;
      //   self.login(self.status.username, self.status.password, self.onConnect);
      //   console.log(self.login)
      // }
      //
      // setTimeout(refreshConnect,65*1000)
    }
  },
  /*
  * 监听登录状态
  * 登录成功后，事务系列响应事件
   */
  onLogin: function () {
    var self = StropheUtils;
    //相应用户定义登录回调事件
    self.status.onLoginSucess();

    // 当接收到<message>节，调用onMessage回调函数
    self.status.connection.addHandler(self.onMessage, null, 'message', null, null, null);
    // let temp =  self.status.connection.addHandler(self.onMessage, null, 'message', null, null, null);
    // 首先要发送一个<presence>给服务器（initial presence）
    self.status.connection.send(strophe.$pres().tree());
  },
  /*
  * 监听接收消息
  * 接收单聊、群聊消息，过滤后响应用户自定义处理事件
  * 接收错误消息，群聊如果未进入聊天室则进入后并重新发送失败消息
  * @param msg 接收到的消息数据
   */
  onMessage: function (msg) { // 接收到<message>
    console.log(msg,123)
    var self = StropheUtils;
    // 解析出<message>的from、type属性，以及body子元素
    var from = msg.getAttribute('from');
    var type = msg.getAttribute('type');
    var elemsBody = msg.getElementsByTagName('body');
    var elemsError = msg.getElementsByTagName('error');
    //如果body有内容
    //忽略body没有内容的消息
    if (elemsBody.length > 0) {
      //获取消息文本
      var body = elemsBody[0];
      var bodyText = Strophe.getText(body);
      //如果室单聊或者群聊，则响应用户自定义处理事件
      if (type == "chat" || type == 'groupchat') {
        self.status.onMessage(bodyText);
      }
      //如果是错误消息
      else if (type == 'error' && elemsError.length > 0) {
        //获取错误类型
        var error = elemsError[0];
        var code = error.getAttribute('code');

        //如果错误类型是未进入聊天室
        if(code == 406)
        {
          //进入聊天室
          self.joinRoom(from);
          //补发消息
          self.sendMultChat(from, bodyText)
        }
      }
    }
    return true;
  },
  /*
  * 登录
  * 首先连接openfire服务器bosh接口
  * 连接成功后，再进行登录请求
  * @param jid 登录jid
  * @param passWord 登录密码
  * @param onSucess 登录后响应用户定义事件
   */
  login: function (uid, passWord, onSucess) {
    //判断当前是否已连接，防止重复连接
    this.status.connnectCount++;
    //判断重连次数,次数过多就终止
    if(this.status.connnectCount>5){
      return
    }
    if (!this.status.connected) {
      //与openfire服务器建立连接，并注册通讯事件
      let boshService = `http://${this.status.APP_SERVICE}:9070/http-bind/`;
      this.status.connection = new Strophe.Connection(boshService);
      this.status.connection.rawInput = this.rawInput;
      this.status.connection.rawOutput = this.rawOutput;

      // let jid = `${uid}@${this.status.APP_SERVICE}/spark`;
      //全局保存当前登录用户
      this.status.jid = uid;
      this.status.uid = uid;
      this.status.username = uid;
      this.status.password = passWord
      //全局保存登录成功，用户自定义响应事件
      this.status.onLoginSucess = onSucess;

      //调用实例发起连接请求，并监听连接状态
      this.status.connection.connect(uid, passWord, this.onConnect);
    }
  },
  connect(){
    //与openfire服务器建立连接，并注册通讯事件
    let boshService = `http://${this.status.APP_SERVICE}:9070/http-bind/`;
    this.status.connection = new Strophe.Connection(boshService);
    this.status.connection.rawInput = this.rawInput;
    this.status.connection.rawOutput = this.rawOutput;
    let uuid = genMsgUId()
    let jid = `${uid}@${this.status.APP_SERVICE}/${uuid}`;
    //全局保存当前登录用户
    this.status.jid = jid;
    //全局保存登录成功，用户自定义响应事件
    this.status.onLoginSucess = onSucess;
    //调用实例发起连接请求，并监听连接状态
    this.status.connection.connect(jid, passWord, this.onConnect);
  },
  /*
  * 加入群组聊天
  * openfire通讯固定格式
  * @param toRJid 群组聊天jid
   */
  joinRoom: function (toRJid) {
    if (this.status.connected) {
      let uid =  this.status.jid.split('@')[0];
      // 发送<presence>元素，加入房间
      let rjid = `${toRJid}@conference.${StropheUtils.status.APP_SERVICE}/${uid}`;
      let pres = strophe.$pres({
        from: this.status.jid,
        to: rjid
      }).c('x', {xmlns: 'http://jabber.org/protocol/muc'});
      //调用实例发送加入请求
      this.status.connection.send(pres.tree());
    }
  },
  /*
  * 单聊
  * openfire通讯固定格式
  * @param toJid 聊天对象jid
  * @param msg 聊天内容
   */
  sendSingeChat: function (toJid, msg) {
    if (this.status.connected) {
      // 创建一个<message>元素并发送
      var message = strophe.$msg({
        to: toJid,
        from: this.status.jid,
        type: 'chat'
      }).c("body", null, msg);

      //调用实例发送单聊消息数据
      this.status.connection.send(message.tree());
    }
  },
  /*
  * 群组聊天
  * openfire通讯固定格式
  * @param toRJid 群组聊天室jid
  * @param msg 聊天内容
   */
  sendMultChat: function (toRJid, msg) {
    if (this.status.connected) {
      // 创建一个<message>元素并发送
      var message = strophe.$msg({
        to: toRJid,
        from: this.status.jid,
        type: 'groupchat'
      }).c("body", null, msg);
      //调用实例发送群聊消息数据
      this.status.connection.send(message.tree());
    }
  }
}

export default StropheUtils


