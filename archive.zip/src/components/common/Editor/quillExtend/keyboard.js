import {Quill} from 'vue-quill-editor'
import store from '@/store'
var bindings = {
  // This will overwrite the default binding also named 'enter'
  enter: {
    key: 13,
    handler: function(range, context) {
      //alert(this.quill.uploadComplete)
      if(this.quill.uploadComplete){
         return;
      }
      if(store.getters.sendMessageWays!=='1'){
        this.quill.uploadComplete  = false;
        if (range.length > 0) {
          this.quill.scroll.deleteAt(range.index, range.length);  // So we do not trigger text-change
        }
        let lineFormats = Object.keys(context.format).reduce(function(lineFormats, format) {
          if (Parchment.query(format, Parchment.Scope.BLOCK) && !Array.isArray(context.format[format])) {
            lineFormats[format] = context.format[format];
          }
          return lineFormats;
        }, {});
        this.quill.insertText(range.index, '\n', lineFormats, Quill.sources.USER);
        // Earlier scroll.deleteAt might have messed up our selection,
        // so insertText's built in selection preservation is not reliable
        this.quill.setSelection(range.index + 1, Quill.sources.SILENT);
        this.quill.focus();
        Object.keys(context.format).forEach((name) => {
          if (lineFormats[name] != null) return;
          if (Array.isArray(context.format[name])) return;
          if (name === 'link') return;
          this.quill.format(name, context.format[name], Quill.sources.USER);
        });
      }else{
        setTimeout(function () {
          store.dispatch('changeSendStatus',true)
        },10)
      }
      return false
    }

  },

  // There is no default binding named 'custom'
  // so this will be added without overwriting anything
  custom: {
    key: 'enter',
    ctrlKey: true,
    handler: function(range, context) {
        if(this.quill.uploadComplete){
            return;
        }
      if(store.getters.sendMessageWays==='1'){
          this.quill.uploadComplete  = false;
        if (range.length > 0) {
          this.quill.scroll.deleteAt(range.index, range.length);  // So we do not trigger text-change
        }
        let lineFormats = Object.keys(context.format).reduce(function(lineFormats, format) {
          if (Parchment.query(format, Parchment.Scope.BLOCK) && !Array.isArray(context.format[format])) {
            lineFormats[format] = context.format[format];
          }
          return lineFormats;
        }, {});
        this.quill.insertText(range.index, '\n', lineFormats, Quill.sources.USER);
        // Earlier scroll.deleteAt might have messed up our selection,
        // so insertText's built in selection preservation is not reliable
        this.quill.setSelection(range.index + 1, Quill.sources.SILENT);
        this.quill.focus();
        Object.keys(context.format).forEach((name) => {
          if (lineFormats[name] != null) return;
          if (Array.isArray(context.format[name])) return;
          if (name === 'link') return;
          this.quill.format(name, context.format[name], Quill.sources.USER);
        });
      }else{
        setTimeout(function () {
          store.dispatch('changeSendStatus',true)
        },10)
      }
    }
  },

  // list: {
  //   key: 'backspace',
  //   context: {
  //     format: ['list']
  //   },
  //   handler: function(range, context) {
  //     if (context.offset === 0) {
  //       // When backspace on the first character of a list,
  //       // remove the list instead
  //       this.quill.format('list', false, Quill.sources.USER);
  //     } else {
  //       // Otherwise propogate to Quill's default
  //       return true;
  //     }
  //   }
  // }
};

export {bindings}
