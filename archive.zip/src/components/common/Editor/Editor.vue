<template>
  <quill-editor v-model="content"
                ref="myTextEditor"
                :options="editorOption"
                @change="onChange"
                @dblclick.native="handleRichContent"
  >
    <div id="toolbar" slot="toolbar">
        <span class="ql-formats">
          <select class="ql-size">
            <option value="small"></option>
            <option selected></option>
            <option value="large"></option>
            <option value="huge"></option>
          </select>
        </span>
      <span class="ql-formats"><button type="button" class="ql-bold"></button></span>
      <span class="ql-formats"><button type="button" class="ql-italic"></button></span>
      <span class="ql-formats"><button type="button" class="ql-list" value="ordered"></button></span>
      <span class="ql-formats"><button type="button" class="ql-list" value="bullet"></button></span>
      <span class="ql-formats">
          <button type="button" class="ql-link"></button>
        </span>
      <span class="ql-formats">
          <button type="button" @click="imgClick">
            <svg viewBox="0 0 18 18">
                <rect class="ql-stroke" height="10" width="12" x="3" y="4"></rect>
                <circle class="ql-fill" cx="6" cy="7" r="1"></circle>
                <polyline class="ql-even ql-fill" points="5 12 5 11 7 9 8 10 11 7 13 9 13 12 5 12"></polyline>
            </svg>
          </button>
      </span>
    </div>
  </quill-editor>
</template>
<style>
  .quill-editor {
    box-sizing: border-box;
    height: 100%;
    padding: 0;
  }

  .ql-container {
    box-sizing: border-box;
    font-family: Helvetica, Arial, sans-serif;
    font-size: 14px;
    outline: none;
    height: 100%;
    margin: 0;
    position: relative;
    background: #FFFFFF;
  }

  .ql-editor {
    box-sizing: border-box;
    line-height: 1.42;
    height: 100%;
    outline: none;
    overflow-y: auto;
    padding: 0;
    tab-size: 4;
    -moz-tab-size: 4;
    text-align: left;
    white-space: pre-wrap;
    word-wrap: break-word;
    word-break: break-word;
  }

  .ql-editor img {
    max-width: 150px;
    max-height: 150px;
    cursor: pointer;
  }

  .ql-clipboard {
    display: none;
  }

  .ql-tooltip {
    display: none
  }

  #toolbar {
    display: none
  }
</style>
<script>
  import {getUploadFileToken} from '@/api/upload'
  import {quillEditor, Quill} from 'vue-quill-editor'
  import {container, ImageExtend, QuillWatch} from './quillExtend'
  import {bindings} from "./quillExtend/keyboard";

  Quill.register('modules/ImageExtend', ImageExtend)
  export default {
    props: {
      /*编辑器的字体大小*/
      fontsize: {
        default: 14
      },
      /*编辑器的内容*/
      value: {
        type: String
      },
      /*前缀*/
      prefix: {
        type: String,
        default: '/'
      },
      /*七牛上传凭证*/
      token: {
        type: String,
        default: ''
      },
      test: '1231',
      editorOption: {
        type: Object,
        default() {
          return {
            placeholder: '添加备注',
            theme: 'snow',
            modules: {
              toolbar: '#toolbar',
              history: {
                delay: 1000,
                maxStack: 50,
                userOnly: false
              },
              ImageExtend: {
                name: 'file',  // 图片参数名
                size: 12,  // 可选参数 图片大小，单位为M，1M = 1024kb
                action: 'http://upload.qiniu.com',  // 服务器地址, 如果action为空，则采用base64插入图片
                // response 为一个函数用来获取服务器返回的具体图片地址
                // 例如服务器返回{code: 200; data:{ url: 'baidu.com'}}
                // 则 return res.data.url
                response: (res) => {
                  return res.src + '?' + 'imageHeight=' + res.imageHeight + '#' + 'imageWidth=' + res.imageWidth
                },
                headers: (xhr) => {
                  // xhr.setRequestHeader('myHeader','myValue')
                },  // 可选参数 设置请求头部
                sizeError: () => {
                  this.$message.error('文件超过大小限制,请通过文件方式发送')
                },  // 图片超过大小的回调
                start: () => {
                },  // 可选参数 自定义开始上传触发事件
                end: () => {
                },  // 可选参数 自定义上传结束触发的事件，无论成功或者失败
                error: () => {
                  this.getToken()
                  this.$message.error('网络错误,图片上传失败,请重试')
                },  // 可选参数 上传失败触发的事件
                success: () => {
                },  // 可选参数  上传成功触发的事件
                change: (xhr, formData) => {
                  // xhr.setRequestHeader('myHeader','myValue')
                } // 可选参数 每次选择图片触发，也可用来设置头部，但比headers多了一个参数，可设置formData
              },
              keyboard: {
                bindings: bindings,
              }
            }
          }
        }
      }
    },
    data() {
      return {
        content: '',
        expires: 0,
        upToken: '',
        domain: 'http://upload.qiniu.com',
        saveKeyPrefix: ''
      }
    },
    methods: {
      onChange() {
        this.$emit('input', this.content)
      },
      /*点击上传图片按钮*/
      imgClick() {
        /*创建input file 不裁切，自己控制*/
        let input = document.createElement('input');
        input.type = 'file';
        input.name = this.fileName;
        input.accept = 'image/jpeg,image/png,image/jpg,image/gif';
        input.onchange = this.onFileChange;
        input.click();
      },
      sendError(data) {
        this.$emit('receiveError', data)
      },
      getToken() {
        let _this = this;
        let expires = _this.expires;
        let t = parseInt(new Date().getTime() / 1000)
        if (t >= expires) {
          getUploadFileToken()
            .then(response => {
              if (response.status == 200) {
                let data = response.data
                _this.domain = data.domain
                _this.expires = data.expires
                _this.saveKeyPrefix = data.saveKeyPrefix
                _this.upToken = data.upToken
              } else {
                _this.$message.error('上传Token获取失败')
              }
            })
        }
      },
      genUId() {
        let date = new Date().getTime()
        let uuid = 'xxxxxx4xxxyxxxxxxx'.replace(/[xy]/g, function (c) {
          let r = (date + Math.random() * 16) % 16 | 0;
          date = Math.floor(date / 16);
          return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16)
        })
        uuid = _this.saveKeyPrefix + uuid
        return uuid
      },
      handleRichContent(event) {
        console.log(1111)
        if (event.target.nodeName === 'IMG') {
          let url = event.target.src
          window.hanClient.showImage(url)
        }
      },
    },
    computed: {
      editor() {
        return this.$refs.myTextEditor.quill;
      },
    },
    components: {
      quillEditor
    },
    mounted() {
      this.content = this.value;
    },
    watch: {
      'value'(newVal, oldVal) {
        if (newVal !== this.content) {
          this.content = newVal
        }
      },
    }
  }
</script>


