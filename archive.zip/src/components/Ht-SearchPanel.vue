<template>
  <div class="ht-search-contacts">
    <div class="search-head statistics-main">
      <div class="search-input statistics-main" ref="searchInput">
        <input type="text" class="tran" v-model="keywords" >
        <i class="close-btn iconfont icon-deletechat"  @click.stop="close"></i>
      </div>
    </div>
    <div class="search-list">
      <!--缺省背景说明-->
      <div class="search-default" v-if="searchResultUserList.length===0&&searchResultGroupList.length===0 && conversationList.length === 0">
        <svg class="icon default-bg-icon" aria-hidden="true">
          <use xlink:href="#icon-contact-illustration"></use>
        </svg>
        <p>支持搜索联系人，群组</p>
      </div>
      <!--搜索结果列表-->
      <template v-else-if="searchResultToolList.length !== 0 || searchResultUserList.length!==0 || searchResultGroupList.length!==0">
        <SmScroll>
        <div class="list-block" v-if="searchResultToolList.length !== 0">
          <div class="list-block__title">
            工具
          </div>
          <ul class="list-block_view">
            <li class="view-item tran"
                title="双击创建会话"
                v-for="(item,index) in searchResultToolList"
                :key="item.uid"
                @dblclick.stop="createSingleChat(item)">
              <img :src="item.avatar">
              <div class="item-info">
                <p class="name">{{item.full_name}}</p>
              </div>
            </li>
          </ul>
        </div>
        <div class="list-block" v-if="searchResultUserList.length!==0">
          <div class="list-block__title">
            联系人
          </div>
          <ul class="list-block_view">
            <li class="view-item tran"
                title="双击创建会话"
                v-for="(item,index) in searchResultUserList"
                :key="item.uid"
                v-show="index<loadMoreUserCount"
                @dblclick.stop="createSingleChat(item)">
              <img :src="item.avatar">
              <div class="item-info">
                <p class="name">
                  {{item.full_name}}{{item.team_name?'-'+item.team_name:item.team_name}}{{item.job_name?'-'+item.job_name:item.job_name}}</p>
              </div>
            </li>
          </ul>
          <div class="look-more"
               v-show="searchResultUserList.length>=10&&loadMoreUserCount<=searchResultUserList.length">
            <span @click.stop.prevent="loadMoreUsers">查看更多</span>
          </div>
        </div>
        <div class="list-block" v-if="searchResultGroupList.length!==0">
          <div class="list-block__title">
            群组
          </div>
          <ul class="list-block_view">
            <li class="view-item tran" title="双击创建会话"
                v-for="(item,index) in searchResultGroupList"
                :key="item.id"
                v-show="index < loadMoreGroupCount"
                @dblclick.stop="createSingleChat(item)">
              <img :src="item.avatar">
              <div class="item-info">
                <p class="name">{{item.group_name}}</p>
              </div>
            </li>
          </ul>
          <div class="look-more"
               v-show="searchResultGroupList.length>=10 && loadMoreGroupCount<=searchResultGroupList.length">
            <span @click.stop.prevent="loadMoreGroups">查看更多</span>
          </div>
        </div>
      </SmScroll>
      </template>

      <!--搜索结果列表-->
      <template v-else="conversationList.length !==0">
        <SmScroll>
          <div class="list-block" v-if="conversationList.length!==0">
            <!--<div class="list-block__title">-->
              <!--联系人-->
            <!--</div>-->
            <ul class="list-block_view">
              <li class="view-item tran"
                  title="双击创建会话"
                  v-for="(item,index) in conversationList"
                  :key="item.uid"
                  v-show="index<loadMoreConversationCount"
                  @dblclick.stop="handleConversationChange(item)">
                <img :src="item.avatar">
                <div class="item-info">
                  <p class="name">
                    {{item.full_name}}{{item.team_name?'-'+item.team_name:item.team_name}}{{item.job_name?'-'+item.job_name:item.job_name}}</p>
                </div>
              </li>
            </ul>
            <div class="look-more"
                 v-show="conversationList.length>=10&&loadMoreConversationCount<=conversationList.length">
              <span @click.stop.prevent="loadMoreConversation">查看更多</span>
            </div>
          </div>
        </SmScroll>
      </template>

    </div>
  </div>
</template>

<script>
    import {searchUserAndGroup} from '@/api/chat'
    import {mapActions,mapGetters} from 'vuex'
    import {trim} from '@/utils/utils'
    import {checkGroupStatus} from '@/api/group'
    export default {
      name: "HtSearchPanel",
      data(){
        return{
          searchResultUserList:[],
          searchResultGroupList:[],
          searchResultToolList:[],
          keywords:'',
          loadMoreUserCount:10,
          loadMoreGroupCount:10,
          loadMoreConversationCount:10
        }
      },
      watch:{
        keywords(val){
          this.loadMoreUserCount = 10;
          this.loadMoreGroupCount = 10;
          if(trim(val)!==''){
            searchUserAndGroup(trim(val))
              .then(response=>{
                if(response.status==200){
                  let data = response.data;
                  this.searchResultUserList = data.user || [];
                  this.searchResultGroupList = data.group || [];
                  this.searchResultToolList =  []
                  let tools = {}
                  if(data.tool){
                    data.tool.forEach(item=>{
                      for(var key in item){
                        if(key == 'avatar'){
                          tools.avatar = item[key]
                        }else if(key == 'uid'){
                          tools.uid = item[key]
                        }else if(key == 'name'){
                          tools.full_name = item[key]
                        }
                      }
                    })
                    this.searchResultToolList.push(tools)
                  }
                }
              })
              .catch()
          }else{
            this.searchResultUserList = [];
            this.searchResultGroupList = [];
            this.searchResultToolList = [];
          }
        }
      },
      computed:{
      ...mapGetters([
          'conversationList'
        ]),
      },
      methods:{
        ...mapActions([
          'createNewConversation',
          'deleteConversation',
          'resetChatStore',
        ]),
        close(){
          this.$emit('close')
        },
        loadMoreUsers(){
          this.loadMoreUserCount+=10;
          if(this.loadMoreUserCount>this.searchResultUserList.length){
            this.loadMoreUserCount=(this.searchResultUserList.length)+1
          }
        },
        loadMoreGroups(){
          this.loadMoreGroupCount+=10;
          if(this.loadMoreGroupCount>this.searchResultGroupList.length){
            this.loadMoreGroupCount=(this.searchResultGroupList.length)+1
          }
        },
        createSingleChat(item){
          this.createNewConversation(item);
          this.$router.push('chat')
          this.close()
        },
        loadMoreConversation(){
          this.loadMoreConversationCount+=10;
          if(this.loadMoreConversationCount>this.conversationList.length){
            this.loadMoreConversationCount=(this.conversationList.length)+1
          }
        },
        handleConversationChange(item){
          if(item.uid>1000000){
            checkGroupStatus(item.uid)
              .then(response=>{
                if(response.status==200){
                  if(response.data.status==1){
                    this.createSingleChat(item)
                  }else{
                    this.deleteConversation(item.uid)
                    this.resetChatStore()
                    this.$message.info('该群已解散')
                  }
                }
              })
              .catch(error=>{
                console.log(error)
              })
          }else{
            this.createSingleChat(item)
          }
        },
      }
    }
</script>

<style scoped>

</style>
