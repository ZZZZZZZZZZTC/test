import Vue from 'vue'
import App from './App'
import router from './router'
import store from '@/store'
import {sync} from 'vuex-router-sync'
import VueClipboard from 'vue-clipboard2'
Vue.use(VueClipboard)
// 全局注册vue filter
import * as filters from '@/filters';
// import HanIMLib from './components/common/HanIMLib'
// 使用elementUi
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import VueLodash from 'vue-lodash'

Vue.use(VueLodash)
Vue.use(ElementUI)
// collapse 展开折叠
import CollapseTransition from 'element-ui/lib/transitions/collapse-transition';
Vue.component(CollapseTransition.name, CollapseTransition)
// 注册使用v-click-outside
import vClickOutside from 'v-click-outside'
import VueLazyload from 'vue-lazyload'
Vue.use(VueLazyload, {
  preLoad: 1.3,
  error: require('./assets/img/loadingError.png'),
  loading: require('./assets/img/imgloading.gif'),
  attempt: 1
})
Vue.use(vClickOutside)
// Vue.use(HanIMLib, {
//   APP_SERVICE: 'hantalk.hanmaker.com',
//   debug: true                                           //生产模式关闭debug，console
// });

// 引入全局css
import '@/assets/less/main.less'
import '@/assets/fonts/iconfont.css'
import '@/assets/fonts/iconfont.js'
// 引用滚动条组件
import SmScroll from '@/components/base/SmScroll/index.js'
Vue.use(SmScroll)


// 注册全局过滤器
Object.keys(filters).forEach(key => {
  Vue.filter(key, filters[key])
})

String.prototype.httpHtml = function () {
  let reg = /(http:\/\/|https:\/\/)((\w|=|\?|\.|\/|&|-|\:|\;|\+|\%|\#)+)/g
  return this.replace(reg, '<a href="javascript:;" onclick="openURL(\'$1$2\')">$1$2</a>')
};
window.openURL = function (url) {
  // shell.openExternal(url)
  window.hanClient.openExternal(url)
}
router.beforeEach((to, from, next) => {
  window.document.title = to.meta.title
  if (to.meta.requiresAuth && store.getters.isGuest)
    next('/')
  else
    next()
});

sync(store, router)



Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  render: h => h(App)
})
