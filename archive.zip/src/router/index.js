import Vue from 'vue'
import Router from 'vue-router'
Vue.use(Router)
// 路由懒加载
// 整体布局
import Layout from '@/components/Ht-Layout'
// 聊天室
import Chat from '@/views/chat/Ht-Chat'
// 通讯录
import Contact from '@/views/contact/Ht-Contact'
// 请假
import Leave from '@/views/leave/Ht-Leave'
// 请假主页
import LeaveIndex from '@/components/leave/Ht-LeaveIndex'
// 我的请假记录
import LeaveMyHistory from '@/components/leave/Ht-LeaveMyHistory'
// 请假历史
import LeaveHistory from '@/components/leave/Ht-LeaveHistory'
// 请假审核
import LeaveCheck from '@/components/leave/Ht-LeaveCheck'
// 请假小组
import LeaveGroup from '@/components/leave/Ht-LeaveGroup'
// 请假小组详情
import LeaveGroupItem from '@/components/leave/Ht-LeaveGroupItem'
// 登录
import Login from '@/views/login/Ht-Login'
// 退出
import Logout from '@/views/login/Ht-Logout'
// 云端
import Cloud from '@/views/cloud/Ht-Cloud'
// 初始化连接
import Connect from '@/views/connect/Ht-Connect'

export default new Router({
  mode: 'hash',
  linkActiveClass: "active",
  routes: [
    {
      path: '/',
      redirect: '/connect'
    },
    {
      path: '/connect',
      name: 'connect',
      component: Connect,
      meta: {
        title: '连接服务器 - 韩创科技',
        requiresAuth: false
      }
    },
    {
      path:'/logout',
      name:'logout',
      component:Logout,
      meta:{
        title: '退出 - 韩创科技',
        requiresAuth: false
      }
    },
    {
      path:'/login',
      name:'login',
      component:Login,
      meta:{
        title: '登录 - 韩创科技',
        requiresAuth: false
      }
    },
    {
      path: '/main',
      name: 'layout',
      component: Layout,
      redirect: '/main/chat',
      children:[
        {
          path: 'chat',
          name: 'chat',
          component: Chat,
          meta: {
            title: '聊天 - 韩创科技',
            requiresAuth: true,
          }
        },
        {
          path: 'contact',
          name: 'contact',
          component: Contact,
          meta: {
            title: '联系人 - 韩创科技',
            requiresAuth: true,
          }
        },
        {
          path:'leave',
          name:"leave",
          component:Leave,
          redirect: '/main/leave/index',
          meta: {
            title: '请假 - 韩创科技',
            requiresAuth: true
          },
          children:[
            {
              path: 'index',
              name: 'leaveIndex',
              component: LeaveIndex,
              meta: {
                title: '请假 - 韩创科技',
                requiresAuth: true
              }
            },
            {
              path: 'group',
              name: 'leaveGroup',
              component: LeaveGroup,
              meta: {
                title: '请假小组管理 - 韩创科技',
                requiresAuth: true
              }
            },
            {
              path: 'check',
              name: 'leaveCheck',
              component: LeaveCheck,
              meta: {
                title: '请假审核 - 韩创科技',
                requiresAuth: true
              }
            },
            {
              path: 'history',
              name: 'leaveHistory',
              component: LeaveHistory,
              meta: {
                title: '历史请假记录 - 韩创科技',
                requiresAuth: true
              }
            },
            {
              path: 'myHistory',
              name: 'leaveMyHistory',
              component: LeaveMyHistory,
              meta: {
                title: '历史请假记录 - 韩创科技',
                requiresAuth: true
              }
            },
            {
              path:'group/:id(\\d+)',
              name:'leaveGroupItem',
              component:LeaveGroupItem,
              meta:{
                title: '请假小组管理项 - 韩创科技',
                requiresAuth:true
              }
            }
          ]
        },
        // 云盘
        {
          path:'cloud',
          name:'cloud',
          component:Cloud,
          meta: {
            title: '云盘 - 韩创科技',
            requiresAuth: true
          }
        }

      ]
    },
    {
      path: '*',
      redirect: '/'
    }
  ]
})
