'use strict';
const { ipcRenderer, remote, screen } = require('electron')

console.log('background进程pid：', process.pid)