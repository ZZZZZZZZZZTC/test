// const { ipcRenderer, shell } = require('electron')

// mixins
let hanClientApiMixin = {
  methods: {
    winClose() {
      window.hanClient.close()
    },
  }
}

// 事件中心
let eventHub = new Vue()

// 通用提示组件
let General = {
  template: '#general-template',
  mixins: [hanClientApiMixin],
  data: function () {
    return {
      title: '',
      name: '',
      link: '',
      content: '',
      time: 60000
    };
  },
  methods: {
    open(link) {
      // shell.openExternal(link)
      window.hanClient.openExternal(link)
      this.winClose()
    },
    timingWinClose() {
      if (this.time <= 0) return false
      window.setTimeout(() => {
        this.winClose()
      }, this.time)
    },
    updateInfo(info) {
      console.log(info)
      this.title = info.title
      this.name = info.name
      this.link = info.link
      this.time = info.time
      this.content = info.content

      this.timingWinClose()
    }
  },
  created: function () {
    eventHub.$on('general-notify', this.updateInfo)
  }
}

// 通用提示组件
let GeneralPlus = {
  template: '#general-plus-template',
  mixins: [hanClientApiMixin],
  data: function () {
    return {
      title: '',
      name: '',
      link: '',
      content: '',
      time: 60000
    };
  },
  methods: {
    open(link) {
      // shell.openExternal(link)
      window.hanClient.openExternal(link)
      this.winClose()
    },
    timingWinClose() {
      if (this.time <= 0) return false
      window.setTimeout(() => {
        this.winClose()
      }, this.time)
    },
    updateInfo(info) {
      console.log(info)
      this.title = info.title
      this.name = info.name
      this.link = info.link
      this.time = info.time
      this.content = info.content

      this.timingWinClose()
    }
  },
  created: function () {
    eventHub.$on('general-plus-notify', this.updateInfo)
  }
}

// 图书提醒组件
let Book = {
  template: '#book-template',
  mixins: [hanClientApiMixin],
  data: function () {
    return {
      title: '',
      name: '',
      link: '',
      book_name: '',
      book_author: '',
      book_pic: '',
      book_score_percent: 0,
      time: 60000
    };
  },
  methods: {
    open(link) {
      // shell.openExternal(link)
      window.hanClient.openExternal(link)
      this.winClose()
    },
    timingWinClose() {
      if (this.time <= 0) return false
      window.setTimeout(() => {
        this.winClose()
      }, this.time)
    },
    updateInfo(info) {
      console.log(info)
      this.title = info.title
      this.name = info.name
      this.link = info.link
      this.time = info.time
      this.book_name = info.content.book_name
      this.book_author = info.content.book_author
      this.book_pic = info.content.book_pic
      this.book_score_percent = info.content.book_score_percent

      this.timingWinClose()
    }
  },
  created: function () {
    eventHub.$on('book-notify', this.updateInfo)
  }
}

// 文章提醒组件
let Article = {
  template: '#article-template',
  mixins: [hanClientApiMixin],
  data: function () {
    return {
      title: '',
      name: '',
      link: '',
      article_name: '',
      article_pic: 'images/article.jpg',
      article_summary: '',
      time: 60000
    };
  },
  methods: {
    open(link) {
      // shell.openExternal(link)
      window.hanClient.openExternal(link)
      this.winClose()
    },
    timingWinClose() {
      if (this.time <= 0) return false
      window.setTimeout(() => {
        this.winClose()
      }, this.time)
    },
    updateInfo(info) {
      console.log(info)
      this.title = info.title
      this.name = info.name
      this.link = info.link
      this.time = info.time
      this.article_name = info.content.article_name
      this.article_pic = info.content.article_pic
      this.article_summary = info.content.article_summary

      this.timingWinClose()
    }
  },
  created: function () {
    eventHub.$on('article-notify', this.updateInfo)
  }
}

// 会议提醒组件
let Activity = {
  template: '#activity-template',
  mixins: [hanClientApiMixin],
  data: function () {
    return {
      title: '',
      name: '',
      link: '',
      activity_title: '',
      activity_date: '',
      activity_local: '',
      activity_id: 0,
      time: 60000
    };
  },
  methods: {
    open(link) {
      // shell.openExternal(link)
      window.hanClient.openExternal(link)
      this.winClose()
    },
    timingWinClose() {
      if (this.time <= 0) return false
      window.setTimeout(() => {
        this.winClose()
      }, this.time)
    },
    updateInfo(info) {
      console.log(info)
      this.title = info.title
      this.name = info.name
      this.link = info.link
      this.time = info.time
      this.activity_title = info.content.activity_title
      this.activity_date = info.content.activity_date
      this.activity_local = info.content.activity_local
      this.activity_id = info.content.activity_id

      this.timingWinClose()
    },
    received(activity_id) {
      // ipcRenderer.send('received-activity', activity_id);
      this.winClose()
    }
  },
  created: function () {
    eventHub.$on('activity-notify', this.updateInfo)
  }
}

// 下班提醒组件
let Offwork = {
  template: '#offwork-template',
  mixins: [hanClientApiMixin],
  data: function () {
    return {
      title: '下班提醒',
      time: 60000
    };
  },
  methods: {
    timingWinClose() {
      if (this.time <= 0) return false
      window.setTimeout(() => {
        this.winClose()
      }, this.time)
    },
    updateInfo(info) {
      this.timingWinClose()
    },
    received(activity_id) {
      // ipcRenderer.send('received-activity', activity_id);
      this.winClose()
    }
  },
  created: function () {
    eventHub.$on('offwork-notify', this.updateInfo)
  }
}



// 生日祝福提醒
let birthday = {
  template: '#birthday-template',
  mixins: [hanClientApiMixin],
  data: function () {
    return {
      avatar: '',
      name: '',
      time: 60000
    }
  },
  methods: {
    timingWinClose() {
      if (this.time <= 0) return false
      window.setTimeout(() => {
        this.winClose()
      }, this.time)
    },
    updateInfo(info) {
      this.avatar = info.head_img
      this.name = info.full_name
      // this.timingWinClose()
    }
  },
  created: function () {
    eventHub.$on('birthday-notify', this.updateInfo)
  }
}

// vue实例
let vm = new Vue({
  el: "#app",
  data: {
    currentView: ''
  },
  components: {
    'h-general': General,
    'h-general-plus': GeneralPlus,
    'h-book': Book,
    'h-article': Article,
    'h-activity': Activity,
    'h-offwork': Offwork,
    'h-birthday': birthday
  }
})


// 渲染进程事件监听
hanClient.callbackRightPop = (arg) => {
  let notify = JSON.parse(arg)
  switch (notify.tpl_type) {
    case 1:
      vm.currentView = 'h-book'
      vm.$nextTick(function () {
        eventHub.$emit('book-notify', notify)
      })
      break;
    case 2:
      vm.currentView = 'h-article'
      vm.$nextTick(function () {
        eventHub.$emit('article-notify', notify)
      })
      break;
    case 3:
      vm.currentView = 'h-activity'
      vm.$nextTick(function () {
        eventHub.$emit('activity-notify', notify)
      })
      break;
    case 4:
      vm.currentView = 'h-offwork'
      vm.$nextTick(function () {
        eventHub.$emit('offwork-notify', notify)
      })
      break;
    case 5:
      vm.currentView = 'h-birthday'
      vm.$nextTick(function () {
        eventHub.$emit('birthday-notify', notify)
      })
      break;
    case 10:
      vm.currentView = 'h-general-plus'
      vm.$nextTick(function () {
        eventHub.$emit('general-plus-notify', notify)
      })
      break
    default:
      vm.currentView = 'h-general'
      vm.$nextTick(function () {
        eventHub.$emit('general-notify', notify)
      })
  }
}
