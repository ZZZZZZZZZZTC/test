<template>
  <div class="ht-login">

    <div class="login-left-bg">

    </div>

    <div class="login-right-fm">
      <!--操作栏-->
      <div class="form-handle__bar" v-if="isInClient && !isMac">
        <span class="icon-box min-box" @click="minimize">
          <i class="iconfont icon-minimum"></i>
        </span>
        <span class="icon-box close-box" @click="closeClient">
          <i class="iconfont icon-close"></i>
        </span>
      </div>


      <!--登录提交表单-->
      <div class="ht-login__form">
        <div class="form-log__show">
          <i class="iconfont icon-login-logo"></i>
          <span>HanTalk</span>
        </div>

        <div class="form-input__box">
          <div class="input-box__item">
            <input type="text" v-model="account.username" placeholder="请输入工号" autocomplete="on">
            <span class="icon-box">
            <i class="iconfont icon-login-id"></i>
          </span>
          </div>
          <div class="input-box__item">
            <input type="password" v-model="account.password" autocomplete="on" @keyup.enter="handleSubmit"
                   placeholder="请输入密码">
            <span class="icon-box">
            <i class="iconfont icon-login-password"></i>
          </span>
          </div>
        </div>

        <div class="from-check_hand">
          <div class="remember-password" style="display: none">
            <el-checkbox v-model="checked">七天内自动登录</el-checkbox>

          </div>

          <div class="forget-password fr" @click="findPassword">
            <span>忘记密码</span>
            <i class="iconfont icon-login-arrow"></i>
          </div>
        </div>

        <el-button class="from-login__button" type="primary" @click.prevnet="handleSubmit" :loading="doSubmit">登录
        </el-button>


        <div class="from-error_info" v-if="isError">
          <el-alert
            :title="errorTitle"
            :closable="false"
            type="error">
          </el-alert>
        </div>

      </div>
    </div>

  </div>
</template>

<script>
  import {login} from '@/api/login'
  import {mapGetters} from 'vuex'
  export default {
    name: "HtLogin",
    data() {
      return {
        account: {
          username: '',
          password: '',
        },
        doSubmit: false,
        errorInfo: '',
        checked:false,
        errorTitle:'',
        isError:false
      }
    },
    watch:{
      isError(val){
        if(val === true){
          let _this = this;
          setTimeout(()=>{
            this.isError = false
          },3000)
        }
      }
    },
    computed:{
      ...mapGetters([
        'isInClient'
      ]),
      isMac(){
        return window.hanClient.isMac
      }
    },
    methods: {
      // 登录提交
      handleSubmit() {
        if (!this.account.username || !this.account.password) {
          this.isError = true
          this.errorTitle = '账号和密码必填!'
          return false
        }
        this.doSubmit = true;

        login(this.account.username, this.account.password)
          .then(response => {
            this.doSubmit = false
            if (response.status == 200) {
              window.localStorage.setItem('hc_access_token', response.data['HC-ACCESS-TOKEN']);
              this.$router.push({path: "/"});
            } else {
              this.isError = true
              this.errorTitle = response.info

            }
          })

      },
      minimize(){
        window.hanClient.minimize()
      },
      maximize(){
        window.hanClient.maximize()
      },
      closeClient(){
        window.hanClient.close()
      },


      // 忘记密码
      findPassword() {
        window.openURL('https://hc.hanmaker.com/app_common/index.php?m=password_find&a=index')
      }
    }

  }
</script>

<style scoped>

</style>
