<template>

</template>

<script>
  import {mapActions} from 'vuex'
    export default {
        name: "Htlogout",
      mounted(){
        this.logout()
      },
      methods:{
        ...mapActions([
          'userLogout',
          'resetChatStore',
          'endAllEvent',
          'clearnConversationLocalList'
        ]),
        logout(){
          window.localStorage.removeItem('hc_access_token')
          window.localStorage.removeItem('hc_im_conversation_list')
          this.userLogout()
          this.endAllEvent()
          this.resetChatStore()
          this.clearnConversationLocalList()
          this.$router.push({path:'/'})
        }
      }
    }
</script>

<style scoped>

</style>
