<template>
  <div class="ht-content">
    <div class="cont-left-box">
      <!--请假列表-->
      <HtLeaveTabs/>
    </div>
    <!--右边主体-->
    <div class="cont-right-box">
      <router-view/>
    </div>
  </div>
</template>

<script>
  import HtLeaveTabs from '../../components/leave/Ht-LeaveTabs'
  import HtLeaveContent from '../../components/leave/Ht-LeaveIndex'
    export default {
        name: "Ht-Leave",
      components:{
        HtLeaveTabs,
        HtLeaveContent
      }
    }
</script>

<style scoped>

</style>
