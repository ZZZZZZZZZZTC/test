<template>
    <div class="ht-connect">
        <div class="connect-loading">
          <img src="../../assets/img/connect-loading.gif" alt="">
        </div>
    </div>
</template>

<script>
  import {mapActions} from 'vuex'
  import {
    getSelfInfo,
    getUserList,
    getUserConfigList,
    groupUserGroupList,
    getGroupUserGroupList
  } from '@/api/user'
  import {getStickTopChat} from '@/api/chat'
  export default {
      name: "HtConnect",
      mounted(){
        this.connectServer()
      },
      methods:{
        ...mapActions([
          'userLogin',
          'userConfig',
          'imConnect',
          'wsConnect',
          'getUserList',
          'getGroupList',
          'startRecNearLeave',
          'startRecHantalkMsg',
          'startRecNotify',
          'startRecNearActivity',
          'setConversationStickStatus',
          'startHeartBeat',
          'initShieldList',
          'initConversationList',
          'startReceiveMsg'
        ]),
        // 初始化连接
        connectServer(){
          let _this = this;
          // 获取换个人信息
          getSelfInfo()
            .catch(err=>{ console.warn(err)})
            .then(res=>{
             if(res.status === 200){
               if(res.data.isGuest){
                 this.$router.push({path: '/login'})
               }else {
                 //  初始化用户信息
                 this.userLogin(res.data);
                 this.startRecHantalkMsg(res.data);
                 this.initShieldList(res.data.groupShield);
                 this.startReceiveMsg()
                 // 获取自己加入的群组信息
                 getGroupUserGroupList()
                   .catch(error => console.warn(error))
                   .then(response => {
                     if(!response){
                       return
                     }
                     if (response.status == 200) {
                       console.log(response.data)
                       this.getGroupList(response.data)
                     } else {
                       this.$router.push({path: '/login'})
                     }
                   })
                 // 获取员工信息
                 getUserList()
                   .catch(error => console.warn(error))
                   .then(response => {
                     if(!response){
                       return
                     }
                     if (response.status == 200) {
                       this.getUserList(response.data)
                     } else {
                       this.$router.push({path: '/login'})
                     }
                   })
                 getUserConfigList()
                   .catch(error => console.warn(error))
                   .then(response => {
                     if(!response){
                       return
                     }
                     if (response.status == 200) {
                       let data = response.data
                       this.userConfig(data)
                     }
                   })
                 getStickTopChat()
                   .catch(error => console.warn(error))
                   .then(response => {
                     if(!response){
                       return
                     }
                     if (response.status == 200) {
                       let data = response.data
                       data.type = 'set'
                       this.setConversationStickStatus(data)
                       this.initConversationList()
                     }
                   })
                 // this.startHeartBeat()
                  // 信息加载完后跳转到聊天界面
                 // 开启获取请假消息
                 this.startRecNearLeave()
                 //获取会议活动消息
                 this.startRecNotify()
                 this.startRecNearActivity()
                 // 跳转
                 setTimeout(() => {
                   this.$router.push({path: '/main'})
                 }, 3500)
               }
             }else {
               this.$router.push({path: '/login'})
             }
            })
        }
      }
    }
</script>

<style scoped>
.ht-connect{
  position: relative;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
}
</style>
