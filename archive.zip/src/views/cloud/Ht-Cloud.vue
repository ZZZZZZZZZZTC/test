<template>
  <div class="ht-content">
    <div class="cont-left-box">
      <keep-alive>
        <!--云端列表-->
        <HtCloudTabs/>
      </keep-alive>
    </div>
    <!--右边主体-->
    <div class="cont-right-box">
      <!--云端主体-->
      <HtCloudContent/>
    </div>
  </div>
</template>

<script>
  import HtCloudTabs from '@/components/cloud/Ht-CloudTabs'
  import HtCloudContent from '@/components/cloud/Ht-CloudContent'
    export default {
        name: "HtCloud",
      components:{HtCloudTabs,HtCloudContent}
    }
</script>

<style scoped>

</style>
