<template>
  <div class="ht-content">
    <div class="cont-left-box">
      <!--通讯录列表-->
        <HtContactList  ref="HtContactList"
                        @handleCreateGroup="handleCreateGroup"/>
    </div>
    <!--右边主体-->
    <div class="cont-right-box">
      <!--通讯录主体-->
      <HtContactContent/>
    </div>

    <!--创建群组-->
    <HtCreateGroup v-if="createEvent"
                  :uids="groupDialogUids"
                  @handleCloseCreate="handleCloseCreate"/>
  </div>
</template>

<script>
  import {mapGetters,mapActions} from 'vuex'
  import HtContactList from '@/components/contact/Ht-ContactList'
  import HtContactContent from '@/components/contact/Ht-ContactContent'
  // 创建群组弹窗
  import HtCreateGroup from '@/components/contact/Ht-CreateGroup'
  export default {
    name: "HtContact",
    data() {
      return {
        createEvent:false,
        groupDialogUids:[]
      }
    },
    computed:{
      ...mapGetters(['staff'])
    },
    methods:{
      ...mapActions([
        'getContactUserId',
        'getContactGroupId',
        'getContactInfoType',
      ]),
      handleCreateGroup(){
        this.groupDialogUids.push(this.staff.uid)
        this.createEvent = true
      },
      handleCloseCreate(){
        this.groupDialogUids = []
        this.createEvent = false
      }
    },
    // 路由离开时清空
    beforeRouteLeave(to, from, next){
      this.getContactUserId('');
      this.getContactGroupId('');
      this.getContactInfoType('');
      next()
    },
    components: { HtContactList,HtContactContent,HtCreateGroup}
  }
</script>

<style scoped>

</style>
