<template>
  <div class="ht-content">
    <div class="cont-left-box">
        <!--会话列表-->
      <HtChatConversList/>
        <!--通讯录列表-->
    </div>
    <!--右边主体-->
    <div class="cont-right-box">
      <!--聊天主体-->
      <HtChatContent/>
    </div>
  </div>
</template>

<script>
  import HtChatConversList from '@/components/chat/Ht-ChatConversList'
  import HtChatContent from '@/components/chat/Ht-ChatContent'
    export default {
      name: "HtChat",
      components:{HtChatConversList,HtChatContent}
    }
</script>

<style scoped>

</style>
