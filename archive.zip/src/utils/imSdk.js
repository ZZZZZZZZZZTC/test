let imSdk = {
  instance: null,
  userId: '',
  params: {},
  callbacks: {},
  modules: {},
  /**
   * IM应用初始化
   * @param params
   * @param callbacks
   * @param modules
   */
  _init: function (params, callbacks, modules) {
    this._initParams(params);
    this._initCallbacks(callbacks);
    this._initModules(modules);
    let config = this._getInitConfig();

    this.modules.RongIMLib.RongIMClient.init(this.params.appKey,null,config);

    this.instance = RongIMClient.getInstance();

    this._handleOnReceiveMessageListener();
    this._handleConnectionStatusListener();
    this._handleConnect();
  },
  _initParams: function(params) {
    let _this = this;
    _this.params = params || {};
    _this.params.appKey = _this.params.appKey || "";
    _this.params.token = _this.params.token || "";
    _this.params.navi  = _this.params.navi || "";
    _this.params.api = _this.params.api || "";
  },

  _initCallbacks: function (callbacks) {
    let _this = this;
    _this.callbacks = callbacks;
  },

  _initModules: function (modules) {
    let _this = this;
    _this.modules = modules || {};
    _this.modules.RongIMLib = _this.modules.RongIMLib || window.RongIMLib;
    _this.modules.protobuf = _this.modules.protobuf || null;
  },
  _getInitConfig: function () {
    let _this = this;
    let config = {};
    // 私有云切换navi导航，私有云格式 '120.92.10.214:8888'
    if(_this.params.navi !== ""){
      config.navi = _this.params.navi;
    }
    // 私有云切换api,私有云格式 '172.20.210.38:81:8888'
    if(_this.params.api !== ""){
      config.api = _this.params.api ;
    }
    // support protobuf url + function
    if (_this.modules.protobuf  != null){
      config.protobuf = _this.modules.protobuf;
    }

    return config;
  },
  /**
   * 连接状态监听器
   * @private
   */
  _handleConnectionStatusListener:function () {
    let _this = this;
    _this.modules.RongIMLib.RongIMClient.setConnectionStatusListener({
      onChanged: function (status) {
        console.log('IM应用 连接状态码：', status);
        switch (status) {
          case RongIMLib.ConnectionStatus.CONNECTED:
            console.log('IM应用 连接成功');
            _this.callbacks.getInstance && _this.callbacks.getInstance(_this.instance);
            break;
          case RongIMLib.ConnectionStatus.CONNECTING:
            console.log('IM应用 正在连接');
            break;
          case RongIMLib.ConnectionStatus.DISCONNECTED:
            console.log('IM应用 断开连接');
            _this.callbacks.doDisconnected && _this.callbacks.doDisconnected();
            break;
          case RongIMLib.ConnectionStatus.KICKED_OFFLINE_BY_OTHER_CLIENT:
            console.log('IM应用 其他地方登录');
            _this.callbacks.doKickedOfflineByOtherClient && _this.callbacks.doKickedOfflineByOtherClient();
            break;
          case RongIMLib.ConnectionStatus.DOMAIN_INCORRECT:
            console.log('IM应用 域名不正确');
            break;
          case RongIMLib.ConnectionStatus.NETWORK_UNAVAILABLE:
            console.log('IM应用 网络不可用');
            // _this.reconnect();
            _this.callbacks.doNetworkUnavailable && _this.callbacks.doNetworkUnavailable();
            break;
          default:
            console.log('IM应用 未知状态');
        }
      }
    });

  },

  /**
   * 监听接收消息
   * @private
   */
  _handleOnReceiveMessageListener:function () {
    let _this = this;

    _this.modules.RongIMLib.RongIMClient.setOnReceiveMessageListener({
      // 接收到的消息
      onReceived: function (message) {
        // 判断消息类型
        console.log("IM应用 新消息: " + message.targetId);
        console.log(message);
        _this.callbacks.receiveNewMessage && _this.callbacks.receiveNewMessage(message);
      }
    });
  },

  /**
   * 开始创建连接
   * @private
   */
  _handleConnect:function () {
    let _this = this;

    _this.modules.RongIMLib.RongIMClient.connect(_this.params.token, {
      onSuccess: function(userId) {
        _this.userId = userId;
        _this.callbacks.getCurrentUser && _this.callbacks.getCurrentUser({userId:userId});
        console.log("IM应用 连接成功，用户id：" + userId);
      },
      onTokenIncorrect: function() {
        console.log('IM应用 token无效');
        alert('IM应用 token无效')
        _this.callbacks.doTokenIncorrect &&  _this.callbacks.doTokenIncorrect()
      },
      onError:function(errorCode){
        console.log("IM应用 连接错误码：",errorCode);
        alert("IM应用 连接错误码："+errorCode)
        // _this.reconnect();
        _this.callbacks.doConnectError &&  _this.callbacks.doConnectError(errorCode)
      }
    });
  },

  /**
   * IM连接
   * @param params
   * @param callbacks
   * @param modules
   */
  start: function (params, callbacks, modules) {
    console.log("IM应用 初始化");
    this._init(params,callbacks,modules);
  },

  /**
   * IM断连
   * @param callback
   */
  disconnect: function (callback) {
    console.log("IM应用 断开连接");
    this.instance.disconnect();
    callback && callback()
  },

  /**
   * IM重连
   */
  reconnect: function (callback) {
    console.log("IM应用 重新连接")
    let _this = this;
    let RongIMLib = _this.modules.RongIMLib;
    let RongIMClient = RongIMLib.RongIMClient;
    RongIMClient.reconnect({
      onSuccess: function(userId) {
        console.log("IM应用 重新连接 成功", userId);
        callback && callback()
      },
      onTokenIncorrect: function() {
        console.log("IM应用 重新连接 失败", "token无效");
        alert("IM应用 重新连接 失败", "token无效")
        _this.callbacks.doTokenIncorrect &&  _this.callbacks.doTokenIncorrect()
      },
      onError:function(errorCode){
        console.log("IM应用 重新连接错误码：", errorCode)
        alert("IM应用 重新连接错误码："+errorCode)
        _this.callbacks.doConnectError &&  _this.callbacks.doConnectError(errorCode)
      }
    });
  }
};

export default imSdk

