import {QuillWatch} from "../components/common/Editor/quillExtend";
import moment from "moment/moment";

export function genUId() {
  let date = new Date().getTime()
  let uuid = 'xxxxxx4xxxyxxxxxxx'.replace(/[xy]/g, function (c) {
    let r = (date + Math.random() * 16) % 16 | 0
    date = Math.floor(date / 16)
    return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16)
  })
  return 'im/images/' + uuid + '.png'
}

export function genMsgUId() {
  let date = new Date().getTime()
  let uuid = 'xxxxxx4xxxyxxxxxxx'.replace(/[xy]/g, function (c) {
    let r = (date + Math.random() * 16) % 16 | 0
    date = Math.floor(date / 16)
    return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16)
  })
  return uuid
}

export function hover(elem, overCallback, outCallback) {//实现hover事件
  var isHover = false;//判断是否悬浮在上方
  var preOvTime = new Date().getTime();//上次悬浮时间
  function unbind(elem, ev, callback) {
    if (typeof(callback) == "function") {
      if (document.all) {
        elem.detachEvent("on" + ev, callback);
      } else {
        elem.removeEventListener(ev, callback, false);
      }
    } else {
      if (document.all) {
        elem.detachEvent("on" + ev);
      } else {
        elem.removeEventListener(ev, false);
      }
    }
  }

  function bind(elem, ev, callback) {
    if (document.all) {
      elem.attachEvent("on" + ev, callback);
    } else {
      elem.addEventListener(ev, callback, false);
    }
  }

  function over(e) {
    var curOvTime = new Date().getTime();
    isHover = true;//处于over状态
    if (curOvTime - preOvTime > 10) {//时间间隔超过10毫秒，认为鼠标完成了mouseout事件
      overCallback(e, elem);
    }
    preOvTime = curOvTime;
  }

  function out(e) {
    var curOvTime = new Date().getTime();
    preOvTime = curOvTime;
    isHover = false;
    setTimeout(function () {
      if (!isHover) {
        outCallback(e, elem);
      }
    }, 10);
  }

  bind(elem, "mouseover", over);
  bind(elem, "mouseout", out);
};

export function hasClass(el, className) {
  let reg = new RegExp('(^|\\s)' + className + '(\\s|$)')
  return reg.test(el.className)
}

export function addClass(el, className) {
  if (hasClass(el, className)) {
    return
  }
  console.log(el, className)
  let newClass = el.className.split(' ')
  newClass.push(className)
  el.className = newClass.join(' ')
}

export function removeClass(el, className) {
  if (!hasClass(el, className)) {
    return
  }

  let reg = new RegExp('(^|\\s)' + className + '(\\s|$)', 'g')
  el.className = el.className.replace(reg, ' ')
}

export function getData(el, name, val) {
  let prefix = 'data-'
  if (val) {
    return el.setAttribute(prefix + name, val)
  }
  return el.getAttribute(prefix + name)
}

export function getRect(el) {
  if (el instanceof window.SVGElement) {
    let rect = el.getBoundingClientRect()
    return {
      top: rect.top,
      left: rect.left,
      width: rect.width,
      height: rect.height
    }
  } else {
    return {
      top: el.offsetTop,
      left: el.offsetLeft,
      width: el.offsetWidth,
      height: el.offsetHeight
    }
  }
}

export function getScrollOffsets(w) {
  // 使用指定的窗口，如果不带参数则使用当前窗口
  w = w || window;
  // 对标准模式下的IE（或任何浏览器）
  var d = w.document;
  if (document.compatMode == "CSS1Compat")
    return {x: d.documentElement.scrollLeft, y: d.documentElement.scrollTop};

}

export function serviceProtocol() {
  return 'https:'
  let protocol = window.location.protocol || 'http:'
  if (protocol == 'file:') protocol = 'https:'
  return protocol
}

export function structRelationship(fromTarget, recTarget, option) {
  // 拼接relationship
  let relationship = ''
  if (recTarget < 1000000) {
    // 个人聊天
    if (recTarget < 0 && recTarget != -4) {
      fromTarget > recTarget ? relationship = recTarget + '_' + fromTarget + '_M' : relationship = fromTarget + '_' + recTarget + '_M'
    } else if (recTarget >= 0) {
      fromTarget > recTarget ? relationship = recTarget + '_' + fromTarget + '_U' : relationship = fromTarget + '_' + recTarget + '_U'
    } else if (recTarget == -4) {
      fromTarget > recTarget ? relationship = recTarget + '_' + fromTarget + '_T' : relationship = fromTarget + '_' + recTarget + '_T'
    }
  } else if (recTarget >= 1000000) {
    // 群组聊天
    relationship = recTarget + "_" + recTarget + '_G'
  }
  return relationship
}

export function relationshipToType(relationship) {
  let types = ['U', 'G', 'M', 'T']
  let type = relationship.slice(relationship.length - 1, relationship.length)
  if (types.some((t) => t === type)) {
    return type
  } else {
    return 'U'
  }
}

// 上传工具函数
export function uploadItem(file, config, uuid, callbacks) {
  // 构造表单
  let formData = new FormData()
  formData.append('token', config.token)
  formData.append('file', file)
  formData.append('key', uuid)
  // 创建ajax请求
  let xhr = new XMLHttpRequest()
  xhr.open('post', config.action, true)
  // 如果有设置请求头
  if (config.headers) {
    config.headers(xhr)
  }
  callbacks.change(xhr, formData)
  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4) {
      if (xhr.status === 200) {
        //success
        let res = JSON.parse(xhr.responseText);
        callbacks.success(res);
      } else {
        //error
        callbacks.error()
      }
    }
  }
  // 开始上传数据
  xhr.upload.onloadstart = function (e) {
    callbacks.start(e)
  }
  // 上传过程
  xhr.upload.onprogress = function (e) {
    let complete = (e.loaded / e.total * 100 | 0)
    callbacks.progress(complete, xhr)
  }
  // 当发生网络异常的时候会触发，如果上传数据的过程还未结束
  xhr.upload.onerror = function (e) {
    callbacks.error(e)
  }
  // 上传数据完成（成功或者失败）时会触发
  xhr.upload.onloadend = function (e) {
    callbacks.end(e)
  }
  xhr.send(formData)
}

export function numToMsgType(num) {
  switch (num) {
    case 1:
      return 'RC:TxtMsg'
    case 2:
      return 'RC:ImgMsg'
    case 3:
      return 'HC:StickerMsg'
    case 4:
      return 'RC:FileMsg'
    case 5:
      return 'RC:InfoNtf'
    case 6:
      return 'RC:RcCmd'
    case 7:
      return 'RC:VcMsg'
    case 8:
      return 'RC:ImgTextMsg'
    case 9:
      return 'RC:CmdMsg'
    case 10:
      return 'HC:TextImage'
    default:
      break
  }
}

export function msgTypeToNum(type) {
  switch (type) {
    case 'G':
      return 3
    case 'U':
      return 1
    case 'T':
      return 1
    case 'M':
      return 1
    default:
      break;
  }
}

// 获取后缀名
export function getSuffix(o) {
  let arr = o.split('.');//通过\分隔字符串，成字符串数组
  return '.' + arr[arr.length - 1];//取最后一个，就是文件名
}

export function HtmlDecode(text) {
  var temp = document.createElement("div");
  temp.innerHTML = text;
  let output = temp.innerText || temp.textContent;
  temp = null;
  return output;
}

export function HtmlEncode(html) {
  let temp = document.createElement("div");
  //然后将要转换的字符串设置为这个元素的innerText(ie支持)或者textContent(火狐，google支持)
  (temp.textContent != undefined) ? (temp.textContent = html) : (temp.innerText = html);
  //最后返回这个元素的innerHTML，即得到经过HTML编码转换的字符串了
  let output = temp.innerHTML;
  temp = null;
  return output;
}

/**
 * @function unescapeHTML 还原html脚本 < > & " '
 * @param a -
 *            字符串
 */
export function unescapeHTML(a) {
  a = "" + a;
  return a.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&apos;/g, "'");
}

/*
* unicode码转中文
* */
export function toChineseWords(data) {
  if (data == '' || typeof data == 'undefined') return;
  data = data.split("\\u");
  var str = '';
  for (var i = 0; i < data.length; i++) {
    str += String.fromCharCode(parseInt(data[i], 16).toString(10));
  }
  return str;
}

// 消息类型转化
export function transformMsgType(type) {
  switch (type) {
    case '0':
      // 文本消息
      return "RC:TxtMsg"
      break;
    case '1':
      // 图片消息
      return 'RC:ImgMsg';
      break;
    case '2':
      // 文件消息
      return 'RC:FileMsg'
      break;
    case '3':
      // 语音消息
      return 'RC:VcMsg';
      break;
    case '4':
      // 图文 文档消息
      return  'RC:ImgTextMsg';
      break;
    case '7':
      // 系统提示消息
      return  "RC:InfoNtf"
      break;
    case '13':
     // 表情消息
     return 'HC:StickerMsg';
      break;
    case '14':
      // 自定义图文富文本消息
      return  'HC:TextImage'
      break;
  }
}

export function HTMLDecode(text) {
  let temp = document.createElement("div");
  temp.innerHTML = text;
  let output = temp.innerText || temp.textContent;
  temp = null;
  return output;
}

export function parseChatText(str, mentionedInfo, item,staff) {
  str = String(str)
  str = str.replace(/amp;/g, '')
  if (mentionedInfo) {
    if (mentionedInfo.type == 1) {
      const keywords = '@所有人'
      let reg = new RegExp(keywords)
      str = str.replace(reg, '&lt;em&gt;' + keywords + '&lt;/em&gt;')
    } else {
      let isMentioned = mentionedInfo.userIdList.includes(this.taff.uid)
      if (isMentioned) {
        let keywords = '@' + this.staff.full_name
        let reg = new RegExp(keywords)
        str = str.replace(reg, '&lt;em&gt;' + keywords + '&lt;/em&gt;')
        console.log(str)
      }
    }
  }
  let reg = /(http:\/\/|https:\/\/)((\w|=|\?|\.|\/|&|-|\:|\;|\+|\%|\#)+)/g;
  let imgreg = /https:\/\/pic2.hanmaker.com/g;
  let imgreg2 = /https:\/\/upload.hanmaker.com/g;
  const key = 'zhanwei&43211234132';
  const key2 = 'zhanwei&8698743912';
  const key3 = 'zhanwei&7456374537';
  let returnreg = /zhanwei&43211234132/g;
  let returnreg2 = /zhanwei&8698743912/g;
  // let temphtml = this.HTMLDecode(str);
  let temphtml = HTMLDecode(str)
  temphtml = temphtml.replace(imgreg, key);
  temphtml = temphtml.replace(imgreg2, key2);
  temphtml = temphtml.replace(reg, '<a href="javascript:;" class="outer-url" data-url=$1$2 onclick="openURL(\'$1$2\')">$1$2</a>');
  temphtml = temphtml.replace(returnreg, 'https://pic2.hanmaker.com');
  temphtml = temphtml.replace(returnreg2, 'https://upload.hanmaker.com');
  temphtml = temphtml.replace(key3, 'http://');
  temphtml = symbolToHTML(temphtml);
  return temphtml
}

export function formatDate(needTime) {
  needTime = needTime*1000
  function add0(m){return m<10?'0'+m:m }
  //needTime是整数，否则要parseInt转换
  var time = new Date(needTime);
  var y = time.getFullYear();
  var m = time.getMonth()+1;
  var d = time.getDate();
  var h = time.getHours();
  var mm = time.getMinutes();
  var s = time.getSeconds();
  return y+'-'+add0(m)+'-'+add0(d)+' '+add0(h)+':'+add0(mm)+':'+add0(s);
}

export  function trim(str) {
    return str.replace(/(^\s*)|(\s*$)/g, "");
}



export function unixDateFormat(time, format) {
  format = format || 'YYYY-MM-DD HH:mm:ss'
  return moment.unix(time).format(format)
}

