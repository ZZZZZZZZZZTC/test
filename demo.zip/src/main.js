import Vue from 'vue'
import App from './App'
import router from './router'
import {sync} from 'vuex-router-sync'
import store from '@/store'
import * as filters from '@/filters';

// 引入全局css
// import '@/assets/less/main.less'

// 注册全局过滤器
Object.keys(filters).forEach(key => {
  Vue.filter(key, filters[key])
})

// 动态修改页面的title名称 需要在router里面设置title参数
router.beforeEach((to, from, next) => {
  window.document.title = to.meta.title
  if (to.meta.requiresAuth && store.getters.isGuest)
    next('/')
  else
    next()
});

sync(store, router)

Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  render: h => h(App)
})
