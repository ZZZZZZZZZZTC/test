import * as types from '../mutations-types'

const state = {
    demo:1
}

const mutations = {
    [types.DEMO](state,payload){
        state.demo = payload
    }
}

const actions = {
    handleDemoData({commit,dispatch,state},payload){
        commit(types.DEMO,payload)
    }
}

const getters = {

}

export default {
    state,
    mutations,
    actions,
    getters
}