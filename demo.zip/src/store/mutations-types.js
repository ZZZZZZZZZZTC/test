// 图片列表相关
export const DEMO = 'DEMO'
