import moment from "moment/moment";


export function hover(elem, overCallback, outCallback) {//实现hover事件
  var isHover = false;//判断是否悬浮在上方
  var preOvTime = new Date().getTime();//上次悬浮时间
  function unbind(elem, ev, callback) {
    if (typeof(callback) == "function") {
      if (document.all) {
        elem.detachEvent("on" + ev, callback);
      } else {
        elem.removeEventListener(ev, callback, false);
      }
    } else {
      if (document.all) {
        elem.detachEvent("on" + ev);
      } else {
        elem.removeEventListener(ev, false);
      }
    }
  }

  function bind(elem, ev, callback) {
    if (document.all) {
      elem.attachEvent("on" + ev, callback);
    } else {
      elem.addEventListener(ev, callback, false);
    }
  }

  function over(e) {
    var curOvTime = new Date().getTime();
    isHover = true;//处于over状态
    if (curOvTime - preOvTime > 10) {//时间间隔超过10毫秒，认为鼠标完成了mouseout事件
      overCallback(e, elem);
    }
    preOvTime = curOvTime;
  }

  function out(e) {
    var curOvTime = new Date().getTime();
    preOvTime = curOvTime;
    isHover = false;
    setTimeout(function () {
      if (!isHover) {
        outCallback(e, elem);
      }
    }, 10);
  }

  bind(elem, "mouseover", over);
  bind(elem, "mouseout", out);
};

export function hasClass(el, className) {
  let reg = new RegExp('(^|\\s)' + className + '(\\s|$)')
  return reg.test(el.className)
}

export function addClass(el, className) {
  if (hasClass(el, className)) {
    return
  }
  console.log(el, className)
  let newClass = el.className.split(' ')
  newClass.push(className)
  el.className = newClass.join(' ')
}

export function removeClass(el, className) {
  if (!hasClass(el, className)) {
    return
  }

  let reg = new RegExp('(^|\\s)' + className + '(\\s|$)', 'g')
  el.className = el.className.replace(reg, ' ')
}


export function getRect(el) {
  if (el instanceof window.SVGElement) {
    let rect = el.getBoundingClientRect()
    return {
      top: rect.top,
      left: rect.left,
      width: rect.width,
      height: rect.height
    }
  } else {
    return {
      top: el.offsetTop,
      left: el.offsetLeft,
      width: el.offsetWidth,
      height: el.offsetHeight
    }
  }
}

export function getScrollOffsets(w) {
  // 使用指定的窗口，如果不带参数则使用当前窗口
  w = w || window;
  // 对标准模式下的IE（或任何浏览器）
  var d = w.document;
  if (document.compatMode == "CSS1Compat")
    return {x: d.documentElement.scrollLeft, y: d.documentElement.scrollTop};

}

export function serviceProtocol() {
  return 'https:'
  let protocol = window.location.protocol || 'http:'
  if (protocol == 'file:') protocol = 'https:'
  return protocol
}


// 上传工具函数
export function uploadItem(file, config, uuid, callbacks) {
  // 构造表单
  let formData = new FormData()
  formData.append('token', config.token)
  formData.append('file', file)
  formData.append('key', uuid)
  // 创建ajax请求
  let xhr = new XMLHttpRequest()
  xhr.open('post', config.action, true)
  // 如果有设置请求头
  if (config.headers) {
    config.headers(xhr)
  }
  callbacks.change(xhr, formData)
  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4) {
      if (xhr.status === 200) {
        //success
        let res = JSON.parse(xhr.responseText);
        callbacks.success(res);
      } else {
        //error
        callbacks.error()
      }
    }
  }
  // 开始上传数据
  xhr.upload.onloadstart = function (e) {
    callbacks.start(e)
  }
  // 上传过程
  xhr.upload.onprogress = function (e) {
    let complete = (e.loaded / e.total * 100 | 0)
    callbacks.progress(complete, xhr)
  }
  // 当发生网络异常的时候会触发，如果上传数据的过程还未结束
  xhr.upload.onerror = function (e) {
    callbacks.error(e)
  }
  // 上传数据完成（成功或者失败）时会触发
  xhr.upload.onloadend = function (e) {
    callbacks.end(e)
  }
  xhr.send(formData)
}

export function numToMsgType(num) {
  switch (num) {
    case 1:
      return 'RC:TxtMsg'
    case 2:
      return 'RC:ImgMsg'
    case 3:
      return 'HC:StickerMsg'
    case 4:
      return 'RC:FileMsg'
    case 5:
      return 'RC:InfoNtf'
    case 6:
      return 'RC:RcCmd'
    case 7:
      return 'RC:VcMsg'
    case 8:
      return 'RC:ImgTextMsg'
    case 9:
      return 'RC:CmdMsg'
    case 10:
      return 'HC:TextImage'
    default:
      break
  }
}

export function msgTypeToNum(type) {
  switch (type) {
    case 'G':
      return 3
    case 'U':
      return 1
    case 'T':
      return 1
    case 'M':
      return 1
    default:
      break;
  }
}

// 获取后缀名
export function getSuffix(o) {
  let arr = o.split('.');//通过\分隔字符串，成字符串数组
  return '.' + arr[arr.length - 1];//取最后一个，就是文件名
}


