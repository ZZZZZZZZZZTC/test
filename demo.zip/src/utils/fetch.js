import axios from 'axios'
import qs from 'qs'
import Cookies from 'js-cookie'
import { serviceProtocol } from '@/utils/utils'
// import * as _ from './whole'
axios.defaults.timeout = 185000;
axios.defaults.headers.post['Content-Type'] = 'application/json;charset=UTF-8';
//POST传参序列化
axios.interceptors.request.use((config) => {
  if(config.method  === 'post'){
    // config.data = qs.stringify(config.data);
  }
  return config;
},(error) =>{
  // _.toast("错误的传参");
  // console.warn("错误的传参");
  return Promise.reject(error);
});
//code状态码200判断
axios.interceptors.response.use((res) =>{
  if(!res.data.hasOwnProperty('status')) {
    return Promise.reject(res.data);
  }
  return res.data;
}, (error) => {
  // _.toast("网络异常");
  // console.warn("网络异常");
  return Promise.reject(error);
});

function fetch(options) {
  options = options || {}
  let pos = options.url.search(/^http/i)
  if (pos == -1)
    options.url = serviceProtocol() + options.url;
  options.headers = options.headers || {};
  options.headers['HC-ACCESS-TOKEN'] = Cookies.get('hanmaker_auth') || window.localStorage.getItem('hc_access_token')
      // options.headers['HC-ACCESS-TOKEN'] = "czo1OToiZTE1Njh6VEJlcWwyZ29tWmR5Mmg5Q3h1OTgvU0NkNUFjTmwwZWI1aXNRbkZBa05aWkVCd1hhSGg3TVUiOw=="

  return axios(options)
}

export default fetch;
