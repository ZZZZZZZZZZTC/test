import fetch from '@/utils/fetch'

const DOMAIN = '//api.hanmaker.com'

// 发送消息 post 请求
export function publishChatMsg(data) {
    return fetch({
      method: 'post',
      url: `${DOMAIN}/V3/Message/publishPrivate`,
      data: data
    })
  }

  // 获取表情包组 get 请求
export function getStickerGroup() {
    return fetch({
      url: `${DOMAIN}/V2/Sticker/getGroups`,
    })
  }