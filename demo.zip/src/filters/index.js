/* all filters*/
import moment from 'moment'
// 时间戳格式化
export function unixDateFormat(time, format) {
  format = format || 'YYYY-MM-DD HH:mm:ss'
  return moment.unix(time).format(format)
}

export function chatTimeFormat(timestamp) {

  Date.prototype.format = function (format) {
    var date = {
      "M+": this.getMonth() + 1,
      "d+": this.getDate(),
      "h+": this.getHours(),
      "m+": this.getMinutes(),
      "s+": this.getSeconds(),
      "q+": Math.floor((this.getMonth() + 3) / 3),
      "S+": this.getMilliseconds()
    };
    if (/(y+)/i.test(format)) {
      format = format.replace(RegExp.$1, (this.getFullYear() + '').substr(4 - RegExp.$1.length));
    }
    for (var k in date) {
      if (new RegExp("(" + k + ")").test(format)) {
        format = format.replace(RegExp.$1, RegExp.$1.length == 1
          ? date[k] : ("00" + date[k]).substr(("" + date[k]).length));
      }
    }
    return format;
  }

  var getFormatTime = {
    // 获取当天开始时间戳
    getTodayStart:function(){
      var myDate = new Date();
      // 开始月份下标为0
      var nowMonth = parseInt(myDate.getMonth()) + parseInt(1);
      return Date.parse(myDate.getFullYear() + '/' + nowMonth + '/' + myDate.getDate()) / 1000;
    },
    // 获取时分
    getLocalTime: function (nS) {
      var newDate = new Date();
      newDate.setTime(nS * 1000);
      return newDate.format('hh:mm');
    },
    // 获取完整时间
    getCompleteTime: function (nS, spacer) {
      var newDate = new Date();
      newDate.setTime(nS * 1000);
      return spacer?newDate.format('yyyy' + spacer +'MM' + spacer +'dd hh:mm'):newDate.format('yyyy/MM/dd');
    },
    // 格式化时间
    format: function (timestampToday, spacer) {
      // 判断当天日期 规则2：当天信息不显示日期。如今天的信息显示时间：  14：25
      if (timestampToday > this.getTodayStart())
        return this.getLocalTime(timestampToday);
      // 判断昨天日期 规则3：昨天的信息需要标记。如：昨天 14：25
      else if (parseInt(timestampToday) + parseInt(86400) > this.getTodayStart())
        return spacer ? '昨天':'昨天 ' + this.getLocalTime(timestampToday);
      // 判断昨天以前 规则4：昨天以前的信息需要显示日期，如：2017年4月18日 14：25
      else
        return this.getCompleteTime(timestampToday, spacer);

    }
  }

  return getFormatTime.format(timestamp)
}
// 会话列表时间格式化
export function chatSimTimeFormat(timestamp) {
  Date.prototype.format = function (format) {
    var date = {
      "M+": this.getMonth() + 1,
      "d+": this.getDate(),
      "h+": this.getHours(),
      "m+": this.getMinutes(),
      "s+": this.getSeconds(),
      "q+": Math.floor((this.getMonth() + 3) / 3),
      "S+": this.getMilliseconds()
    };
    if (/(y+)/i.test(format)) {
      format = format.replace(RegExp.$1, (this.getFullYear() + '').substr(4 - RegExp.$1.length));
    }
    for (var k in date) {
      if (new RegExp("(" + k + ")").test(format)) {
        format = format.replace(RegExp.$1, RegExp.$1.length === 1
          ? date[k] : ("00" + date[k]).substr(("" + date[k]).length));
      }
    }
    return format;
  }

  var getFormatTime = {
    // 获取当天开始时间戳
    getTodayStart:function(){
      var myDate = new Date();
      // 开始月份下标为0
      var nowMonth = parseInt(myDate.getMonth()) + parseInt(1);
      return Date.parse(myDate.getFullYear() + '/' + nowMonth + '/' + myDate.getDate()) / 1000;
    },
    // 获取时分
    getLocalTime: function (nS) {
      var newDate = new Date();
      newDate.setTime(nS * 1000);
      return newDate.format('hh:mm');
    },
    // 获取完整时间
    getCompleteTime: function (nS, spacer) {
      var newDate = new Date();
      newDate.setTime(nS * 1000);
      return spacer?newDate.format('yy' + spacer +'MM' + spacer +'dd'):newDate.format('MM/dd');
    },
    // 格式化时间
    format: function (timestampToday, spacer) {
      // 判断当天日期 规则2：当天信息不显示日期。如今天的信息显示时间：  14：25
      if (timestampToday > this.getTodayStart())
        return this.getLocalTime(timestampToday);
      // 判断昨天日期 规则3：昨天的信息需要标记。如：昨天 14：25
      else if (parseInt(timestampToday) + parseInt(86400) > this.getTodayStart())
        return spacer?'昨天':'昨天 ';
      // 判断昨天以前 规则4：昨天以前的信息需要显示日期，如：2017年4月18日 14：25
      else
        return this.getCompleteTime(timestampToday, spacer);

    }
  }

  return getFormatTime.format(timestamp)
}

// 聊天框时间格式化
export function handleChatTimeFormat(timestamp, preTimesStamp) {
  if (timestamp === preTimesStamp) {
    return chatTimeFormat(timestamp)
  }
  return chatTimeFormat(timestamp)
}

// 格式化文件字节大小
// 格式化文件字节大小
export function getFileSize(fileByte) {
  var fileSizeByte = fileByte;
  var fileSizeMsg = "";
  if (fileSizeByte < 1048576) {
    if(fileSizeByte < 1024){
      fileSizeMsg = fileSizeByte +'B'
    }else{
      fileSizeMsg = (fileSizeByte / 1024).toFixed(2) + "KB"
    }
  }
  else if (fileSizeByte == 1048576) fileSizeMsg = "1MB";
  else if (fileSizeByte > 1048576 && fileSizeByte < 1073741824) fileSizeMsg = (fileSizeByte / (1024 * 1024)).toFixed(2) + "MB";
  else if (fileSizeByte > 1048576 && fileSizeByte == 1073741824) fileSizeMsg = "1GB";
  else if (fileSizeByte > 1073741824 && fileSizeByte < 1099511627776) fileSizeMsg = (fileSizeByte / (1024 * 1024 * 1024)).toFixed(2) + "GB";
  else if (fileSizeByte == null) fileSizeMsg = "0KB";
  else fileSizeMsg = "文件超过1TB";
  return fileSizeMsg;
}
// 删除无用的html
export function delHtmlTag(str) {
  //去掉所有的html标记
  return str.replace(/<[^>]+>/g, "");
}
//本地时间戳格式化非UNIX
export  function formatDate (timestamp,mat) {
    return  moment(parseInt(timestamp)).format(mat || 'YYYY-MM-DD HH:mm:ss')
}
