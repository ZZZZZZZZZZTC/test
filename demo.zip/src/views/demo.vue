<template>
    <div class="demo">
    </div> 
</template>

<script>
export default {
    name: 'demo',
    data: function() {	
        return {}
    },
    methods: {}
}
</script>

<style scoped>

</style>