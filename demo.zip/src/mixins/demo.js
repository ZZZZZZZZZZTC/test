export default{
    methods:{
        demo(){
            console.log('这是个mixin的demo')
        }
    }
}